# PIPEDA Compliance Checklist
## YSSL S.T.A.R.Toolbox — Track 1 Data Foundation
**Version:** 1.0 | **Date:** June 11, 2026
**Legislation:** Personal Information Protection and Electronic Documents Act (PIPEDA)
**Owner:** Track 1 — Preetham Nagulapalli

---

## 1. What is PIPEDA?

PIPEDA is Canada's federal privacy law governing how private sector
organizations collect, use, and disclose personal information in the
course of commercial activity. It applies to any information about
an identifiable individual.

---

## 2. Personal Information Assessment

| Field | Personal Information? | Risk Level | Justification |
|---|---|---|---|
| recipient_name | Borderline | Low | Public grant records — published by Canada Council |
| province | No | None | Geographic region only |
| city | Borderline | Low | Public record — published by Canada Council |
| postal_code | Yes | Medium | Could identify small communities |
| business_number | Yes | Low | Public business registry information |
| canonical_id | No | None | Hash — not reversible to identity |
| grant amounts | No | None | Public grant records |
| field_of_practice | No | None | Professional category only |
| ip_activity_flag | No | None | Derived signal — not personal data |
| rfm_score | No | None | Derived score — not personal data |
| segment | No | None | Derived category — not personal data |

---

## 3. Key PIPEDA Principles Applied

### Principle 1 — Accountability
Track 1 owns and is accountable for all data in this pipeline.
YSSL Inc. is accountable for data once handed off.

### Principle 2 — Identifying Purposes
Data is used solely for:
- Building creative professional profiles for S.T.A.R.Toolbox
- Academic capstone research at Northeastern University
- Market sizing and segmentation analysis for YSSL

### Principle 3 — Consent
All source data is publicly available open government data.
No individual consent required for publicly published grant records.

### Principle 4 — Limiting Collection
Only fields necessary for the project are retained.
Raw bilingual columns, redundant fields, and unnecessary
identifiers were dropped during cleaning.

### Principle 5 — Limiting Use
Data is used only for stated purposes above.
Not shared with third parties outside the project team.

### Principle 6 — Accuracy
Six-dimension quality scorecard documents accuracy levels.
CPI adjustment ensures financial accuracy across years.

### Principle 7 — Safeguards
- GitHub repo is private
- Raw data stored locally — not uploaded to any cloud service
- No sensitive personal information in processed files

### Principle 8 — Openness
This governance document is the transparency record.
Available to sponsor and course instructor on request.

### Principle 9 — Individual Access
Source data is publicly available from Canada Council.
Individuals can view their own grant records at
open.canada.ca

### Principle 10 — Challenging Compliance
Any compliance concerns can be directed to:
Track 1 owner — Preetham Nagulapalli
Course instructor — Valerie Atherley
Sponsor — YSSL Inc.

---

## 4. Risk Summary

| Risk | Level | Mitigation |
|---|---|---|
| Re-identification from name + city + postal code | Low | All source data is public record |
| Unauthorized access to raw data | Low | Local storage only, private GitHub |
| Data used beyond stated purpose | Low | Governance plan limits use |
| Postal code identifying small communities | Medium | Not used in analysis — retained for reference only |

---

## 5. Recommendation for YSSL

When S.T.A.R.Toolbox begins collecting user account data
(names, emails, payment information, project details),
a full PIPEDA compliance review will be required including:
- Privacy policy drafting
- Consent mechanisms
- Data breach response plan
- Privacy impact assessment

This checklist covers only the Track 1 research data foundation.
It does not cover future user-generated data.
