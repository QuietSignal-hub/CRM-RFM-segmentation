# Data Dictionary
## YSSL S.T.A.R.Toolbox — Creative Professional Profile Table
**Version:** 1.0 | **Date:** June 11, 2026 | **Owner:** Track 1 — Preetham Nagulapalli

---

## Table: creative_profiles_v3.csv
**Description:** Unified CRM-ready profile table of 24,350 unique Canadian creative professionals derived from Canada Council for the Arts grant data (2017–2024), enriched with CPI inflation adjustment, RFM scoring, audience segmentation, NAICS codes, and O*NET occupational vocabulary.

| Column | Type | Description | Source | Known Issues |
|---|---|---|---|---|
| canonical_id | string | Unique 12-character MD5 hash of cleaned name + province | Derived | None |
| recipient_name | string | Legal name of grant recipient | Canada Council | Mixed case in raw data — cleaned |
| recipient_type | string | Organization or Individual | Canada Council | Based on business number presence |
| province | string | Full province name | Canada Council | Standardized from abbreviations |
| city | string | City at time of grant approval | Canada Council | Not standardized — mixed case |
| field_of_practice | string | Canada Council creative discipline | Canada Council | 13 categories |
| priority_sector | string | Photography & Film / Music & Singing / Dance / Other | Derived | Other = non-priority fields |
| is_priority | int | 1 = priority sector, 0 = other | Derived | None |
| naics_code | string | 6-digit NAICS industry code | Derived from O*NET map | Single code per field — simplified |
| onet_soc_code | string | O*NET Standard Occupational Classification code | O*NET 30.3 | US-based — needs NOC crosswalk |
| onet_title | string | O*NET occupation title | O*NET 30.3 | None |
| top_skills | string | Top 3 skills pipe-separated | O*NET 30.3 | 27-1019.00 substituted with 27-1013.00 |
| top_work_activities | string | Top 3 work activities pipe-separated | O*NET 30.3 | Same substitution as above |
| grant_count | int | Total number of grants received 2017–2024 | Canada Council | None |
| grant_total_nominal | int | Sum of grants in nominal dollars | Canada Council | Not inflation adjusted |
| grant_total_2024_cad | int | Sum of grants in 2024 CAD | Derived via CPI | CPI data ends 2024 |
| avg_grant_2024_cad | int | Average grant in 2024 CAD | Derived | Rounded to nearest dollar |
| first_grant_year | int | Year of first grant | Canada Council | Fiscal year start extracted |
| last_grant_year | int | Year of most recent grant | Canada Council | None |
| years_active | int | last_grant_year - first_grant_year + 1 | Derived | None |
| recency | int | 2024 - last_grant_year | Derived | None |
| frequency | int | Same as grant_count | Derived | None |
| monetary | int | Same as grant_total_2024_cad | Derived | None |
| r_score | int | Recency score 1-5 (5=most recent) | Derived | Percentile-based |
| f_score | int | Frequency score 1-5 (5=most frequent) | Derived | Percentile-based |
| m_score | int | Monetary score 1-5 (5=highest value) | Derived | Percentile-based |
| rfm_score | int | Sum of r+f+m scores (3-15) | Derived | None |
| segment | string | Core Champion / Established Regular / Emerging Creative / Lapsed Recipient | Derived | Thresholds: 13+=Core, 10+=Established, 7+=Emerging |
| ip_activity_flag | int | 1 = IP activity likely, 0 = unlikely | Derived | Proxy method — not verified trademark match |
