# Data Governance Plan
## YSSL S.T.A.R.Toolbox — Track 1 Data Foundation
**Version:** 1.0 | **Date:** June 11, 2026
**Framework:** DAMA-DMBOK2
**Owner:** Track 1 — Preetham Nagulapalli

---

## 1. Data Ownership

| Dataset | Owner | Steward |
|---|---|---|
| Canada Council Grants | Canada Council for the Arts | Track 1 |
| StatCan CPI | Statistics Canada | Track 1 |
| StatCan Business Counts | Statistics Canada | Track 1 |
| StatCan Financial Stats | Statistics Canada | Track 1 |
| CIPO Trademarks | Canadian Intellectual Property Office | Track 1 |
| O*NET 30.3 | US Department of Labor | Track 1 |
| Creative Profiles Table | YSSL Inc. | Track 1 |

---

## 2. Data Stewardship

Track 1 is responsible for:
- Maintaining clean versioned datasets in data/processed/
- Documenting all transformation decisions
- Flagging data quality issues to the team
- Updating datasets when source data is refreshed
- Ensuring reproducibility of all pipelines

---

## 3. Missing Value Policy

| Column | Decision | Reason |
|---|---|---|
| business_number | Flag as Individual | No business number = unregistered individual |
| postal_code | Leave as null | Too few (106) to impute reliably |
| priority_sector | Fill with Other | Non-priority fields are valid not missing |
| 27-1019.00 O*NET skills | Substitute 27-1013.00 | Closest occupational match available |

---

## 4. Data Retention Policy

| Dataset | Retention | Location |
|---|---|---|
| Raw source files | Indefinite | data/raw/ local only not in GitHub |
| Processed datasets | Indefinite | data/processed/ GitHub tracked |
| Governance documents | Indefinite | docs/ GitHub tracked |
| Jupyter notebooks | Indefinite | notebooks/ GitHub tracked |

---

## 5. Update Frequency

| Dataset | Source Update Frequency | Action Required |
|---|---|---|
| Canada Council Grants | Annual | Re-run cleaning pipeline |
| StatCan CPI | Annual | Update CPI table re-run adjustment |
| StatCan Business Counts | Annual | Re-download and re-filter |
| CIPO Trademarks | Quarterly | Re-download latest bulk file |
| O*NET | Annual | Check for new version |

---

## 6. Reproducibility

All pipelines are fully reproducible:
- Raw data stored locally in data/raw/
- All transformations documented in Jupyter notebooks
- No random seeds required all operations are deterministic
- GitHub repo tagged at each phase completion
- Anyone with raw data files can re-run notebooks top to bottom

---

## 7. Data Lineage

Canada Council Raw CSV
→ 08_clean_canada_council.ipynb
→ canada_council_clean_v1.csv
→ 09_build_recipient_profiles.ipynb
→ creative_profiles_v1.csv (RFM + segments)
→ 10_cipo_fuzzy_match.ipynb
→ creative_profiles_v2.csv (+ ip_activity_flag)
→ 11_enrich_profiles.ipynb
→ creative_profiles_v3.csv (+ NAICS + O*NET)

---

## 8. Access Controls

- GitHub repo: Private team members only
- Raw data: Local machine only not shared via GitHub
- Processed data: GitHub accessible to all team members
- No personally identifiable information beyond public grant records
