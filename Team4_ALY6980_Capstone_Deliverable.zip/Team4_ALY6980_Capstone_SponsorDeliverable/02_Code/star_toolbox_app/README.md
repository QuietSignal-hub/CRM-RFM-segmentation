# S.T.A.R. Toolbox

**S.T.A.R. Toolbox** — An algorithmic analysis engine that connects business, cultural, community, regional, and creative dimensions to produce actionable recommendations grounded in local context.

## Why S.T.A.R. Exists

Canadian SMBs face a fragmented resource ecosystem with no unified pathways to scale locally. Entrepreneurs struggle to map their assets, understand their strategic position, navigate regulatory requirements, and develop plans tailored to their region and market.

S.T.A.R. Toolbox helps them do exactly that—providing a configurable framework to analyze five interdependent dimensions (business, cultural, community, regional, creative), identify gaps, benchmark against comparable profiles, and generate recommendations that serve their specific context.

Importantly, S.T.A.R. works out of the box with baseline resources. Or, if you prefer, bring your own data sources, APIs, and databases. It's your choice.

## Purpose

S.T.A.R. Toolbox analyzes multidimensional input across five core dimensions to identify your strategic position and generate localized action plans. It's designed to be immediately useful with baseline resources, or optionally enhanced with your own systems—you choose.

### Key Features

- **Baseline Included** — Use provided resources, templates, and data sources out of the box with zero setup
- **Optional Custom Data** — Upload your own documents, images, reports, and media via the brainstorm panel
- **Optional Custom Sources** — Connect URLs, RSS feeds, AI providers, or databases if you want to (not required)
- **Adaptive Weight Inference** — Learns what matters to you from your behavior, not from predefined templates
- **Multidimensional Analysis** — Evaluates business viability, market validation, compliance/regulation, cultural fit, and creative potential simultaneously
- **Gap & Strength Analysis** — Flags dimensions as gaps or strengths relative to comparable profiles
- **Comparative Benchmarking** — Shows how you compare to similar businesses in your sector and region
- **Regulatory & Compliance Integration** — Incorporates jurisdiction-specific requirements into recommendations
- **Recommendations** — Action plans addressing gaps and leveraging strengths
- **Design Profiling** — Derives visual identity (fonts, colors, layout) from your strategic profile

---

## Quick Start

### Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec

**Required environment variables:**
- None (works out of the box with baseline resources)

## Tech Stack

- **Workspace:** pnpm workspaces, Node.js 24, TypeScript 5.9
- **API:** Express 5, TypeScript
- **Storage:** Local JSON filesystem (default; optional external DB support)
- **Validation:** Zod (`zod/v4`)
- **API Codegen:** Orval (from OpenAPI spec)
- **Build:** esbuild (CJS bundle)

## Repository Structure

### `/lib`

- **`api-spec/openapi.yaml`** — API contract (source of truth for all endpoints)

### `/artifacts`

- **`api-server`** — Express server with modular route handlers and algorithmic scoring engine
  - `src/lib/storage.ts` — JSON file read/write abstraction + optional external DB connectors
  - `src/lib/algorithm/` — Adaptive scoring engine, benchmarking, recommender, design profiler
  - `src/lib/integrations/` — URL/RSS parsing, AI provider connectors, database adapters (all optional)
  - `src/lib/baseline/` — Default resources, templates, benchmarking datasets, regulatory frameworks
  - `src/routes/` — One file per module (identity, frameworks, integrations, brainstorm, etc.)
  - `local-data/` — Runtime JSON storage directory (gitignored, auto-created on first write)

## Core Architecture

### Baseline + Optional Integrations

S.T.A.R. gives you two ways to work:

**Default: Baseline Mode**
- Provided resources: industry benchmarks, regional data, cultural frameworks, ecosystem templates
- Provided templates: recommendation templates, design profiles, regulatory compliance datasets
- No additional configuration needed
- Start analyzing immediately

**Optional: Enhanced with Your Systems**
- Upload your own files (brainstorm panel)
- Connect your own data sources (URLs, RSS feeds, databases)
- Plug in your own AI providers (any LLM you choose)
- All integrations are opt-in; baseline mode works perfectly without them

### Data Input: Two Panels

#### Brainstorm Panel (Optional Custom Files)
Upload directly into the system:
- Documents: PDF, Word, Google Docs, Notion exports
- Media: Images, video clips, audio recordings
- Reports: Analysis documents, meeting notes, strategic plans, financial records
- Structured data: Spreadsheets, CSV, JSON

#### Integrations Panel (All Optional)

**1. Content Sources (URL, HTML, RSS)**
- Custom RSS feeds (industry news, competitor tracking, market intelligence)
- Website URLs (parse HTML, extract metadata)
- Any publicly accessible content
- System automatically parses and ingests for analysis

**2. AI Providers (Bring Your Own API Key)**
- Mistral AI, OpenAI, Anthropic, or any compatible LLM
- Users provide their own API keys
- System uses configured provider for enhanced analysis (supplements, not replaces, baseline)

**3. Database Connections (Proprietary or Cloud)**
- Connect your own database (PostgreSQL, MySQL, MongoDB, etc.)
- Used for analysis: system queries your data to inform recommendations
- Used for backend file management: system stores/retrieves assets from your infrastructure

### Algorithm Flow

1. **Load inputs** — Aggregate:
   - User identity and preferences
   - Baseline data or custom integrations (your choice)
   - Custom brainstorm uploads (optional)
   - Connected integrations (RSS, AI, database—all optional)

2. **Infer dimension weights from behavior** — Analyze user actions, file uploads (if any), source choices, and priorities

3. **Evaluate against 5 dimensions:**
   - **Business** — Market viability, unit economics, revenue model
   - **Cultural** — Identity, values, cultural fit, framework alignment
   - **Community** — Stakeholder alignment, community impact, relational assets
   - **Regional** — Geographic context, local regulations, resource availability
   - **Creative** — Innovation, differentiation, aesthetic/market positioning

4. **Benchmark against comparable profiles** — Find similar businesses using baseline (or supplemented) datasets

5. **Gap & strength analysis** — Identify dimensions scoring < 33% as gaps; ≥ 66% as strengths

6. **Incorporate regulatory & compliance requirements** — Flag jurisdiction-specific obligations

7. **AI-enhanced analysis (optional)** — If AI provider connected, use for deeper insight

8. **Generate recommendations** — Produce action plans addressing gaps, leveraging strengths, meeting compliance

9. **Generate design profile** — Derive visual identity from strategic analysis

10. **Write results** — Persist to JSON or connected database

### Data Model: 8 Modules

| Module | Endpoint | Purpose |
|--------|----------|---------|
| **Identity** | `PUT /api/identity` | User profile: name, role, sector, region, goals, strengths, interests |
| **Cultural Frameworks** | `CRUD /api/cultural-frameworks` | Ideological/values lenses: baseline provided, custom additions optional |
| **Integrations** | `CRUD /api/integrations` | Connected sources (all optional): URLs, RSS feeds, AI API keys, database credentials |
| **Brainstorm** | `CRUD /api/brainstorm` | Uploaded files (optional): PDF, doc, image, video, audio, spreadsheet, report |
| **Ecosystem** | `CRUD /api/ecosystem` | Resources: baseline provided, custom additions optional |
| **Recommendations** | `CRUD /api/recommendations` | Algorithmically-generated + manually-curated action plans |
| **Design** | `GET /api/design` | Visual identity profile derived from analysis |
| **Inventory** | `GET /api/inventory` | Summary count of all stored data |

### Main Workflow

**`POST /api/analyze`** — Trigger the full algorithm. Returns:
- Inferred dimension weights
- Comparable business profiles and benchmarks
- Dimension strengths (≥ 66%) and gaps (< 33%)
- Regulatory/compliance gaps and obligations
- AI-enhanced insights (if provider connected)
- Recommendations with action steps
- Design profile

## Architecture Decisions

- **Batteries included with optional upgrades:** Baseline resources, templates, and benchmarking data provided out of the box. Users can opt into custom integrations without friction or forced configuration.
- **No forced external dependencies:** Default to local JSON filesystem. External databases, APIs, and AI providers are all optional.
- **User-controlled credentials (if integrating):** If users connect external services, they control credentials. System never stores or retains them after session.
- **Adaptive weight inference, not predefined scoring:** Dimension weights learned from user behavior, not imposed upfront.
- **5 interdependent dimensions:** Business, cultural, community, regional, creative analyzed together.
- **Rule-based algorithm, Phase 1, AI-enhanced Phase 2:** Core scoring deterministic and auditable. Optional AI providers enhance without replacing core logic.
- **OpenAPI-first:** Spec defines contract; codegen produces Zod schemas.
- **Regulatory/compliance as data:** Jurisdiction-specific requirements feed into recommendations.
- **Design as strategic output:** Visual identity derived from strategic analysis.
- **Configurable and expandable:** Baseline datasets, recommendation templates, AI providers, and database adapters customizable per region or partnership.

## Development Workflow

1. **Define API contracts** in `lib/api-spec/openapi.yaml`
2. **Codegen:** Run `pnpm --filter @workspace/api-spec run codegen` to generate Zod schemas
3. **Implement route handler** in `artifacts/api-server/src/routes/`
4. **Add baseline resources** to `src/lib/baseline/` (templates, benchmarks, frameworks, regulatory data)
5. **Add integration logic** to `src/lib/integrations/` (URL/RSS parsing, AI connectors, DB adapters—all optional)
6. **Add algorithm logic** to `src/lib/algorithm/` (weight inference, dimension evaluation, benchmarking)
7. **Test:** Use Postman, curl, or client library to call endpoints
8. **Typecheck & build:** `pnpm run build` verifies everything compiles

## User Constraints (Phase 1)

- ✅ Baseline resources included; custom integrations optional
- ✅ Local filesystem default; optional external DB connection
- ✅ API-first; UI development deferred until algorithm is stable
- ✅ Rule-based algorithm; AI providers optional (user-supplied API keys)
- ✅ No cloud dependencies — runs on any system with Node.js
- ✅ No vendor lock-in — all data and credentials owned by user

## Gotchas

- **`local-data/` auto-created on first write** — Do not commit to version control (already in `.gitignore`)
- **Baseline is a complete system** — You don't need to configure anything to start using S.T.A.R.
- **Custom integrations are opt-in** — Adding your own data sources is optional and only enhances analysis if applicable to your use case
- **Algorithm learns from behavior over time** — Early interactions may produce generic recommendations; as users input more data, analysis becomes more accurate
- **API keys are user-managed (if connecting external services)** — System does not store credentials; users must provide them per session or via environment
- **Design endpoint requires prior analysis** — `GET /api/design` returns 404 until `/api/analyze` has been run at least once
- **Regulatory frameworks are region-specific** — Compliance recommendations vary by jurisdiction; ensure regulatory data is current for your target region

## Environment Setup: Quick Start

### Baseline Mode (Default)
1. Install dependencies: `pnpm install`
2. Start the API server: `pnpm --filter @workspace/api-server run dev`
3. Make your first API call: `PUT /api/identity`
4. Run the algorithm: `POST /api/analyze`
5. Retrieve results: `GET /api/design`, `GET /api/recommendations`

### Enhanced Mode (Optional)
Same as above, plus optionally:
- Upload files to brainstorm panel
- Add RSS feed URLs
- Configure AI provider API keys
- Connect your database
- All work seamlessly alongside baseline

## Integration Types (All Optional)

### Content Sources (URL, HTML, RSS)
```
GET /api/integrations/parse-content?type=rss&url=https://example.com/feed
GET /api/integrations/parse-content?type=url&url=https://example.com
GET /api/integrations/parse-content?type=html&html=<html>...</html>
```

### AI Providers
```
POST /api/integrations/ai-provider
{
  "provider": "mistral|openai|anthropic|custom",
  "apiKey": "user-provided-key",
  "model": "specific-model-id"
}
```

### Database Connections
```
POST /api/integrations/database
{
  "type": "postgresql|mysql|mongodb|custom",
  "host": "database-host",
  "port": 5432,
  "database": "database-name",
  "credentials": { "username": "...", "password": "..." }
}
```

All credentials are validated on connection but not stored persistently. Baseline mode requires none of these.
