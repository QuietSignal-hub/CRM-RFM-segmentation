import React, { useState, useCallback } from "react";
import { X } from "lucide-react";

interface Position { x: number; y: number; }
interface Size { width: number; height: number; }
type ResizeDir = "n" | "s" | "e" | "w" | "ne" | "nw" | "se" | "sw";

const CURSOR: Record<ResizeDir, string> = {
  n: "ns-resize", s: "ns-resize", e: "ew-resize", w: "ew-resize",
  ne: "nesw-resize", sw: "nesw-resize", nw: "nwse-resize", se: "nwse-resize",
};

const HANDLES: ResizeDir[] = ["n", "s", "e", "w", "ne", "nw", "se", "sw"];

const getHandleStyle = (dir: ResizeDir): React.CSSProperties => {
  const corner = dir.length === 2;
  const base: React.CSSProperties = { position: "absolute", cursor: CURSOR[dir], zIndex: 10 };
  if (corner) {
    const sz = 12;
    return {
      ...base,
      width: sz, height: sz,
      top:    dir.includes("n") ? 0 : undefined,
      bottom: dir.includes("s") ? 0 : undefined,
      left:   dir.includes("w") ? 0 : undefined,
      right:  dir.includes("e") ? 0 : undefined,
    };
  }
  if (dir === "n") return { ...base, top: 0,    left: 12, right: 12, height: 6 };
  if (dir === "s") return { ...base, bottom: 0, left: 12, right: 12, height: 6 };
  if (dir === "e") return { ...base, right: 0,  top: 12,  bottom: 12, width: 6 };
  if (dir === "w") return { ...base, left: 0,   top: 12,  bottom: 12, width: 6 };
  return base;
};

interface ToolWindowProps {
  id: string;
  title: string;
  icon: React.ReactNode;
  position: Position;
  size: Size;
  onMove: (id: string, pos: Position) => void;
  onResize: (id: string, size: Size, pos: Position) => void;
  onClose: (id: string) => void;
  onFocus: (id: string) => void;
  zIndex: number;
  children: React.ReactNode;
  minWidth?: number;
  minHeight?: number;
}

const ToolWindow: React.FC<ToolWindowProps> = ({
  id, title, icon, position, size, onMove, onResize, onClose, onFocus, zIndex,
  children, minWidth = 320, minHeight = 260,
}) => {
  const [dragging, setDragging] = useState(false);

  const handleTitlePointerDown = useCallback((e: React.PointerEvent<HTMLDivElement>) => {
    if ((e.target as HTMLElement).closest("[data-no-drag]")) return;
    e.preventDefault();
    onFocus(id);
    const startX = e.clientX, startY = e.clientY;
    const origX = position.x, origY = position.y;
    setDragging(true);
    e.currentTarget.setPointerCapture(e.pointerId);

    const onMoveHandler = (ev: PointerEvent) => {
      onMove(id, {
        x: Math.max(0, origX + ev.clientX - startX),
        y: Math.max(0, origY + ev.clientY - startY),
      });
    };
    const onUpHandler = () => {
      setDragging(false);
      window.removeEventListener("pointermove", onMoveHandler);
      window.removeEventListener("pointerup", onUpHandler);
    };
    window.addEventListener("pointermove", onMoveHandler);
    window.addEventListener("pointerup", onUpHandler);
  }, [id, position, onMove, onFocus]);

  const handleResizePointerDown = useCallback((dir: ResizeDir, e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    onFocus(id);
    const startX = e.clientX, startY = e.clientY;
    const origX = position.x, origY = position.y;
    const origW = size.width, origH = size.height;

    const onMoveHandler = (ev: PointerEvent) => {
      const dx = ev.clientX - startX, dy = ev.clientY - startY;
      let nx = origX, ny = origY, nw = origW, nh = origH;
      if (dir.includes("e")) nw = Math.max(minWidth,  origW + dx);
      if (dir.includes("w")) { nw = Math.max(minWidth,  origW - dx); nx = origX + origW - nw; }
      if (dir.includes("s")) nh = Math.max(minHeight, origH + dy);
      if (dir.includes("n")) { nh = Math.max(minHeight, origH - dy); ny = origY + origH - nh; }
      onResize(id, { width: nw, height: nh }, { x: nx, y: ny });
    };
    const onUpHandler = () => {
      window.removeEventListener("pointermove", onMoveHandler);
      window.removeEventListener("pointerup", onUpHandler);
    };
    window.addEventListener("pointermove", onMoveHandler);
    window.addEventListener("pointerup", onUpHandler);
  }, [id, position, size, onResize, onFocus, minWidth, minHeight]);

  return (
    <div
      style={{
        position: "absolute",
        left: position.x,
        top: position.y,
        width: size.width,
        height: size.height,
        zIndex,
      }}
      className={`flex flex-col border border-border bg-card rounded-xl overflow-hidden transition-shadow ${dragging ? "shadow-2xl" : "shadow-lg"}`}
      onPointerDown={() => onFocus(id)}
    >
      <div
        onPointerDown={handleTitlePointerDown}
        className="flex items-center gap-2 px-3 h-9 bg-muted/60 border-b border-border cursor-grab active:cursor-grabbing flex-shrink-0 select-none"
      >
        <span className="text-primary flex-shrink-0 flex items-center">{icon}</span>
        <span className="text-sm font-semibold text-foreground flex-1 truncate">{title}</span>
        <button
          data-no-drag
          onPointerDown={(e) => e.stopPropagation()}
          onClick={() => onClose(id)}
          className="flex-shrink-0 w-5 h-5 rounded flex items-center justify-center text-muted-foreground hover:bg-destructive/20 hover:text-destructive transition-colors"
        >
          <X size={12} />
        </button>
      </div>

      <div className="flex-1 overflow-hidden">
        {children}
      </div>

      {HANDLES.map((dir) => (
        <div
          key={dir}
          style={getHandleStyle(dir)}
          onPointerDown={(e) => handleResizePointerDown(dir, e)}
        />
      ))}
    </div>
  );
};

export default ToolWindow;
