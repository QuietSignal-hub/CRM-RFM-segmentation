import React from "react";
import {
  AlignHorizontalJustifyCenter,
  AlignHorizontalJustifyStart,
  AlignHorizontalJustifyEnd,
  AlignVerticalJustifyCenter,
  AlignVerticalJustifyStart,
  AlignVerticalJustifyEnd,
  AlignHorizontalSpaceAround,
  AlignVerticalSpaceAround,
} from "lucide-react";

interface AlignmentToolbarProps {
  selectedCount: number;
  onAlign: (action: AlignAction) => void;
  onClearSelection: () => void;
}

export type AlignAction =
  | "align-left"
  | "align-center-h"
  | "align-right"
  | "align-top"
  | "align-center-v"
  | "align-bottom"
  | "distribute-h"
  | "distribute-v";

const AlignmentToolbar: React.FC<AlignmentToolbarProps> = ({
  selectedCount,
  onAlign,
  onClearSelection,
}) => {
  if (selectedCount < 1) return null;

  const btn =
    "p-1.5 rounded-md hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors";

  return (
    <div className="fixed top-3 left-1/2 -translate-x-1/2 z-[100] flex items-center gap-1 px-3 py-1.5 bg-card border border-border rounded-xl shadow-lg">
      <span className="text-xs font-medium text-muted-foreground mr-2">
        {selectedCount} selected
      </span>

      <div className="h-5 w-px bg-border" />

      <button title="Align left" className={btn} onClick={() => onAlign("align-left")}>
        <AlignHorizontalJustifyStart size={16} />
      </button>
      <button title="Align center (H)" className={btn} onClick={() => onAlign("align-center-h")}>
        <AlignHorizontalJustifyCenter size={16} />
      </button>
      <button title="Align right" className={btn} onClick={() => onAlign("align-right")}>
        <AlignHorizontalJustifyEnd size={16} />
      </button>

      <div className="h-5 w-px bg-border" />

      <button title="Align top" className={btn} onClick={() => onAlign("align-top")}>
        <AlignVerticalJustifyStart size={16} />
      </button>
      <button title="Align center (V)" className={btn} onClick={() => onAlign("align-center-v")}>
        <AlignVerticalJustifyCenter size={16} />
      </button>
      <button title="Align bottom" className={btn} onClick={() => onAlign("align-bottom")}>
        <AlignVerticalJustifyEnd size={16} />
      </button>

      <div className="h-5 w-px bg-border" />

      <button title="Distribute horizontally" className={btn} onClick={() => onAlign("distribute-h")}>
        <AlignHorizontalSpaceAround size={16} />
      </button>
      <button title="Distribute vertically" className={btn} onClick={() => onAlign("distribute-v")}>
        <AlignVerticalSpaceAround size={16} />
      </button>

      <div className="h-5 w-px bg-border" />

      <button
        className="px-2 py-1 text-xs rounded-md hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors"
        onClick={onClearSelection}
      >
        Clear
      </button>
    </div>
  );
};

export default AlignmentToolbar;
