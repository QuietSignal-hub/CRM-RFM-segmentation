import React, { useState } from "react";
import { ShieldCheck, ExternalLink, ChevronDown, ChevronUp, Loader2, AlertTriangle, Info, AlertCircle, CheckCircle2, RotateCcw } from "lucide-react";

// ── Types (mirrors lib/api-zod shapes) ────────────────────────────────────

type Industry = "photography" | "music" | "dance";

interface ProjectCharacteristics {
  involvesMinors?: boolean;
  commercialUse?: boolean;
  hiringCrew?: boolean;
  publicProperty?: boolean;
  outdoorShoot?: boolean;
  droneUse?: boolean;
  paidModels?: boolean;
  sellsPrints?: boolean;
  livePerformance?: boolean;
  ticketedEvent?: boolean;
  usesRecordedMusic?: boolean;
  recordedRelease?: boolean;
  sellsMerch?: boolean;
}

interface ComplianceCheckRequest {
  description?: string;
  industry: Industry;
  userLocation: string;
  workLocation: string;
  clientLocation: string;
  characteristics: ProjectCharacteristics;
}

type Severity = "critical" | "high" | "medium" | "low";

interface MatchedRule {
  id: string;
  title: string;
  description: string;
  jurisdiction: string;
  category: string;
  severity: Severity;
  explanation: string;
  aiEnriched: boolean;
  sourceName: string;
  sourceUrl: string;
  formReference?: string;
  noticePeriod?: string;
  actionSteps?: string[];
  verified: boolean;
  lastVerified: string | null;
}

interface SeverityBreakdown {
  critical: number;
  high: number;
  medium: number;
  low: number;
}

interface ComplianceCheckResponse {
  checkId: string;
  timestamp: string;
  jurisdictionsResolved: string[];
  matchCount: number;
  severityBreakdown: SeverityBreakdown;
  rules: MatchedRule[];
  disclaimer: string;
}

interface HistoryEntry {
  request: ComplianceCheckRequest;
  response: ComplianceCheckResponse;
  ranAt: string;
}

// ── Constants ─────────────────────────────────────────────────────────────

const INDUSTRIES: { value: Industry; label: string }[] = [
  { value: "photography", label: "Photography" },
  { value: "music",       label: "Music"       },
  { value: "dance",       label: "Dance"       },
];

const CHARACTERISTICS: { key: keyof ProjectCharacteristics; label: string }[] = [
  { key: "involvesMinors",    label: "Involves minors"       },
  { key: "commercialUse",     label: "Commercial use"        },
  { key: "hiringCrew",        label: "Hiring crew"           },
  { key: "publicProperty",    label: "Public property"       },
  { key: "outdoorShoot",      label: "Outdoor shoot"         },
  { key: "droneUse",          label: "Drone use"             },
  { key: "paidModels",        label: "Paid models"           },
  { key: "sellsPrints",       label: "Sells prints"          },
  { key: "livePerformance",   label: "Live performance"      },
  { key: "ticketedEvent",     label: "Ticketed event"        },
  { key: "usesRecordedMusic", label: "Uses recorded music"   },
  { key: "recordedRelease",   label: "Recorded release"      },
  { key: "sellsMerch",        label: "Sells merch"           },
];

const SEVERITY_CONFIG: Record<Severity, { label: string; bg: string; text: string; icon: React.ReactNode }> = {
  critical: { label: "Critical", bg: "bg-red-100",    text: "text-red-700",    icon: <AlertCircle   size={11} /> },
  high:     { label: "High",     bg: "bg-orange-100", text: "text-orange-700", icon: <AlertTriangle size={11} /> },
  medium:   { label: "Medium",   bg: "bg-yellow-100", text: "text-yellow-700", icon: <Info          size={11} /> },
  low:      { label: "Low",      bg: "bg-green-100",  text: "text-green-700",  icon: <CheckCircle2  size={11} /> },
};

// ── Helpers ───────────────────────────────────────────────────────────────

const EMPTY_FORM: ComplianceCheckRequest = {
  industry: "photography",
  userLocation: "",
  workLocation: "",
  clientLocation: "",
  description: "",
  characteristics: {},
};

async function runComplianceCheck(req: ComplianceCheckRequest): Promise<ComplianceCheckResponse> {
  const res = await fetch("/api/compliance-check", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(req),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err?.error ?? err?.message ?? `HTTP ${res.status}`);
  }
  return res.json();
}

// ── Sub-components ────────────────────────────────────────────────────────

const SeverityBadge: React.FC<{ severity: Severity }> = ({ severity }) => {
  const cfg = SEVERITY_CONFIG[severity];
  return (
    <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-semibold ${cfg.bg} ${cfg.text}`}>
      {cfg.icon}
      {cfg.label}
    </span>
  );
};

const RuleCard: React.FC<{ rule: MatchedRule }> = ({ rule }) => {
  const [open, setOpen] = useState(false);
  return (
    <div className="border border-border rounded-lg overflow-hidden">
      <button
        className="w-full flex items-start gap-2 px-3 py-2.5 bg-muted/30 hover:bg-muted/50 transition-colors text-left"
        onClick={() => setOpen((v) => !v)}
      >
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <SeverityBadge severity={rule.severity} />
            <span className="text-[10px] text-muted-foreground border border-border rounded px-1.5 py-0.5">{rule.jurisdiction}</span>
            <span className="text-[10px] text-muted-foreground border border-border rounded px-1.5 py-0.5">{rule.category}</span>
          </div>
          <p className="text-xs font-semibold text-foreground mt-1 leading-snug">{rule.title}</p>
        </div>
        <div className="flex-shrink-0 mt-0.5 text-muted-foreground">
          {open ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
        </div>
      </button>

      {open && (
        <div className="border-t border-border px-3 py-2.5 space-y-2">
          {rule.aiEnriched && rule.explanation && (
            <p className="text-xs text-foreground leading-relaxed">{rule.explanation}</p>
          )}
          {!rule.aiEnriched && (
            <p className="text-xs text-muted-foreground leading-relaxed">{rule.description}</p>
          )}
          {rule.formReference && (
            <p className="text-xs text-muted-foreground"><span className="font-medium text-foreground">Form:</span> {rule.formReference}</p>
          )}
          {rule.noticePeriod && (
            <p className="text-xs text-muted-foreground"><span className="font-medium text-foreground">Notice period:</span> {rule.noticePeriod}</p>
          )}
          {rule.actionSteps && rule.actionSteps.length > 0 && (
            <div>
              <p className="text-xs font-medium text-foreground mb-1">Action steps</p>
              <ol className="list-decimal list-inside space-y-0.5">
                {rule.actionSteps.map((s, i) => (
                  <li key={i} className="text-xs text-muted-foreground">{s}</li>
                ))}
              </ol>
            </div>
          )}
          <a
            href={rule.sourceUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
          >
            {rule.sourceName} <ExternalLink size={10} />
          </a>
          {rule.lastVerified && (
            <p className="text-[10px] text-muted-foreground">Last verified: {new Date(rule.lastVerified).toLocaleDateString()}</p>
          )}
        </div>
      )}
    </div>
  );
};

const SeverityBar: React.FC<{ breakdown: SeverityBreakdown; total: number }> = ({ breakdown, total }) => {
  if (total === 0) return null;
  const severities: Severity[] = ["critical", "high", "medium", "low"];
  return (
    <div className="flex items-center gap-3 flex-wrap">
      {severities.map((s) => {
        const count = breakdown[s];
        if (!count) return null;
        const cfg = SEVERITY_CONFIG[s];
        return (
          <span key={s} className={`inline-flex items-center gap-1 text-xs font-medium ${cfg.text}`}>
            {cfg.icon} {count} {cfg.label}
          </span>
        );
      })}
    </div>
  );
};

// ── Main Component ────────────────────────────────────────────────────────

type View = "form" | "results" | "history";

const CompliancePanel: React.FC = () => {
  const [view, setView]       = useState<View>("form");
  const [form, setForm]       = useState<ComplianceCheckRequest>(EMPTY_FORM);
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState<string | null>(null);
  const [result, setResult]   = useState<ComplianceCheckResponse | null>(null);
  const [history, setHistory] = useState<HistoryEntry[]>([]);

  // ── Form helpers ──
  const setField = <K extends keyof ComplianceCheckRequest>(key: K, value: ComplianceCheckRequest[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const toggleChar = (key: keyof ProjectCharacteristics) => {
    setForm((prev) => ({
      ...prev,
      characteristics: {
        ...prev.characteristics,
        [key]: !prev.characteristics[key],
      },
    }));
  };

  const handleSubmit = async () => {
    if (!form.userLocation.trim() || !form.workLocation.trim() || !form.clientLocation.trim()) {
      setError("Please fill in all location fields.");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const res = await runComplianceCheck(form);
      setResult(res);
      setHistory((prev) => [{ request: form, response: res, ranAt: new Date().toISOString() }, ...prev]);
      setView("results");
    } catch (e: any) {
      setError(e?.message ?? "Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setForm(EMPTY_FORM);
    setResult(null);
    setError(null);
    setView("form");
  };

  const handleLoadHistory = (entry: HistoryEntry) => {
    setForm(entry.request);
    setResult(entry.response);
    setView("results");
  };

  // ── Render ──
  return (
    <div className="flex flex-col h-full overflow-hidden">

      {/* Tab bar */}
      <div className="flex items-center gap-0 border-b border-border flex-shrink-0 px-3">
        {(["form", "results", "history"] as View[]).map((v) => (
          <button
            key={v}
            onClick={() => setView(v)}
            className={`px-3 py-2 text-xs font-medium border-b-2 transition-colors capitalize ${
              view === v
                ? "border-primary text-primary"
                : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            {v === "results" ? `Results${result ? ` (${result.matchCount})` : ""}` : v === "history" ? `History${history.length ? ` (${history.length})` : ""}` : "New check"}
          </button>
        ))}
      </div>

      {/* ── FORM VIEW ── */}
      {view === "form" && (
        <div className="flex-1 overflow-y-auto p-3 space-y-4">

          {/* Industry */}
          <div>
            <label className="block text-xs font-semibold text-foreground mb-1.5">Industry</label>
            <div className="flex gap-2 flex-wrap">
              {INDUSTRIES.map((ind) => (
                <button
                  key={ind.value}
                  onClick={() => setField("industry", ind.value)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-colors ${
                    form.industry === ind.value
                      ? "bg-primary text-primary-foreground border-primary"
                      : "bg-background text-foreground border-border hover:bg-muted"
                  }`}
                >
                  {ind.label}
                </button>
              ))}
            </div>
          </div>

          {/* Locations */}
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-foreground">Locations</label>
            {[
              { key: "userLocation",   placeholder: "Your location (e.g. Toronto, ON)"     },
              { key: "workLocation",   placeholder: "Work location (e.g. Montréal, QC)"    },
              { key: "clientLocation", placeholder: "Client location (e.g. New York, USA)" },
            ].map(({ key, placeholder }) => (
              <input
                key={key}
                type="text"
                placeholder={placeholder}
                value={(form as any)[key]}
                onChange={(e) => setField(key as any, e.target.value)}
                className="w-full px-2.5 py-1.5 text-xs rounded-md border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
              />
            ))}
          </div>

          {/* Project characteristics */}
          <div>
            <label className="block text-xs font-semibold text-foreground mb-1.5">Project characteristics</label>
            <div className="grid grid-cols-2 gap-x-4 gap-y-1.5">
              {CHARACTERISTICS.map(({ key, label }) => (
                <label key={key} className="flex items-center gap-2 cursor-pointer group">
                  <input
                    type="checkbox"
                    checked={!!form.characteristics[key]}
                    onChange={() => toggleChar(key)}
                    className="w-3 h-3 rounded border-border accent-primary cursor-pointer"
                  />
                  <span className="text-xs text-muted-foreground group-hover:text-foreground transition-colors">{label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold text-foreground mb-1.5">
              Project description <span className="text-muted-foreground font-normal">(optional)</span>
            </label>
            <textarea
              rows={3}
              placeholder="e.g. Shooting a commercial campaign in Quebec for a US client with child models…"
              value={form.description ?? ""}
              onChange={(e) => setField("description", e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs rounded-md border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary resize-none"
            />
          </div>

          {error && (
            <div className="flex items-start gap-2 px-3 py-2 bg-destructive/10 text-destructive rounded-md text-xs">
              <AlertTriangle size={12} className="mt-0.5 flex-shrink-0" />
              {error}
            </div>
          )}

          <button
            onClick={handleSubmit}
            disabled={loading}
            className="w-full flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:brightness-110 disabled:opacity-60 disabled:cursor-not-allowed transition"
          >
            {loading ? (
              <><Loader2 size={13} className="animate-spin" /> Checking…</>
            ) : (
              <><ShieldCheck size={13} /> Run compliance check</>
            )}
          </button>
        </div>
      )}

      {/* ── RESULTS VIEW ── */}
      {view === "results" && result && (
        <div className="flex-1 overflow-y-auto flex flex-col">
          {/* Summary bar */}
          <div className="px-3 py-2.5 border-b border-border flex-shrink-0 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-foreground">{result.matchCount} rule{result.matchCount !== 1 ? "s" : ""} matched</span>
              <button
                onClick={handleReset}
                className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
              >
                <RotateCcw size={11} /> New check
              </button>
            </div>
            <SeverityBar breakdown={result.severityBreakdown} total={result.matchCount} />
            <div className="flex flex-wrap gap-1">
              {result.jurisdictionsResolved.map((j) => (
                <span key={j} className="text-[10px] border border-border rounded px-1.5 py-0.5 text-muted-foreground">{j}</span>
              ))}
            </div>
          </div>

          {/* Rules */}
          <div className="flex-1 overflow-y-auto p-3 space-y-2">
            {result.rules.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <CheckCircle2 size={28} className="text-green-500 mb-2" />
                <p className="text-xs font-semibold text-foreground">No compliance rules matched</p>
                <p className="text-xs text-muted-foreground mt-1">Your project characteristics don't trigger any rules in the current database.</p>
              </div>
            ) : (
              result.rules.map((rule) => <RuleCard key={rule.id} rule={rule} />)
            )}
          </div>

          {/* Disclaimer */}
          <div className="px-3 py-2 border-t border-border flex-shrink-0">
            <p className="text-[10px] text-muted-foreground leading-relaxed">{result.disclaimer}</p>
          </div>
        </div>
      )}

      {/* ── RESULTS VIEW (no result yet) ── */}
      {view === "results" && !result && (
        <div className="flex-1 flex items-center justify-center text-center px-6">
          <div>
            <ShieldCheck size={28} className="text-muted-foreground mx-auto mb-2" />
            <p className="text-xs font-semibold text-foreground">No results yet</p>
            <p className="text-xs text-muted-foreground mt-1">Run a compliance check from the New check tab.</p>
            <button onClick={() => setView("form")} className="mt-3 text-xs text-primary hover:underline">Go to form</button>
          </div>
        </div>
      )}

      {/* ── HISTORY VIEW ── */}
      {view === "history" && (
        <div className="flex-1 overflow-y-auto p-3">
          {history.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <RotateCcw size={28} className="text-muted-foreground mb-2" />
              <p className="text-xs font-semibold text-foreground">No checks yet</p>
              <p className="text-xs text-muted-foreground mt-1">Your past compliance checks will appear here.</p>
            </div>
          ) : (
            <div className="space-y-2">
              {history.map((entry, i) => (
                <button
                  key={i}
                  onClick={() => handleLoadHistory(entry)}
                  className="w-full text-left border border-border rounded-lg px-3 py-2.5 hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-semibold text-foreground capitalize">{entry.request.industry}</span>
                    <span className="text-[10px] text-muted-foreground">{new Date(entry.ranAt).toLocaleTimeString()}</span>
                  </div>
                  <p className="text-[10px] text-muted-foreground truncate">
                    {entry.request.workLocation} · {entry.response.matchCount} rule{entry.response.matchCount !== 1 ? "s" : ""}
                  </p>
                  <SeverityBar breakdown={entry.response.severityBreakdown} total={entry.response.matchCount} />
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default CompliancePanel;
