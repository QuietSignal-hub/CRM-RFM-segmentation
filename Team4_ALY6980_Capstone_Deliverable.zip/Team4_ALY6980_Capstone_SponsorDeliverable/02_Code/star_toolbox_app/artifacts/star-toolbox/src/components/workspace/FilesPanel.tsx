import React, { useState } from "react";
import { ChevronRight, X, FileText, Image, Film, Music, Table, File, Layers, Globe, Star, Zap, FolderOpen, Download, Eye } from "lucide-react";

export interface SavedFile {
  id: string;
  name: string;
  type: "brainstorm" | "integrations" | "optimize" | "bundle" | "ecosystem" | "tool" | "closed-item";
  data: any;
  category?: FileCategory;
  thumbnail?: string;
  createdAt: Date;
  updatedAt: Date;
}

export type FileCategory =
  | "Tools"
  | "Sources"
  | "Project Assets"
  | "Media"
  | "Compliance"
  | "Community"
  | "Archives"
  | "Geographic Node";

const TYPE_LABELS: Record<string, string> = {
  brainstorm: "Brainstorm",
  integrations: "Sources",
  optimize: "Action Plan",
  bundle: "Layout Snapshot",
  ecosystem: "Ecosystem",
  tool: "Tool",
  "closed-item": "Archived",
};

const TYPE_ICONS: Record<string, React.ComponentType<{ size: number; className?: string }>> = {
  brainstorm: FileText,
  integrations: Layers,
  optimize: Zap,
  bundle: FolderOpen,
  ecosystem: Globe,
  tool: Star,
  "closed-item": File,
};

const MIME_ICONS: Record<string, React.ComponentType<{ size: number; className?: string }>> = {
  document: FileText, spreadsheet: Table, image: Image, video: Film, audio: Music, other: File,
};

interface FilesPanelProps {
  files: SavedFile[];
  onOpenFile: (file: SavedFile) => void;
  onDeleteFile: (id: string) => void;
}

// ── Full-page media viewer modal ──
const MediaViewerModal: React.FC<{ file: SavedFile; asset?: any; onClose: () => void }> = ({ file, asset, onClose }) => {
  const mediaItem = asset || file.data;
  
  // Determine media type
  let mediaType = "unknown";
  if (file.type === "brainstorm" && asset?.mimeCategory) {
    mediaType = asset.mimeCategory;
  } else if (mediaItem?.mimeType) {
    const mimeType = mediaItem.mimeType.toLowerCase();
    if (mimeType.startsWith("image/")) mediaType = "image";
    else if (mimeType.startsWith("video/")) mediaType = "video";
    else if (mimeType.startsWith("audio/")) mediaType = "audio";
    else if (mimeType.includes("text")) mediaType = "text";
  }

  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-card rounded-lg shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-auto relative" onClick={(e) => e.stopPropagation()}>
        <div className="sticky top-0 flex items-center justify-between px-6 py-4 border-b border-border bg-card/95 backdrop-blur">
          <h2 className="text-lg font-semibold truncate">{mediaItem?.name || file.name}</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X size={24} />
          </button>
        </div>

        <div className="p-6">
          {/* Image */}
          {mediaType === "image" && (
            <div className="flex justify-center">
              <img src={mediaItem?.dataUrl} alt={mediaItem?.name} className="max-w-full max-h-[70vh] rounded-lg" />
            </div>
          )}

          {/* Video */}
          {mediaType === "video" && (
            <video controls className="w-full max-h-[70vh] rounded-lg bg-black">
              <source src={mediaItem?.dataUrl} type={mediaItem?.mimeType} />
              Your browser does not support the video tag.
            </video>
          )}

          {/* Audio */}
          {mediaType === "audio" && (
            <div className="flex flex-col items-center gap-4">
              <Music size={64} className="text-primary" />
              <audio controls className="w-full">
                <source src={mediaItem?.dataUrl} type={mediaItem?.mimeType} />
                Your browser does not support the audio element.
              </audio>
              <p className="text-sm text-muted-foreground">{mediaItem?.name}</p>
            </div>
          )}

          {/* PDF or Document Text */}
          {(mediaType === "text" || mediaItem?.content) && (
            <div className="prose prose-sm max-w-none dark:prose-invert">
              <div className="bg-muted/50 p-4 rounded-lg whitespace-pre-wrap break-words text-sm leading-relaxed text-foreground">
                {mediaItem?.content || "No content available"}
              </div>
            </div>
          )}

          {/* Fallback for unknown media */}
          {mediaType === "unknown" && (
            <div className="text-center py-12">
              <File size={48} className="text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">File format not supported for preview</p>
              {mediaItem?.dataUrl && (
                <a href={mediaItem.dataUrl} download className="mt-4 inline-block px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90">
                  Download File
                </a>
              )}
            </div>
          )}

          {/* File metadata */}
          <div className="mt-6 pt-6 border-t border-border text-xs text-muted-foreground">
            <p><strong>Name:</strong> {mediaItem?.name || file.name}</p>
            {mediaItem?.size && <p><strong>Size:</strong> {mediaItem.size}</p>}
            {mediaItem?.mimeType && <p><strong>Type:</strong> {mediaItem.mimeType}</p>}
            {file.createdAt && <p><strong>Created:</strong> {new Date(file.createdAt).toLocaleString()}</p>}
          </div>
        </div>
      </div>
    </div>
  );
};

// ── Asset preview card for brainstorm/media files ──
const AssetCard: React.FC<{ asset: any; onView: (asset: any) => void }> = ({ asset, onView }) => {
  const Icon = MIME_ICONS[asset.mimeCategory] ?? File;

  return (
    <div className="border border-border rounded-lg overflow-hidden bg-muted/20 hover:bg-muted/40 transition-colors">
      {/* Thumbnail */}
      {asset.mimeCategory === "image" && asset.dataUrl && (
        <div className="relative h-32 overflow-hidden bg-black/10 cursor-pointer group" onClick={() => onView(asset)}>
          <img src={asset.dataUrl} alt={asset.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center">
            <Eye size={24} className="text-white opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        </div>
      )}

      {asset.mimeCategory === "video" && asset.dataUrl && (
        <div className="relative h-32 overflow-hidden bg-black/10 cursor-pointer group" onClick={() => onView(asset)}>
          <video className="w-full h-full object-cover group-hover:scale-105 transition-transform">
            <source src={asset.dataUrl} />
          </video>
          <div className="absolute inset-0 bg-black/30 group-hover:bg-black/40 transition-colors flex items-center justify-center">
            <Film size={32} className="text-white" />
          </div>
        </div>
      )}

      {asset.mimeCategory === "audio" && (
        <div className="h-32 bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center cursor-pointer hover:from-primary/30 hover:to-primary/10 transition-colors group" onClick={() => onView(asset)}>
          <Music size={48} className="text-primary group-hover:scale-110 transition-transform" />
        </div>
      )}

      {!["image", "video", "audio"].includes(asset.mimeCategory) && (
        <div className="h-32 bg-muted/50 flex items-center justify-center cursor-pointer hover:bg-muted/70 transition-colors group" onClick={() => onView(asset)}>
          <Icon size={48} className="text-muted-foreground group-hover:scale-110 transition-transform" />
        </div>
      )}

      {/* Info */}
      <div className="p-3">
        <p className="text-xs font-medium truncate">{asset.name}</p>
        {asset.summary && <p className="text-xs text-muted-foreground truncate mt-1">{asset.summary}</p>}
        {asset.size && <p className="text-xs text-muted-foreground mt-1">{asset.size}</p>}
        <button
          onClick={() => onView(asset)}
          className="mt-2 w-full px-2 py-1.5 text-xs bg-primary text-primary-foreground rounded hover:bg-primary/90 transition-colors"
        >
          View
        </button>
      </div>
    </div>
  );
};

// ── Brainstorm file content viewer ──
const BrainstormFileContent: React.FC<{ file: SavedFile; onViewAsset: (asset: any) => void }> = ({ file, onViewAsset }) => {
  const session = file.data;
  const assets: any[] = session.assets ?? [];
  const notes: string = session.notes ?? "";

  if (assets.length === 0 && !notes) {
    return <p className="text-xs text-muted-foreground">No content.</p>;
  }

  return (
    <div className="flex flex-col gap-4">
      {assets.length > 0 && (
        <div>
          <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-3">Assets ({assets.length})</h3>
          <div className="grid grid-cols-2 gap-3">
            {assets.map((asset: any) => (
              <AssetCard key={asset.id} asset={asset} onView={onViewAsset} />
            ))}
          </div>
        </div>
      )}

      {notes && (
        <div>
          <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2">Notes</h3>
          <div className="bg-muted/50 p-4 rounded-lg text-sm text-foreground leading-relaxed whitespace-pre-wrap break-words">
            {notes}
          </div>
        </div>
      )}
    </div>
  );
};

// ── Integration sources content viewer ──
const IntegrationsFileContent: React.FC<{ file: SavedFile; onViewAsset: (asset: any) => void }> = ({ file, onViewAsset }) => {
  const sources: any[] = file.data.sources ?? [];

  if (sources.length === 0) {
    return <p className="text-xs text-muted-foreground">No sources.</p>;
  }

  return (
    <div className="flex flex-col gap-4">
      {sources.map((s: any, idx: number) => (
        <div key={s.id} className="border border-border rounded-lg p-4 bg-muted/20">
          <h4 className="text-sm font-bold text-foreground">{idx + 1}. {s.name}</h4>
          
          {s.analysis?.summary && (
            <div className="mt-2">
              <p className="text-xs font-semibold text-muted-foreground mb-1">Summary:</p>
              <p className="text-xs text-foreground leading-relaxed">{s.analysis.summary}</p>
            </div>
          )}

          {s.content && (
            <div className="mt-3 bg-muted/30 p-3 rounded text-xs text-foreground leading-relaxed whitespace-pre-wrap break-words max-h-40 overflow-y-auto">
              {s.content}
            </div>
          )}

          {s.analysis?.themes && (
            <div className="mt-2">
              <p className="text-xs font-semibold text-muted-foreground mb-1">Key Themes:</p>
              <div className="flex flex-wrap gap-1">
                {s.analysis.themes.map((theme: string, i: number) => (
                  <span key={i} className="px-2 py-0.5 bg-primary/20 text-primary text-xs rounded-full">
                    {theme}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

// ── Optimize session content viewer ──
const OptimizeFileContent: React.FC<{ file: SavedFile }> = ({ file }) => {
  const session = file.data;
  const steps: any[] = session.steps ?? [];

  if (steps.length === 0) {
    return <p className="text-xs text-muted-foreground">No action plan.</p>;
  }

  return (
    <div className="flex flex-col gap-3">
      <div className="mb-2">
        {session.title && <h3 className="text-sm font-bold text-foreground">{session.title}</h3>}
        {session.summary && <p className="text-xs text-muted-foreground mt-1">{session.summary}</p>}
      </div>

      {steps.map((step: any, idx: number) => (
        <div key={step.id} className="border border-border rounded-lg p-3 bg-muted/20">
          <h4 className="font-semibold text-sm text-foreground">
            Step {idx + 1}: {step.title}
          </h4>
          <p className="text-xs text-foreground mt-2 leading-relaxed">{step.description}</p>

          {step.substeps && step.substeps.length > 0 && (
            <ul className="mt-2 ml-3 space-y-1">
              {step.substeps.map((sub: any) => (
                <li key={sub.id} className="text-xs text-muted-foreground flex gap-1">
                  <span className="text-primary">•</span>
                  <span>{sub.text}</span>
                </li>
              ))}
            </ul>
          )}

          {step.dataReferences && step.dataReferences.length > 0 && (
            <div className="mt-2 text-xs text-muted-foreground">
              <p className="font-semibold mb-1">References:</p>
              <ul className="ml-2 space-y-0.5">
                {step.dataReferences.map((ref: string, i: number) => (
                  <li key={i}>• {ref}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

// ── Ecosystem content viewer ──
const EcosystemFileContent: React.FC<{ file: SavedFile }> = ({ file }) => {
  const session = file.data;
  const nodes: any[] = session.nodes ?? session.requests ?? [];

  if (nodes.length === 0) {
    return <p className="text-xs text-muted-foreground">No ecosystem nodes.</p>;
  }

  return (
    <div className="flex flex-col gap-3">
      {nodes.map((node: any, idx: number) => (
        <div key={node.id} className="border border-border rounded-lg p-3 bg-muted/20">
          <h4 className="font-semibold text-sm text-foreground">{idx + 1}. {node.name || node.label}</h4>
          {node.description && <p className="text-xs text-muted-foreground mt-1">{node.description}</p>}
          {node.type && <p className="text-xs text-muted-foreground mt-1"><strong>Type:</strong> {node.type}</p>}
          {node.status && <p className="text-xs text-muted-foreground"><strong>Status:</strong> {node.status}</p>}
        </div>
      ))}
    </div>
  );
};

// ── Main FilesPanel component ──
const FilesPanel: React.FC<FilesPanelProps> = ({ files, onOpenFile, onDeleteFile }) => {
  const [openIds, setOpenIds] = useState<Set<string>>(new Set());
  const [viewingAsset, setViewingAsset] = useState<{ file: SavedFile; asset?: any } | null>(null);

  const toggleOpen = (id: string) => {
    setOpenIds((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  if (files.length === 0) {
    return (
      <div className="flex flex-col h-full items-center justify-center px-6 text-center">
        <FolderOpen size={32} className="text-muted-foreground mb-2" />
        <h2 className="text-base font-semibold">Inventory</h2>
        <p className="text-xs text-muted-foreground mt-1">Saved items will appear here automatically as you add content.</p>
      </div>
    );
  }

  return (
    <>
      <div className="flex flex-col h-full overflow-y-auto p-3 gap-2">
        {files.map((file) => {
          const isOpen = openIds.has(file.id);
          const Icon = TYPE_ICONS[file.type] ?? File;

          return (
            <div key={file.id} className="border border-border rounded-lg overflow-hidden bg-card">
              {/* File header */}
              <div
                className="flex items-center gap-2 px-3 py-2 bg-muted/30 cursor-pointer select-none hover:bg-muted/50 transition-colors"
                onClick={() => toggleOpen(file.id)}
              >
                <ChevronRight size={12} className={`flex-shrink-0 text-muted-foreground transition-transform duration-150 ${isOpen ? "rotate-90" : ""}`} />
                <Icon size={11} className="text-primary flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium truncate">{file.name}</p>
                  <p className="text-xs text-muted-foreground">{TYPE_LABELS[file.type] ?? file.type}</p>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteFile(file.id);
                  }}
                  className="flex-shrink-0 w-4 h-4 rounded flex items-center justify-center text-muted-foreground hover:bg-destructive/20 hover:text-destructive transition-colors"
                  title="Delete file"
                >
                  <X size={10} />
                </button>
              </div>

              {/* File content - expanded view */}
              {isOpen && (
                <div className="border-t border-border p-4 max-h-[400px] overflow-y-auto bg-card/50">
                  {file.type === "brainstorm" && (
                    <BrainstormFileContent file={file} onViewAsset={(asset) => setViewingAsset({ file, asset })} />
                  )}

                  {file.type === "integrations" && (
                    <IntegrationsFileContent file={file} onViewAsset={(asset) => setViewingAsset({ file, asset })} />
                  )}

                  {file.type === "optimize" && (
                    <OptimizeFileContent file={file} />
                  )}

                  {file.type === "ecosystem" && (
                    <EcosystemFileContent file={file} />
                  )}

                  {file.type === "bundle" && file.data && (
                    <div className="text-xs text-foreground leading-relaxed space-y-2">
                      <p><strong>Layout Snapshot</strong></p>
                      {file.data.visibleTools && (
                        <p>Active Tools: {(file.data.visibleTools as string[]).join(", ")}</p>
                      )}
                      {file.data.workspaceTabs && (
                        <p>Tabs: {file.data.workspaceTabs.length}</p>
                      )}
                      <p className="text-muted-foreground mt-2">Created: {new Date(file.createdAt).toLocaleString()}</p>
                    </div>
                  )}

                  {file.type === "tool" && file.data && (
                    <div className="text-xs text-foreground leading-relaxed space-y-2">
                      {Object.entries(file.data).map(([key, value]: [string, any]) => {
                        if (typeof value === "string" && value.trim()) {
                          return (
                            <div key={key}>
                              <p className="font-semibold text-xs capitalize">{key.replace(/([A-Z])/g, " $1")}</p>
                              <p className="text-muted-foreground whitespace-pre-wrap break-words">{value}</p>
                            </div>
                          );
                        }
                        return null;
                      })}
                    </div>
                  )}

                  {file.type === "closed-item" && (
                    <div className="text-xs text-muted-foreground">
                      <p>Archived: {new Date(file.createdAt).toLocaleString()}</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Media viewer modal */}
      {viewingAsset && (
        <MediaViewerModal file={viewingAsset.file} asset={viewingAsset.asset} onClose={() => setViewingAsset(null)} />
      )}
    </>
  );
};

export default FilesPanel;
