export interface SourceItem {
  id: string;
  name: string;
  type: string;
  checked: boolean;
  addedAt: Date;
}
