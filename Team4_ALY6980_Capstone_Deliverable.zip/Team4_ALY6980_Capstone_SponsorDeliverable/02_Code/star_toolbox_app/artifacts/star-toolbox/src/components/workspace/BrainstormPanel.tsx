import React, { useState, useRef, useCallback } from "react";
import { ChevronRight, X, Upload, FileText, Image, Film, Music, Table, File } from "lucide-react";

export interface StaticAsset {
  id: string;
  name: string;
  ext: string;
  mimeCategory: "document" | "spreadsheet" | "image" | "video" | "audio" | "other";
  size?: string;
  addedAt: Date;
  content?: string;
  dataUrl?: string;
  status: "ready" | "processing" | "error";
  summary?: string;
}

export interface BrainstormSession {
  id: string;
  title: string;
  assets: StaticAsset[];
  notes: string;
  createdAt: Date;
  updatedAt: Date;
}

interface BrainstormPanelProps {
  session: BrainstormSession;
  onUpdateSession: (updater: BrainstormSession | ((prev: BrainstormSession) => BrainstormSession)) => void;
  activeOptions: Set<string>;
  onUncheck: (opt: string) => void;
}

const OPTIONS = ["Files", "Notes"];

const ACCEPTED = [
  ".pdf",".doc",".docx",".ppt",".pptx",".txt",".md",".rtf",
  ".csv",".xlsx",".xls",".tsv",
  ".jpg",".jpeg",".png",".gif",".webp",".svg",".bmp",".tiff",
  ".mp4",".webm",".mov",".avi",".mkv",
  ".mp3",".wav",".ogg",".m4a",".flac",".aac",
].join(",");

const TEXT_EXTS    = new Set(["txt","md","rtf","json","xml","yaml","yml","html","htm","sql","css","js","ts"]);
const SPREADSHEET_EXTS = new Set(["csv","xls","tsv"]);
const IMAGE_EXTS   = new Set(["jpg","jpeg","png","gif","webp","svg","bmp","tiff"]);
const VIDEO_EXTS   = new Set(["mp4","webm","mov","avi","mkv"]);
const AUDIO_EXTS   = new Set(["mp3","wav","ogg","m4a","flac","aac"]);
const DOCUMENT_EXTS = new Set(["pdf","doc","docx","ppt","pptx","txt","md","rtf","xlsx"]);

function getMimeCategory(ext: string): StaticAsset["mimeCategory"] {
  if (IMAGE_EXTS.has(ext))      return "image";
  if (VIDEO_EXTS.has(ext))      return "video";
  if (AUDIO_EXTS.has(ext))      return "audio";
  if (SPREADSHEET_EXTS.has(ext)) return "spreadsheet";
  if (DOCUMENT_EXTS.has(ext))   return "document";
  return "other";
}

function formatSize(bytes: number): string {
  if (bytes < 1024)           return `${bytes} B`;
  if (bytes < 1024 * 1024)    return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

const CATEGORY_ICONS: Record<string, React.ComponentType<{ size: number; className?: string }>> = {
  document: FileText, spreadsheet: Table, image: Image, video: Film, audio: Music, other: File,
};

const BrainstormPanel: React.FC<BrainstormPanelProps> = ({ session, onUpdateSession, activeOptions, onUncheck }) => {
  const [openCards, setOpenCards] = useState<Set<string>>(new Set());
  const fileInputRef = useRef<HTMLInputElement>(null);

  const toggleCard = (opt: string) => {
    setOpenCards((prev) => {
      const next = new Set(prev);
      next.has(opt) ? next.delete(opt) : next.add(opt);
      return next;
    });
  };

  const updateAsset = useCallback((id: string, updates: Partial<StaticAsset>) => {
    onUpdateSession((prev) => ({
      ...prev,
      assets: prev.assets.map((a) => a.id === id ? { ...a, ...updates } : a),
      updatedAt: new Date(),
    }));
  }, [onUpdateSession]);

  const processFile = useCallback(async (file: globalThis.File, assetId: string, cat: StaticAsset["mimeCategory"], ext: string) => {
    if (cat === "image") {
      const reader = new FileReader();
      reader.onload = (ev) => updateAsset(assetId, { status: "ready", dataUrl: ev.target?.result as string });
      reader.onerror = () => updateAsset(assetId, { status: "error" });
      reader.readAsDataURL(file);
      return;
    }
    if (cat === "video" || cat === "audio") {
      updateAsset(assetId, { status: "ready" });
      return;
    }
    if (TEXT_EXTS.has(ext) || SPREADSHEET_EXTS.has(ext) || DOCUMENT_EXTS.has(ext)) {
      try {
        const text: string = await new Promise((resolve, reject) => {
          const r = new FileReader();
          r.onload = (e) => resolve((e.target?.result as string) ?? "");
          r.onerror = reject;
          r.readAsText(file);
        });
        const words = text.trim().split(/\s+/).filter(Boolean).length;
        const lines = text.split("\n").filter((l) => l.trim()).length;
        const summary = `${words.toLocaleString()} words · ${lines} lines`;
        updateAsset(assetId, { status: "ready", content: text, summary });
      } catch {
        updateAsset(assetId, { status: "error" });
      }
      return;
    }
    updateAsset(assetId, { status: "ready" });
  }, [updateAsset]);

  const handleFiles = useCallback((files: FileList | null) => {
    if (!files) return;
    Array.from(files).forEach((file) => {
      const ext = file.name.split(".").pop()?.toLowerCase() ?? "unknown";
      const cat = getMimeCategory(ext);
      const assetId = crypto.randomUUID();
      onUpdateSession((prev) => ({
        ...prev,
        assets: [...prev.assets, {
          id: assetId, name: file.name, ext, mimeCategory: cat,
          size: formatSize(file.size), addedAt: new Date(), status: "processing" as const,
        }],
        updatedAt: new Date(),
      }));
      processFile(file, assetId, cat, ext);
    });
  }, [onUpdateSession, processFile]);

  const removeAsset = useCallback((id: string) => {
    onUpdateSession((prev) => ({
      ...prev,
      assets: prev.assets.filter((a) => a.id !== id),
      updatedAt: new Date(),
    }));
  }, [onUpdateSession]);

  const visibleOptions = OPTIONS.filter((o) => activeOptions.has(o));
  const isEmpty = visibleOptions.length === 0;

  return (
    <div className="flex flex-col h-full overflow-y-auto">
      <input
        ref={fileInputRef} type="file" multiple accept={ACCEPTED} className="hidden"
        onChange={(e) => handleFiles(e.target.files)}
      />
      {isEmpty ? (
        <div className="flex-1 flex items-center justify-center px-6 text-center">
          <div>
            <h2 className="text-base font-semibold">Brainstorm</h2>
            <p className="text-xs text-muted-foreground mt-1">Select an option from the dropdown above to get started.</p>
          </div>
        </div>
      ) : (
        <div className="p-3 flex flex-col gap-2">
          {visibleOptions.map((opt) => {
            const isOpen = openCards.has(opt);
            return (
              <div key={opt} className="border border-border rounded-lg overflow-hidden">
                <div
                  className="flex items-center gap-2 px-3 py-2 bg-muted/30 cursor-pointer select-none"
                  onClick={() => toggleCard(opt)}
                >
                  <ChevronRight size={12} className={`flex-shrink-0 text-muted-foreground transition-transform duration-150 ${isOpen ? "rotate-90" : ""}`} />
                  <span className="text-xs font-medium flex-1">{opt}</span>
                  <button
                    onClick={(e) => { e.stopPropagation(); onUncheck(opt); }}
                    className="flex-shrink-0 w-4 h-4 rounded flex items-center justify-center text-muted-foreground hover:bg-destructive/20 hover:text-destructive transition-colors"
                  >
                    <X size={10} />
                  </button>
                </div>
                {isOpen && (
                  <div className="border-t border-border">
                    {opt === "Files" && (
                      <div className="p-3 flex flex-col gap-2">
                        <button
                          onClick={() => fileInputRef.current?.click()}
                          className="flex items-center gap-2 px-3 py-2 text-xs border border-dashed border-border rounded-lg hover:bg-muted transition-colors w-full justify-center text-muted-foreground"
                        >
                          <Upload size={12} /> Upload files
                        </button>
                        {session.assets.length === 0 ? (
                          <p className="text-xs text-muted-foreground text-center py-1">No files uploaded yet.</p>
                        ) : (
                          <ul className="flex flex-col gap-1">
                            {session.assets.map((asset) => {
                              const Icon = CATEGORY_ICONS[asset.mimeCategory] ?? File;
                              return (
                                <li key={asset.id} className="flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-muted group">
                                  <Icon size={12} className="text-muted-foreground flex-shrink-0" />
                                  <span className="text-xs flex-1 truncate">{asset.name}</span>
                                  {asset.size && <span className="text-xs text-muted-foreground flex-shrink-0">{asset.size}</span>}
                                  <button
                                    onClick={() => removeAsset(asset.id)}
                                    className="opacity-0 group-hover:opacity-100 w-4 h-4 rounded flex items-center justify-center text-muted-foreground hover:text-destructive transition-colors"
                                  >
                                    <X size={10} />
                                  </button>
                                </li>
                              );
                            })}
                          </ul>
                        )}
                      </div>
                    )}
                    {opt === "Notes" && (
                      <div className="p-3">
                        <textarea
                          value={session.notes ?? ""}
                          onChange={(e) => onUpdateSession((prev) => ({ ...prev, notes: e.target.value, updatedAt: new Date() }))}
                          placeholder="Type your notes here…"
                          className="w-full min-h-[120px] text-xs p-2 border border-border rounded-md bg-background resize-none focus:outline-none focus:ring-1 focus:ring-primary"
                        />
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default BrainstormPanel;
