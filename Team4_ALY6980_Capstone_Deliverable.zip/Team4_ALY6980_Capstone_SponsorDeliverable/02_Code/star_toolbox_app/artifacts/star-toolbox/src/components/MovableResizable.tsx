import React, { useState, useCallback, useRef } from "react";
import { GripVertical } from "lucide-react";

interface Size {
  width: number;
  height: number;
}

interface Position {
  x: number;
  y: number;
}

interface MovableResizableProps {
  id: string;
  position: Position;
  size?: Size;
  minWidth?: number;
  minHeight?: number;
  onMove: (id: string, pos: Position) => void;
  onResize?: (id: string, size: Size) => void;
  children: React.ReactNode;
  resizable?: boolean;
  locked?: boolean;
  className?: string;
  showGrip?: boolean;
}

type ResizeDir = "n" | "s" | "e" | "w" | "ne" | "nw" | "se" | "sw";

const HANDLE_CURSORS: Record<ResizeDir, string> = {
  n: "cursor-n-resize",
  s: "cursor-s-resize",
  e: "cursor-e-resize",
  w: "cursor-w-resize",
  ne: "cursor-ne-resize",
  nw: "cursor-nw-resize",
  se: "cursor-se-resize",
  sw: "cursor-sw-resize",
};

const MovableResizable: React.FC<MovableResizableProps> = ({
  id,
  position,
  size,
  minWidth = 60,
  minHeight = 40,
  onMove,
  onResize,
  children,
  resizable = false,
  locked = false,
  className = "",
  showGrip = true,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const dragRef = useRef<{
    startX: number;
    startY: number;
    origX: number;
    origY: number;
  } | null>(null);
  const resizeRef = useRef<{
    dir: ResizeDir;
    startX: number;
    startY: number;
    origX: number;
    origY: number;
    origW: number;
    origH: number;
  } | null>(null);
  const elRef = useRef<HTMLDivElement>(null);

  // --- DRAG (only from grip handle) ---
  const onGripDragStart = useCallback(
    (e: React.PointerEvent) => {
      if (locked) return;
      e.preventDefault();
      e.stopPropagation();
      setIsDragging(true);
      dragRef.current = {
        startX: e.clientX,
        startY: e.clientY,
        origX: position.x,
        origY: position.y,
      };
      (e.target as HTMLElement).setPointerCapture?.(e.pointerId);

      const onMove = (ev: PointerEvent) => {
        if (!dragRef.current) return;
        const dx = ev.clientX - dragRef.current.startX;
        const dy = ev.clientY - dragRef.current.startY;
        const newX = Math.max(0, dragRef.current.origX + dx);
        const newY = Math.max(0, dragRef.current.origY + dy);
        window.dispatchEvent(
          new CustomEvent("movable-move", {
            detail: { id, x: newX, y: newY },
          })
        );
      };

      const onUp = () => {
        setIsDragging(false);
        dragRef.current = null;
        window.removeEventListener("pointermove", onMove);
        window.removeEventListener("pointerup", onUp);
      };

      window.addEventListener("pointermove", onMove);
      window.addEventListener("pointerup", onUp);
    },
    [id, position, locked]
  );

  // --- RESIZE ---
  const onResizeStart = useCallback(
    (dir: ResizeDir, e: React.PointerEvent) => {
      if (locked) return;
      e.preventDefault();
      e.stopPropagation();
      if (!size) return;
      setIsResizing(true);
      resizeRef.current = {
        dir,
        startX: e.clientX,
        startY: e.clientY,
        origX: position.x,
        origY: position.y,
        origW: size.width,
        origH: size.height,
      };

      const onMove = (ev: PointerEvent) => {
        if (!resizeRef.current) return;
        const r = resizeRef.current;
        const dx = ev.clientX - r.startX;
        const dy = ev.clientY - r.startY;

        let newW = r.origW;
        let newH = r.origH;
        let newX = r.origX;
        let newY = r.origY;

        if (r.dir.includes("e")) newW = Math.max(minWidth, r.origW + dx);
        if (r.dir.includes("w")) {
          newW = Math.max(minWidth, r.origW - dx);
          newX = r.origX + (r.origW - newW);
        }
        if (r.dir.includes("s")) newH = Math.max(minHeight, r.origH + dy);
        if (r.dir.includes("n")) {
          newH = Math.max(minHeight, r.origH - dy);
          newY = r.origY + (r.origH - newH);
        }

        window.dispatchEvent(
          new CustomEvent("movable-move", {
            detail: { id, x: newX, y: newY },
          })
        );
        window.dispatchEvent(
          new CustomEvent("movable-resize", {
            detail: { id, width: newW, height: newH },
          })
        );
      };

      const onUp = () => {
        setIsResizing(false);
        resizeRef.current = null;
        window.removeEventListener("pointermove", onMove);
        window.removeEventListener("pointerup", onUp);
      };

      window.addEventListener("pointermove", onMove);
      window.addEventListener("pointerup", onUp);
    },
    [id, position, size, minWidth, minHeight, locked]
  );

  const style: React.CSSProperties = {
    position: "absolute",
    left: position.x,
    top: position.y,
    ...(size ? { width: size.width, height: size.height } : {}),
    zIndex: isDragging || isResizing ? 50 : 1,
    userSelect: "none",
    touchAction: "none",
  };

  const handles: ResizeDir[] = ["n", "s", "e", "w", "ne", "nw", "se", "sw"];

  return (
    <div ref={elRef} style={style} className={`group/movable ${className}`}>
      {/* Left-side grip handle — exclusive drag trigger */}
      {showGrip && !locked && (
        <div
          data-grip-handle="true"
          onPointerDown={onGripDragStart}
          className="absolute left-0 top-0 h-full w-5 flex items-center justify-center cursor-grab active:cursor-grabbing z-20 opacity-0 group-hover/movable:opacity-60 hover:!opacity-100 transition-opacity"
          style={{ transform: "translateX(-100%)" }}
        >
          <GripVertical size={14} className="text-muted-foreground" />
        </div>
      )}
      {children}
      {resizable && size && !locked && (
        <>
          {handles.map((dir) => {
            const isCorner = dir.length === 2;
            const s = isCorner ? 10 : 6;
            const pos: React.CSSProperties = {};

            if (dir.includes("n")) pos.top = -s / 2;
            if (dir.includes("s")) pos.bottom = -s / 2;
            if (dir.includes("e")) pos.right = -s / 2;
            if (dir.includes("w")) pos.left = -s / 2;
            if (dir === "n" || dir === "s") {
              pos.left = "50%";
              pos.transform = "translateX(-50%)";
            }
            if (dir === "e" || dir === "w") {
              pos.top = "50%";
              pos.transform = "translateY(-50%)";
            }

            return (
              <div
                key={dir}
                data-resize-handle="true"
                onPointerDown={(e) => onResizeStart(dir, e)}
                className={`absolute opacity-0 group-hover/movable:opacity-100 transition-opacity bg-primary rounded-full border border-primary-foreground ${HANDLE_CURSORS[dir]}`}
                style={{
                  width: s,
                  height: s,
                  ...pos,
                  zIndex: 60,
                }}
              />
            );
          })}
        </>
      )}
    </div>
  );
};

export default MovableResizable;
