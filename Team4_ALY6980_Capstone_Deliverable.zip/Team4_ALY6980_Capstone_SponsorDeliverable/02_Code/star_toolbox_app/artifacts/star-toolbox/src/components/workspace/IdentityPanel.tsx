import React, { useState } from "react";
import { ChevronRight, X } from "lucide-react";

export interface IdentitySession {
  id: string;
  projectName: string;
  mission: string;
  audience: string;
  values: string;
  differentiators: string;
  updatedAt: Date;
}

interface IdentityPanelProps {
  session: IdentitySession;
  onUpdateSession: (session: IdentitySession) => void;
  activeOptions: Set<string>;
  onUncheck: (opt: string) => void;
}

const IdentityPanel: React.FC<IdentityPanelProps> = ({ session, activeOptions, onUncheck }) => {
  const [openCards, setOpenCards] = useState<Set<string>>(new Set());

  const toggleCard = (opt: string) => {
    setOpenCards((prev) => {
      const next = new Set(prev);
      next.has(opt) ? next.delete(opt) : next.add(opt);
      return next;
    });
  };

  const visibleOptions = Array.from(activeOptions);
  const isEmpty = visibleOptions.length === 0;

  return (
    <div className="flex flex-col h-full overflow-y-auto">
      {isEmpty ? (
        <div className="flex-1 flex items-center justify-center px-6 text-center">
          <div>
            <h2 className="text-base font-semibold">Identity</h2>
            <p className="text-xs text-muted-foreground mt-1">Identity fields will appear here once analysis is complete.</p>
          </div>
        </div>
      ) : (
        <div className="p-3 flex flex-col gap-2">
          {visibleOptions.map((opt) => {
            const isOpen = openCards.has(opt);
            return (
              <div key={opt} className="border border-border rounded-lg overflow-hidden">
                <div
                  className="flex items-center gap-2 px-3 py-2 bg-muted/30 cursor-pointer select-none"
                  onClick={() => toggleCard(opt)}
                >
                  <ChevronRight size={12} className={`flex-shrink-0 text-muted-foreground transition-transform duration-150 ${isOpen ? "rotate-90" : ""}`} />
                  <span className="text-xs font-medium flex-1">{opt}</span>
                  <button
                    onClick={(e) => { e.stopPropagation(); onUncheck(opt); }}
                    className="flex-shrink-0 w-4 h-4 rounded flex items-center justify-center text-muted-foreground hover:bg-destructive/20 hover:text-destructive transition-colors"
                  >
                    <X size={10} />
                  </button>
                </div>
                {isOpen && (
                  <div className="border-t border-border px-3 py-2 text-xs text-muted-foreground">
                    No items yet.
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default IdentityPanel;
