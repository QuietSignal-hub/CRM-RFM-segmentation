import React from "react";
import { LucideIcon, X } from "lucide-react";

interface ToolbarButtonProps {
  icon: LucideIcon;
  label: string;
  onClick?: () => void;
  onClose?: () => void;
  variant?: "default" | "primary";
}

const ToolbarButton: React.FC<ToolbarButtonProps> = ({
  icon: Icon,
  label,
  onClick,
  onClose,
  variant = "default",
}) => {
  const base =
    variant === "primary"
      ? "bg-primary text-primary-foreground hover:opacity-90"
      : "bg-card text-foreground border border-border hover:bg-secondary";

  return (
    <div className="relative">
      {onClose && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onClose();
          }}
          className="absolute -top-2 -right-2 z-10 w-5 h-5 rounded-full bg-card border border-border flex items-center justify-center opacity-0 group-hover/movable:opacity-100 transition-opacity text-xs hover:bg-destructive hover:text-destructive-foreground hover:border-destructive"
        >
          <X size={10} />
        </button>
      )}
      <button
        onClick={onClick}
        className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all shadow-sm ${base}`}
      >
        <Icon size={16} />
        {label}
      </button>
    </div>
  );
};

export default ToolbarButton;
