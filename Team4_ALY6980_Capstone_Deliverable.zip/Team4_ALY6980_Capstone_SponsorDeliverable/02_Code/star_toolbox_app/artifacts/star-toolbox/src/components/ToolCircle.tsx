import React from "react";
import { LucideIcon, X } from "lucide-react";

interface ToolCircleProps {
  icon: LucideIcon;
  label: string;
  onClick?: () => void;
  onClose?: () => void;
}

const ToolCircle: React.FC<ToolCircleProps> = ({ icon: Icon, label, onClick, onClose }) => {
  return (
    <div className="relative flex flex-col items-center gap-2">
      {onClose && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onClose();
          }}
          className="absolute -top-1 -right-1 z-10 w-5 h-5 rounded-full bg-card border border-border flex items-center justify-center opacity-0 group-hover/movable:opacity-100 transition-opacity hover:bg-destructive hover:text-destructive-foreground hover:border-destructive"
        >
          <X size={10} />
        </button>
      )}
      <button
        onClick={onClick}
        className="w-24 h-24 rounded-full bg-primary flex items-center justify-center shadow-md hover:shadow-lg transition-shadow hover:scale-105 active:scale-95 transition-transform"
      >
        <Icon size={36} className="text-primary-foreground" />
      </button>
      <span className="text-sm font-medium text-foreground">{label}</span>
    </div>
  );
};

export default ToolCircle;
