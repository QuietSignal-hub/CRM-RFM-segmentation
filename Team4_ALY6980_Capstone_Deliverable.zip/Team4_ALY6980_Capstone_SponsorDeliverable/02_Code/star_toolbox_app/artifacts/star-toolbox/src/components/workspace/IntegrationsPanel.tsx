import React, { useState } from "react";
import { ChevronRight, X } from "lucide-react";

export interface DataSource {
  id: string;
  name: string;
  type: string;
  status: "ready" | "processing" | "error";
  addedAt: Date;
  content?: string;
  analysis?: SourceAnalysis;
}

export interface SourceAnalysis {
  wordCount: number;
  lineCount?: number;
  topKeywords: string[];
  summary: string;
  structure?: string;
}

export interface IntegrationSession {
  id: string;
  sources: DataSource[];
  createdAt: Date;
  updatedAt: Date;
}

interface IntegrationsPanelProps {
  session: IntegrationSession;
  onUpdateSession: (updater: IntegrationSession | ((prev: IntegrationSession) => IntegrationSession)) => void;
  activeOptions: Set<string>;
  onUncheck: (opt: string) => void;
}

const OPTIONS = ["URLs", "API Keys", "Databases"];

const IntegrationsPanel: React.FC<IntegrationsPanelProps> = ({ session, onUpdateSession, activeOptions, onUncheck }) => {
  const [openCards, setOpenCards] = useState<Set<string>>(new Set());

  const toggleCard = (opt: string) => {
    setOpenCards((prev) => {
      const next = new Set(prev);
      next.has(opt) ? next.delete(opt) : next.add(opt);
      return next;
    });
  };

  const visibleOptions = OPTIONS.filter((o) => activeOptions.has(o));
  const isEmpty = visibleOptions.length === 0;

  const getSourcesForType = (opt: string): DataSource[] => {
    const typeMap: Record<string, string[]> = {
      "URLs": ["url", "rss", "website"],
      "API Keys": ["api", "apikey"],
      "Databases": ["database", "db"],
    };
    const types = typeMap[opt] ?? [];
    return session.sources.filter((s) => types.includes(s.type));
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto">
      {isEmpty ? (
        <div className="flex-1 flex items-center justify-center px-6 text-center">
          <div>
            <h2 className="text-base font-semibold">Integrations</h2>
            <p className="text-xs text-muted-foreground mt-1">Connect live data sources — URLs, API keys, and databases — to pull real-time content into your workspace.</p>
          </div>
        </div>
      ) : (
        <div className="p-3 flex flex-col gap-2">
          {visibleOptions.map((opt) => {
            const isOpen = openCards.has(opt);
            const sources = getSourcesForType(opt);
            return (
              <div key={opt} className="border border-border rounded-lg overflow-hidden">
                <div
                  className="flex items-center gap-2 px-3 py-2 bg-muted/30 cursor-pointer select-none"
                  onClick={() => toggleCard(opt)}
                >
                  <ChevronRight
                    size={12}
                    className={`flex-shrink-0 text-muted-foreground transition-transform duration-150 ${isOpen ? "rotate-90" : ""}`}
                  />
                  <span className="text-xs font-medium flex-1">{opt}</span>
                  <button
                    onClick={(e) => { e.stopPropagation(); onUncheck(opt); }}
                    className="flex-shrink-0 w-4 h-4 rounded flex items-center justify-center text-muted-foreground hover:bg-destructive/20 hover:text-destructive transition-colors"
                  >
                    <X size={10} />
                  </button>
                </div>
                {isOpen && (
                  <div className="px-3 py-2 border-t border-border text-xs text-muted-foreground">
                    {sources.length === 0
                      ? <span>No {opt.toLowerCase()} connected yet.</span>
                      : <ul className="space-y-1">{sources.map((s) => <li key={s.id}>{s.name}</li>)}</ul>
                    }
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default IntegrationsPanel;
