import React, { useState, useRef, useEffect } from "react";
import {
  X, Save, User, Layers, Link, Lightbulb, Zap, Globe, Star, FolderOpen,
  LucideIcon, Search, MoreHorizontal, Sparkles, Lock, Unlock, ChevronDown, ShieldCheck,
} from "lucide-react";
import BrainstormPanel, { BrainstormSession } from "./workspace/BrainstormPanel";
import IntegrationsPanel, { IntegrationSession } from "./workspace/IntegrationsPanel";
import OptimizePanel, { OptimizeSession } from "./workspace/OptimizePanel";
import FilesPanel, { SavedFile } from "./workspace/FilesPanel";
import EcosystemPanel, { EcosystemSession } from "./workspace/EcosystemPanel";
import IdentityPanel, { IdentitySession } from "./workspace/IdentityPanel";
import FrameworksPanel, { FrameworksSession } from "./workspace/FrameworksPanel";
import RecommendationsPanel, { RecommendationsSession } from "./workspace/RecommendationsPanel";
import CompliancePanel from "./workspace/CompliancePanel";

export interface WorkspaceTab {
  id: string;
  label: string;
  type: "tool" | "files" | "brainstorm" | "integrations" | "optimize" | "ecosystem" | "identity" | "frameworks" | "recommendations" | "compliance";
}

const TAB_ICONS: Record<string, LucideIcon> = {
  identity: User, frameworks: Layers, integrations: Link, brainstorm: Lightbulb,
  optimize: Zap, ecosystem: Globe, recommendations: Star, inventory: FolderOpen,
  compliance: ShieldCheck,
};

interface WorkspaceCanvasProps {
  tabs: WorkspaceTab[];
  onCloseTab: (id: string) => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  isLocked: boolean;
  onToggleLock: () => void;
  onTidy: () => void;
  onSaveLayout: () => void;
  brainstormSession: BrainstormSession;
  onUpdateBrainstorm: (s: BrainstormSession) => void;
  integrationSession: IntegrationSession;
  onUpdateIntegrations: (s: IntegrationSession) => void;
  optimizeSession: OptimizeSession;
  onUpdateOptimize: (s: OptimizeSession) => void;
  ecosystemSession: EcosystemSession;
  onUpdateEcosystem: (s: EcosystemSession) => void;
  identitySession: IdentitySession;
  onUpdateIdentity: (s: IdentitySession) => void;
  frameworksSession: FrameworksSession;
  onUpdateFrameworks: (s: FrameworksSession) => void;
  recommendationsSession: RecommendationsSession;
  onUpdateRecommendations: (s: RecommendationsSession) => void;
  savedFiles: SavedFile[];
  onOpenFile: (file: SavedFile) => void;
  onDeleteFile: (id: string) => void;
  onSaveCurrentWork: () => void;
}

const PANEL_OPTIONS: Partial<Record<string, string[]>> = {
  brainstorm: ["Files", "Notes"],
  integrations: ["URLs", "API Keys", "Databases"],
};

const PANEL_SORT: Partial<Record<string, string[]>> = {
  files: ["A to Z", "Date", "File Type"],
};

const WorkspaceCanvas: React.FC<WorkspaceCanvasProps> = ({
  tabs, onCloseTab,
  searchQuery, onSearchChange,
  isLocked, onToggleLock, onTidy, onSaveLayout,
  brainstormSession, onUpdateBrainstorm,
  integrationSession, onUpdateIntegrations,
  optimizeSession, onUpdateOptimize,
  ecosystemSession, onUpdateEcosystem,
  identitySession, onUpdateIdentity,
  frameworksSession, onUpdateFrameworks,
  recommendationsSession, onUpdateRecommendations,
  savedFiles, onOpenFile, onDeleteFile, onSaveCurrentWork,
}) => {
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const [checkedOptions, setCheckedOptions] = useState<Record<string, Set<string>>>({});
  const [sortSelections, setSortSelections] = useState<Record<string, string>>({});
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!menuOpen) return;
    const handler = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [menuOpen]);

  useEffect(() => {
    if (!openDropdown) return;
    const handler = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) setOpenDropdown(null);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [openDropdown]);

  const getChecked = (type: string): Set<string> => {
    if (checkedOptions[type]) return checkedOptions[type];
    return new Set(PANEL_OPTIONS[type] ?? []);
  };

  const toggleAll = (type: string) => {
    const opts = PANEL_OPTIONS[type] ?? [];
    const current = getChecked(type);
    const allChecked = opts.every((o) => current.has(o));
    setCheckedOptions((prev) => ({ ...prev, [type]: allChecked ? new Set() : new Set(opts) }));
  };

  const toggleOne = (type: string, opt: string) => {
    const next = new Set(getChecked(type));
    next.has(opt) ? next.delete(opt) : next.add(opt);
    setCheckedOptions((prev) => ({ ...prev, [type]: next }));
  };

  const menuAction = (fn: () => void) => { fn(); setMenuOpen(false); };

  const renderPanel = (tab: WorkspaceTab) => {
    switch (tab.type) {
      case "brainstorm":
        return (
          <BrainstormPanel
            session={brainstormSession}
            onUpdateSession={onUpdateBrainstorm}
            activeOptions={getChecked("brainstorm")}
            onUncheck={(opt) => toggleOne("brainstorm", opt)}
          />
        );
      case "integrations":
        return (
          <IntegrationsPanel
            session={integrationSession}
            onUpdateSession={onUpdateIntegrations}
            activeOptions={getChecked("integrations")}
            onUncheck={(opt) => toggleOne("integrations", opt)}
          />
        );
      case "optimize":
        return (
          <OptimizePanel
            session={optimizeSession} onUpdateSession={onUpdateOptimize}
            brainstormSession={brainstormSession} integrationSession={integrationSession}
            savedFiles={savedFiles}
            activeOptions={getChecked("optimize")}
            onUncheck={(opt) => toggleOne("optimize", opt)}
          />
        );
      case "ecosystem":
        return (
          <EcosystemPanel
            session={ecosystemSession} onUpdateSession={onUpdateEcosystem}
            activeOptions={getChecked("ecosystem")}
            onUncheck={(opt) => toggleOne("ecosystem", opt)}
          />
        );
      case "identity":
        return (
          <IdentityPanel
            session={identitySession} onUpdateSession={onUpdateIdentity}
            activeOptions={getChecked("identity")}
            onUncheck={(opt) => toggleOne("identity", opt)}
          />
        );
      case "frameworks":
        return (
          <FrameworksPanel
            session={frameworksSession} onUpdateSession={onUpdateFrameworks}
            activeOptions={getChecked("frameworks")}
            onUncheck={(opt) => toggleOne("frameworks", opt)}
          />
        );
      case "recommendations":
        return (
          <RecommendationsPanel
            session={recommendationsSession} onUpdateSession={onUpdateRecommendations}
            brainstormSession={brainstormSession} integrationSession={integrationSession}
            identitySession={identitySession} frameworksSession={frameworksSession}
            activeOptions={getChecked("recommendations")}
            onUncheck={(opt) => toggleOne("recommendations", opt)}
          />
        );
      case "compliance":
        return <CompliancePanel />;
      case "files":
        return <FilesPanel files={savedFiles} onOpenFile={onOpenFile} onDeleteFile={onDeleteFile} />;
      default:
        return <div className="p-4 text-muted-foreground text-sm">{tab.label}</div>;
    }
  };

  return (
    <div className="w-full h-full border border-border rounded-xl bg-card flex flex-col overflow-hidden">

      {/* ── Workspace header ── */}
      <div
        className="flex items-center gap-2 px-3 py-2 border-b border-border flex-shrink-0"
        onPointerDown={(e) => e.stopPropagation()}
      >
        <span className="font-bold text-foreground text-sm flex-shrink-0">Workspace</span>

        {/* Search bar */}
        <div className="flex items-center gap-1.5 px-2.5 py-1 bg-background border border-border rounded-full flex-1 min-w-0">
          <Search size={12} className="text-muted-foreground flex-shrink-0" />
          <input
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search tools and features…"
            className="bg-transparent outline-none text-foreground placeholder:text-muted-foreground text-xs flex-1 min-w-0"
            onPointerDown={(e) => e.stopPropagation()}
          />
        </div>

        {/* Overflow menu */}
        <div className="relative flex-shrink-0" ref={menuRef}>
          <button
            onClick={() => setMenuOpen((v) => !v)}
            onPointerDown={(e) => e.stopPropagation()}
            className={`w-7 h-7 rounded-md flex items-center justify-center transition-colors ${menuOpen ? "bg-muted text-foreground" : "text-muted-foreground hover:bg-muted hover:text-foreground"}`}
          >
            <MoreHorizontal size={15} />
          </button>

          {menuOpen && (
            <div className="absolute right-0 top-full mt-1 w-44 bg-card border border-border rounded-lg shadow-lg z-50 py-1 text-sm">
              <button
                onClick={() => menuAction(onSaveCurrentWork)}
                className="w-full flex items-center gap-2 px-3 py-2 hover:bg-muted transition-colors text-left"
              >
                <Save size={13} className="text-primary flex-shrink-0" />
                <span>Save Work</span>
              </button>
              <button
                onClick={() => menuAction(onSaveLayout)}
                className="w-full flex items-center gap-2 px-3 py-2 hover:bg-muted transition-colors text-left"
              >
                <Save size={13} className="text-muted-foreground flex-shrink-0" />
                <span>Save Layout</span>
              </button>
              <div className="my-1 border-t border-border" />
              <button
                onClick={() => menuAction(onToggleLock)}
                className="w-full flex items-center gap-2 px-3 py-2 hover:bg-muted transition-colors text-left"
              >
                {isLocked
                  ? <Unlock size={13} className="text-muted-foreground flex-shrink-0" />
                  : <Lock   size={13} className="text-muted-foreground flex-shrink-0" />
                }
                <span>{isLocked ? "Unlock Layout" : "Lock Layout"}</span>
              </button>
              <button
                onClick={() => menuAction(onTidy)}
                className="w-full flex items-center gap-2 px-3 py-2 hover:bg-muted transition-colors text-left"
              >
                <Sparkles size={13} className="text-primary flex-shrink-0" />
                <span>Tidy Layout</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* ── Tiled panels ── */}
      <div className="flex-1 flex overflow-hidden">
        {tabs.length === 0 ? (
          <div className="flex-1 flex items-center justify-center text-muted-foreground text-sm">
            Select a tool or action to get started
          </div>
        ) : (
          tabs.map((tab, i) => {
            const Icon = TAB_ICONS[tab.id] ?? TAB_ICONS[tab.type] ?? FolderOpen;
            return (
              <div
                key={tab.id}
                className={`flex flex-col flex-1 min-w-0 overflow-hidden ${i < tabs.length - 1 ? "border-r border-border" : ""}`}
              >
                <div className="flex items-center gap-1.5 px-3 py-1.5 bg-muted/40 border-b border-border flex-shrink-0">
                  <Icon size={12} className="text-primary flex-shrink-0" />
                  <span className="text-xs font-semibold text-foreground flex-1 truncate">{tab.label}</span>
                  {PANEL_SORT[tab.type] && (
                    <div
                      className="relative flex-shrink-0"
                      ref={openDropdown === tab.id ? dropdownRef : null}
                    >
                      <button
                        onClick={() => setOpenDropdown(openDropdown === tab.id ? null : tab.id)}
                        className="flex items-center gap-0.5 px-1.5 py-0.5 text-xs rounded border border-border bg-background hover:bg-muted transition-colors"
                      >
                        Sort{sortSelections[tab.type] ? `: ${sortSelections[tab.type]}` : ""} <ChevronDown size={9} />
                      </button>
                      {openDropdown === tab.id && (
                        <div className="absolute right-0 top-full mt-1 w-36 bg-card border border-border rounded-lg shadow-lg z-50 py-1">
                          {PANEL_SORT[tab.type]!.map((opt) => (
                            <button
                              key={opt}
                              onClick={() => { setSortSelections((prev) => ({ ...prev, [tab.type]: opt })); setOpenDropdown(null); }}
                              className={`w-full text-left px-3 py-1.5 text-xs hover:bg-muted transition-colors ${sortSelections[tab.type] === opt ? "font-semibold text-primary" : ""}`}
                            >
                              {opt}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                  {PANEL_OPTIONS[tab.type] && (
                    <div
                      className="relative flex-shrink-0"
                      ref={openDropdown === tab.id ? dropdownRef : null}
                    >
                      <button
                        onClick={() => setOpenDropdown(openDropdown === tab.id ? null : tab.id)}
                        className="flex items-center gap-0.5 px-1.5 py-0.5 text-xs rounded border border-border bg-background hover:bg-muted transition-colors"
                      >
                        Options <ChevronDown size={9} />
                      </button>
                      {openDropdown === tab.id && (
                        <div className="absolute right-0 top-full mt-1 w-36 bg-card border border-border rounded-lg shadow-lg z-50 py-1">
                          <label className="flex items-center gap-2 px-3 py-1.5 hover:bg-muted cursor-pointer text-xs font-semibold">
                            <input
                              type="checkbox"
                              checked={PANEL_OPTIONS[tab.type]!.every((o) => getChecked(tab.type).has(o))}
                              onChange={() => toggleAll(tab.type)}
                            />
                            Select All
                          </label>
                          <div className="border-t border-border my-1" />
                          {PANEL_OPTIONS[tab.type]!.map((opt) => (
                            <label key={opt} className="flex items-center gap-2 px-3 py-1.5 hover:bg-muted cursor-pointer text-xs">
                              <input
                                type="checkbox"
                                checked={getChecked(tab.type).has(opt)}
                                onChange={() => toggleOne(tab.type, opt)}
                              />
                              {opt}
                            </label>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                  <button
                    onClick={() => onCloseTab(tab.id)}
                    className="flex-shrink-0 w-4 h-4 rounded flex items-center justify-center text-muted-foreground hover:bg-destructive/20 hover:text-destructive transition-colors"
                  >
                    <X size={10} />
                  </button>
                </div>
                <div className="flex-1 overflow-hidden">
                  {renderPanel(tab)}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

export default WorkspaceCanvas;
