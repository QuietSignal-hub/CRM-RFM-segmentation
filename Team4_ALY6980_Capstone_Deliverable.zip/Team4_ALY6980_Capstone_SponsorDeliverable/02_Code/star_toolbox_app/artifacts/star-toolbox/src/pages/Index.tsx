import React, { useState, useCallback, useEffect, useRef } from "react";
import {
  Lightbulb, Link, Zap, Globe, FolderOpen,
  User, Layers, Star, ShieldCheck, ExternalLink,
} from "lucide-react";

// Compliance Checker (Track 3) lives at the api-server. In dev, Vite proxies
// /api to the backend; in production they are same-origin behind the router.
const COMPLIANCE_CHECKER_URL = "/api/compliance/console";
import MovableResizable from "@/components/MovableResizable";
import ToolCircle from "@/components/ToolCircle";
import WorkspaceCanvas, { WorkspaceTab } from "@/components/WorkspaceCanvas";
import AlignmentToolbar, { AlignAction } from "@/components/AlignmentToolbar";
import { BrainstormSession } from "@/components/workspace/BrainstormPanel";
import { IntegrationSession } from "@/components/workspace/IntegrationsPanel";
import { OptimizeSession } from "@/components/workspace/OptimizePanel";
import { SavedFile, FileCategory } from "@/components/workspace/FilesPanel";
import { EcosystemSession } from "@/components/workspace/EcosystemPanel";
import { IdentitySession } from "@/components/workspace/IdentityPanel";
import { FrameworksSession } from "@/components/workspace/FrameworksPanel";
import { RecommendationsSession } from "@/components/workspace/RecommendationsPanel";
import { toast } from "sonner";

interface ItemPosition { x: number; y: number; }
interface ItemSize    { width: number; height: number; }

const TOOLS = [
  { id: "identity",        label: "Identity",        icon: User,        tabType: "identity"        as const },
  { id: "frameworks",      label: "Frameworks",      icon: Layers,      tabType: "frameworks"      as const },
  { id: "integrations",    label: "Integrations",    icon: Link,        tabType: "integrations"    as const },
  { id: "brainstorm",      label: "Brainstorm",      icon: Lightbulb,   tabType: "brainstorm"      as const },
  { id: "optimize",        label: "Plan",            icon: Zap,         tabType: "optimize"        as const },
  { id: "ecosystem",       label: "Ecosystem",       icon: Globe,       tabType: "ecosystem"       as const },
  { id: "recommendations", label: "Recommendations", icon: Star,        tabType: "recommendations" as const },
  { id: "inventory",       label: "Inventory",       icon: FolderOpen,  tabType: "files"           as const },
  { id: "compliance",      label: "Compliance",      icon: ShieldCheck, tabType: "compliance"      as const },
];

const makeDefaults = () => {
  const pos: Record<string, ItemPosition> = {};
  TOOLS.forEach((t, i) => { pos[t.id] = { x: 100 + i * 155, y: 40 }; });
  pos["workspace"] = { x: 40, y: 220 };
  return pos;
};

const makeDefaultSizes = () => {
  const s: Record<string, ItemSize> = {};
  TOOLS.forEach((t) => { s[t.id] = { width: 120, height: 140 }; });
  s["workspace"] = { width: 1300, height: 600 };
  return s;
};

const makeDefaultBrainstorm      = (): BrainstormSession      => ({ id: crypto.randomUUID(), title: "New Brainstorm", assets: [], notes: "", createdAt: new Date(), updatedAt: new Date() });
const makeDefaultIntegration     = (): IntegrationSession     => ({ id: crypto.randomUUID(), sources: [], createdAt: new Date(), updatedAt: new Date() });
const makeDefaultOptimize        = (): OptimizeSession        => ({ id: crypto.randomUUID(), title: "Action Plan", steps: [], createdAt: new Date(), updatedAt: new Date() });
const makeDefaultEcosystem       = (): EcosystemSession       => ({ id: crypto.randomUUID(), requests: [], createdAt: new Date(), updatedAt: new Date() });
const makeDefaultIdentity        = (): IdentitySession        => ({ id: crypto.randomUUID(), projectName: "", mission: "", audience: "", values: "", differentiators: "", updatedAt: new Date() });
const makeDefaultFrameworks      = (): FrameworksSession      => ({ id: crypto.randomUUID(), selected: [], custom: [], updatedAt: new Date() });
const makeDefaultRecommendations = (): RecommendationsSession => ({ id: crypto.randomUUID(), items: [], generatedAt: null, updatedAt: new Date() });

const inferCategory = (id: string): FileCategory => {
  if (id === "brainstorm")      return "Project Assets";
  if (id === "integrations")    return "Sources";
  if (id === "optimize")        return "Project Assets";
  if (id === "ecosystem")       return "Geographic Node";
  if (id === "identity")        return "Project Assets";
  if (id === "frameworks")      return "Tools";
  if (id === "recommendations") return "Project Assets";
  return "Archives";
};

const Index: React.FC = () => {
  const [visibleTools, setVisibleTools] = useState(TOOLS.map((t) => t.id));
  const [isLocked,     setIsLocked]     = useState(() => {
    try { return localStorage.getItem("startbox-layout-locked") === "true"; } catch { return false; }
  });

  const toggleLock = useCallback(() => {
    setIsLocked((prev) => {
      const next = !prev;
      localStorage.setItem("startbox-layout-locked", String(next));
      toast.success(next ? "Layout locked" : "Layout unlocked");
      return next;
    });
  }, []);

  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  const [positions, setPositions] = useState<Record<string, ItemPosition>>(() => {
    try { const s = localStorage.getItem("startbox-layout-positions"); if (s) return JSON.parse(s); } catch {}
    return makeDefaults();
  });

  const [sizes, setSizes] = useState<Record<string, ItemSize>>(() => {
    try { const s = localStorage.getItem("startbox-layout-sizes"); if (s) return JSON.parse(s); } catch {}
    return makeDefaultSizes();
  });

  const [workspaceTabs, setWorkspaceTabs] = useState<WorkspaceTab[]>([]);
  const [searchQuery,   setSearchQuery]   = useState("");

  const [brainstormSession,      setBrainstormSession]      = useState<BrainstormSession>(makeDefaultBrainstorm);
  const [integrationSession,     setIntegrationSession]     = useState<IntegrationSession>(makeDefaultIntegration);
  const [optimizeSession,        setOptimizeSession]        = useState<OptimizeSession>(makeDefaultOptimize);
  const [ecosystemSession,       setEcosystemSession]       = useState<EcosystemSession>(makeDefaultEcosystem);
  const [identitySession,        setIdentitySession]        = useState<IdentitySession>(makeDefaultIdentity);
  const [frameworksSession,      setFrameworksSession]      = useState<FrameworksSession>(makeDefaultFrameworks);
  const [recommendationsSession, setRecommendationsSession] = useState<RecommendationsSession>(makeDefaultRecommendations);

  const [savedFiles, setSavedFiles] = useState<SavedFile[]>(() => {
    try {
      const s = localStorage.getItem("startbox-files");
      if (s) return JSON.parse(s).map((f: any) => ({ ...f, createdAt: new Date(f.createdAt), updatedAt: new Date(f.updatedAt) }));
    } catch {}
    return [];
  });

  useEffect(() => { localStorage.setItem("startbox-files", JSON.stringify(savedFiles)); }, [savedFiles]);

  // Auto-save brainstorm + integrations to inventory whenever they change
  const brainstormRef   = useRef(brainstormSession);
  const integrationRef  = useRef(integrationSession);
  brainstormRef.current  = brainstormSession;
  integrationRef.current = integrationSession;

  useEffect(() => {
    const timer = setTimeout(() => {
      const b    = brainstormRef.current;
      const intg = integrationRef.current;
      const hasB    = b.assets.length > 0 || (b.notes && b.notes.trim().length > 0);
      const hasIntg = intg.sources.length > 0;
      if (!hasB && !hasIntg) return;
      const now = new Date();
      setSavedFiles((prev) => {
        let next = [...prev];
        if (hasB) {
          const idx = next.findIndex((f) => f.id === "auto-brainstorm");
          const entry: SavedFile = { id: "auto-brainstorm", name: b.title || "Brainstorm", type: "brainstorm", data: b, category: "Project Assets", createdAt: idx >= 0 ? next[idx].createdAt : now, updatedAt: now };
          if (idx >= 0) next[idx] = entry; else next.push(entry);
        }
        if (hasIntg) {
          const idx = next.findIndex((f) => f.id === "auto-integrations");
          const entry: SavedFile = { id: "auto-integrations", name: `Sources (${intg.sources.length})`, type: "integrations", data: intg, category: "Sources", createdAt: idx >= 0 ? next[idx].createdAt : now, updatedAt: now };
          if (idx >= 0) next[idx] = entry; else next.push(entry);
        }
        return next;
      });
    }, 800);
    return () => clearTimeout(timer);
  }, [brainstormSession, integrationSession]);

  // ── Tidy ──
  const handleTidy = useCallback(() => {
    const defPos = makeDefaults(); const defSizes = makeDefaultSizes();
    const newPos = { ...positions }; const newSizes = { ...sizes };
    TOOLS.forEach((t) => { newPos[t.id] = defPos[t.id]; newSizes[t.id] = defSizes[t.id]; });
    newPos["workspace"] = defPos["workspace"]; newSizes["workspace"] = defSizes["workspace"];
    setPositions(newPos); setSizes(newSizes);
    setVisibleTools(TOOLS.map((t) => t.id));
    toast.success("Layout tidied up");
  }, [positions, sizes]);

  // ── Save layout ──
  const handleSaveLayout = useCallback(() => {
    localStorage.setItem("startbox-layout-positions", JSON.stringify(positions));
    localStorage.setItem("startbox-layout-sizes",     JSON.stringify(sizes));
    const now = new Date();
    setSavedFiles((prev) => [...prev, {
      id: crypto.randomUUID(), name: `Layout ${new Date().toLocaleTimeString()}`, type: "bundle" as const,
      data: { positions, sizes, visibleTools, workspaceTabs },
      category: "Project Assets", createdAt: now, updatedAt: now,
    }]);
    toast.success("Layout saved to Inventory");
  }, [positions, sizes, visibleTools, workspaceTabs]);

  // ── Rubber-band selection ──
  const canvasRef = useRef<HTMLDivElement>(null);
  const [selRect, setSelRect] = useState<{ x: number; y: number; w: number; h: number } | null>(null);
  const selStart = useRef<{ x: number; y: number } | null>(null);

  const handleCanvasPointerDown = useCallback((e: React.PointerEvent) => {
    if (e.target !== canvasRef.current) return;
    const rect = canvasRef.current!.getBoundingClientRect();
    const x = e.clientX - rect.left + canvasRef.current!.scrollLeft;
    const y = e.clientY - rect.top  + canvasRef.current!.scrollTop;
    selStart.current = { x, y };
    if (!e.shiftKey && !e.ctrlKey && !e.metaKey) setSelectedIds(new Set());

    const onMove = (ev: PointerEvent) => {
      if (!selStart.current) return;
      const mx = ev.clientX - rect.left + canvasRef.current!.scrollLeft;
      const my = ev.clientY - rect.top  + canvasRef.current!.scrollTop;
      setSelRect({ x: Math.min(selStart.current.x, mx), y: Math.min(selStart.current.y, my), w: Math.abs(mx - selStart.current.x), h: Math.abs(my - selStart.current.y) });
    };
    const onUp = () => {
      if (selStart.current && selRect) {
        const r = selRect;
        const ids = new Set<string>(e.shiftKey || e.ctrlKey || e.metaKey ? selectedIds : []);
        Object.entries(positions).forEach(([id, pos]) => {
          const sz = sizes[id] || { width: 100, height: 100 };
          if (pos.x + sz.width / 2 >= r.x && pos.x + sz.width / 2 <= r.x + r.w &&
              pos.y + sz.height / 2 >= r.y && pos.y + sz.height / 2 <= r.y + r.h) ids.add(id);
        });
        setSelectedIds(ids);
      }
      setSelRect(null); selStart.current = null;
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup",   onUp);
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup",   onUp);
  }, [positions, sizes, selectedIds, selRect]);

  const positionsRef    = useRef(positions);   positionsRef.current   = positions;
  const selectedIdsRef  = useRef(selectedIds); selectedIdsRef.current = selectedIds;
  const groupDragOrigin = useRef<Record<string, ItemPosition> | null>(null);
  const groupDragAnchor = useRef<string | null>(null);

  useEffect(() => {
    const handleMove = (e: Event) => {
      const { id, x, y } = (e as CustomEvent).detail;
      const sel = selectedIdsRef.current;
      if (sel.has(id) && sel.size > 1) {
        if (!groupDragOrigin.current || groupDragAnchor.current !== id) {
          groupDragOrigin.current = {}; groupDragAnchor.current = id;
          sel.forEach((sid) => { groupDragOrigin.current![sid] = { ...positionsRef.current[sid] }; });
        }
        const origin = groupDragOrigin.current[id];
        const dx = x - origin.x; const dy = y - origin.y;
        setPositions((prev) => {
          const next = { ...prev };
          sel.forEach((sid) => { const o = groupDragOrigin.current![sid]; if (o) next[sid] = { x: Math.max(0, o.x + dx), y: Math.max(0, o.y + dy) }; });
          return next;
        });
      } else {
        groupDragOrigin.current = null; groupDragAnchor.current = null;
        setPositions((prev) => ({ ...prev, [id]: { x, y } }));
      }
    };
    const handleResize  = (e: Event) => { const { id, width, height } = (e as CustomEvent).detail; setSizes((prev) => ({ ...prev, [id]: { width, height } })); };
    const handleDragEnd = () => { groupDragOrigin.current = null; groupDragAnchor.current = null; };
    window.addEventListener("movable-move",   handleMove);
    window.addEventListener("movable-resize", handleResize);
    window.addEventListener("pointerup",      handleDragEnd);
    return () => {
      window.removeEventListener("movable-move",   handleMove);
      window.removeEventListener("movable-resize", handleResize);
      window.removeEventListener("pointerup",      handleDragEnd);
    };
  }, []);

  const handleItemClick = useCallback((id: string, e: React.PointerEvent) => {
    if (e.shiftKey || e.ctrlKey || e.metaKey) {
      e.preventDefault(); e.stopPropagation();
      setSelectedIds((prev) => { const next = new Set(prev); next.has(id) ? next.delete(id) : next.add(id); return next; });
    }
  }, []);

  const handleAlign = useCallback((action: AlignAction) => {
    if (selectedIds.size < 2) return;
    const ids   = Array.from(selectedIds);
    const items = ids.map((id) => ({ id, pos: positions[id], size: sizes[id] || { width: 100, height: 100 } }));
    setPositions((prev) => {
      const next = { ...prev };
      switch (action) {
        case "align-left":     { const minX = Math.min(...items.map((i) => i.pos.x)); items.forEach((i) => { next[i.id] = { ...next[i.id], x: minX }; }); break; }
        case "align-right":    { const maxR = Math.max(...items.map((i) => i.pos.x + i.size.width)); items.forEach((i) => { next[i.id] = { ...next[i.id], x: maxR - i.size.width }; }); break; }
        case "align-center-h": { const minX = Math.min(...items.map((i) => i.pos.x)); const maxR = Math.max(...items.map((i) => i.pos.x + i.size.width)); const cx = (minX + maxR) / 2; items.forEach((i) => { next[i.id] = { ...next[i.id], x: cx - i.size.width / 2 }; }); break; }
        case "align-top":      { const minY = Math.min(...items.map((i) => i.pos.y)); items.forEach((i) => { next[i.id] = { ...next[i.id], y: minY }; }); break; }
        case "align-bottom":   { const maxB = Math.max(...items.map((i) => i.pos.y + i.size.height)); items.forEach((i) => { next[i.id] = { ...next[i.id], y: maxB - i.size.height }; }); break; }
        case "align-center-v": { const minY = Math.min(...items.map((i) => i.pos.y)); const maxB = Math.max(...items.map((i) => i.pos.y + i.size.height)); const cy = (minY + maxB) / 2; items.forEach((i) => { next[i.id] = { ...next[i.id], y: cy - i.size.height / 2 }; }); break; }
        case "distribute-h": {
          if (items.length < 3) break;
          const sorted = [...items].sort((a, b) => a.pos.x - b.pos.x);
          const first = sorted[0]; const last = sorted[sorted.length - 1];
          const gap = ((last.pos.x + last.size.width) - first.pos.x - sorted.reduce((s, i) => s + i.size.width, 0)) / (sorted.length - 1);
          let cur = first.pos.x; sorted.forEach((item) => { next[item.id] = { ...next[item.id], x: cur }; cur += item.size.width + gap; }); break;
        }
        case "distribute-v": {
          if (items.length < 3) break;
          const sorted = [...items].sort((a, b) => a.pos.y - b.pos.y);
          const first = sorted[0]; const last = sorted[sorted.length - 1];
          const gap = ((last.pos.y + last.size.height) - first.pos.y - sorted.reduce((s, i) => s + i.size.height, 0)) / (sorted.length - 1);
          let cur = first.pos.y; sorted.forEach((item) => { next[item.id] = { ...next[item.id], y: cur }; cur += item.size.height + gap; }); break;
        }
      }
      return next;
    });
  }, [selectedIds, positions, sizes]);

  // ── Open / close workspace panels ──
  const openInWorkspace = useCallback((id: string, label: string, type: WorkspaceTab["type"]) => {
    setWorkspaceTabs((prev) => {
      if (prev.some((t) => t.id === id)) return prev;
      return [...prev, { id, label, type }];
    });
  }, []);

  const handleCloseTab  = (id: string) => { setWorkspaceTabs((prev) => prev.filter((t) => t.id !== id)); };
  const handleToolClick = (tool: (typeof TOOLS)[0]) => { openInWorkspace(tool.id, tool.label, tool.tabType); };

  const handleSaveCurrentWork = useCallback(() => {
    const files: SavedFile[] = []; const now = new Date();
    if ((brainstormSession.assets?.length ?? 0) > 0)
      files.push({ id: crypto.randomUUID(), name: brainstormSession.title || "Brainstorm", type: "brainstorm", data: brainstormSession, category: "Project Assets", createdAt: now, updatedAt: now });
    if (integrationSession.sources.length > 0)
      files.push({ id: crypto.randomUUID(), name: `Sources (${integrationSession.sources.length})`, type: "integrations", data: integrationSession, category: "Sources", createdAt: now, updatedAt: now });
    if (optimizeSession.steps.length > 0)
      files.push({ id: crypto.randomUUID(), name: optimizeSession.title || "Action Plan", type: "optimize", data: optimizeSession, category: "Project Assets", createdAt: now, updatedAt: now });
    if ((ecosystemSession.requests?.length ?? 0) > 0)
      files.push({ id: crypto.randomUUID(), name: "Ecosystem Map", type: "ecosystem", data: ecosystemSession, category: "Geographic Node", createdAt: now, updatedAt: now });
    if (identitySession.projectName || identitySession.mission)
      files.push({ id: crypto.randomUUID(), name: identitySession.projectName || "Identity", type: "tool", data: identitySession, category: "Project Assets", createdAt: now, updatedAt: now });
    if (frameworksSession.selected.length > 0)
      files.push({ id: crypto.randomUUID(), name: `Frameworks (${frameworksSession.selected.length})`, type: "tool", data: frameworksSession, category: "Tools", createdAt: now, updatedAt: now });
    if (recommendationsSession.items.length > 0)
      files.push({ id: crypto.randomUUID(), name: "Recommendations", type: "tool", data: recommendationsSession, category: "Project Assets", createdAt: now, updatedAt: now });
    if (files.length === 0) { toast.info("Nothing to save yet"); return; }
    setSavedFiles((prev) => [...prev, ...files]);
    openInWorkspace("inventory", "Inventory", "files");
    toast.success(`Saved ${files.length} item${files.length > 1 ? "s" : ""} to Inventory`);
  }, [brainstormSession, integrationSession, optimizeSession, ecosystemSession, identitySession, frameworksSession, recommendationsSession, openInWorkspace]);

  const handleCloseTool = useCallback((toolId: string) => {
    const tool = TOOLS.find((t) => t.id === toolId);
    if (!tool) return;
    const now = new Date(); const category = inferCategory(toolId);
    let data: any = { closedAt: now.toISOString(), toolId, label: tool.label };
    if      (toolId === "brainstorm"      && (brainstormSession.assets?.length ?? 0) > 0)  data = brainstormSession;
    else if (toolId === "integrations"    && integrationSession.sources.length > 0)        data = integrationSession;
    else if (toolId === "optimize"        && optimizeSession.steps.length > 0)             data = optimizeSession;
    else if (toolId === "ecosystem"       && (ecosystemSession.requests?.length ?? 0) > 0) data = ecosystemSession;
    else if (toolId === "identity"        && (identitySession.projectName || identitySession.mission)) data = identitySession;
    else if (toolId === "frameworks"      && frameworksSession.selected.length > 0)        data = frameworksSession;
    else if (toolId === "recommendations" && recommendationsSession.items.length > 0)      data = recommendationsSession;
    setSavedFiles((prev) => [...prev, { id: crypto.randomUUID(), name: tool.label, type: "closed-item", data, category, createdAt: now, updatedAt: now }]);
    setVisibleTools((prev) => prev.filter((id) => id !== toolId));
    toast.success(`${tool.label} saved to Inventory`);
  }, [brainstormSession, integrationSession, optimizeSession, ecosystemSession, identitySession, frameworksSession, recommendationsSession]);

  const handleOpenFile = useCallback((file: SavedFile) => {
    if (file.type === "bundle" && file.data?.positions) {
      const snap = file.data;
      if (snap.positions)     setPositions(snap.positions);
      if (snap.sizes)         setSizes(snap.sizes);
      if (snap.visibleTools)  setVisibleTools(snap.visibleTools);
      if (snap.workspaceTabs) setWorkspaceTabs(snap.workspaceTabs);
      toast.success("Layout restored"); return;
    }
    if (file.type === "brainstorm")        { setBrainstormSession(file.data);  openInWorkspace("brainstorm",   "Brainstorm",   "brainstorm"); }
    else if (file.type === "integrations") { setIntegrationSession(file.data); openInWorkspace("integrations", "Integrations", "integrations"); }
    else if (file.type === "optimize")     { setOptimizeSession(file.data);    openInWorkspace("optimize",     "Plan",         "optimize"); }
    else if (file.type === "ecosystem")    { setEcosystemSession(file.data);   openInWorkspace("ecosystem",    "Ecosystem",    "ecosystem"); }
    else if (file.type === "closed-item" && file.data?.toolId) {
      const toolId = file.data.toolId;
      if (TOOLS.some((t) => t.id === toolId)) setVisibleTools((prev) => prev.includes(toolId) ? prev : [...prev, toolId]);
    }
  }, [openInWorkspace]);

  const handleDeleteFile = useCallback((id: string) => { setSavedFiles((prev) => prev.filter((f) => f.id !== id)); }, []);

  const selectionRing = "ring-2 ring-primary ring-offset-2 ring-offset-background rounded-lg";

  return (
    <div
      ref={canvasRef}
      className="relative bg-white overflow-auto"
      style={{ minWidth: 1400, minHeight: "100vh" }}
      onPointerDown={handleCanvasPointerDown}
    >
      <AlignmentToolbar selectedCount={selectedIds.size} onAlign={handleAlign} onClearSelection={() => setSelectedIds(new Set())} />

      {/* Compliance Checker launch — opens the Track 3 checker in a new tab */}
      <button
        onClick={() => window.open(COMPLIANCE_CHECKER_URL, "_blank", "noopener")}
        title="Open the Compliance Checker"
        className="fixed top-3 right-4 z-[100] flex items-center gap-2 rounded-lg bg-primary px-3 py-2 text-sm font-medium text-primary-foreground shadow-md hover:brightness-110 transition"
      >
        <ShieldCheck size={16} />
        Compliance Check
        <ExternalLink size={13} className="opacity-70" />
      </button>

      {selRect && (
        <div className="absolute border-2 border-primary/50 bg-primary/10 rounded-sm pointer-events-none"
          style={{ left: selRect.x, top: selRect.y, width: selRect.w, height: selRect.h, zIndex: 99 }} />
      )}

      {/* Tool circles — freely movable on canvas */}
      {TOOLS.filter((t) => visibleTools.includes(t.id)).map((tool) => (
        <MovableResizable
          key={tool.id} id={tool.id}
          position={positions[tool.id] || { x: 100, y: 40 }}
          size={sizes[tool.id]}
          onMove={() => {}} onResize={() => {}}
          resizable locked={isLocked} minWidth={80} minHeight={80}
        >
          <div
            className={`w-full h-full flex items-center justify-center ${selectedIds.has(tool.id) ? selectionRing : ""}`}
            onPointerDown={(e) => handleItemClick(tool.id, e)}
          >
            <ToolCircle icon={tool.icon} label={tool.label} onClick={() => handleToolClick(tool)} onClose={() => handleCloseTool(tool.id)} />
          </div>
        </MovableResizable>
      ))}

      {/* Workspace window — movable, with all controls in header */}
      <MovableResizable
        id="workspace"
        position={positions["workspace"] || { x: 40, y: 220 }}
        size={sizes["workspace"]}
        onMove={() => {}} onResize={() => {}}
        resizable locked={isLocked} minWidth={300} minHeight={200}
      >
        <div
          onPointerDown={(e) => { handleItemClick("workspace", e); if (!(e.target as HTMLElement).dataset.resizeHandle) e.stopPropagation(); }}
          className={`w-full h-full ${selectedIds.has("workspace") ? selectionRing : ""}`}
        >
          <WorkspaceCanvas
            tabs={workspaceTabs}
            onCloseTab={handleCloseTab}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            isLocked={isLocked}
            onToggleLock={toggleLock}
            onTidy={handleTidy}
            onSaveLayout={handleSaveLayout}
            brainstormSession={brainstormSession}           onUpdateBrainstorm={setBrainstormSession}
            integrationSession={integrationSession}         onUpdateIntegrations={setIntegrationSession}
            optimizeSession={optimizeSession}               onUpdateOptimize={setOptimizeSession}
            ecosystemSession={ecosystemSession}             onUpdateEcosystem={setEcosystemSession}
            identitySession={identitySession}               onUpdateIdentity={setIdentitySession}
            frameworksSession={frameworksSession}           onUpdateFrameworks={setFrameworksSession}
            recommendationsSession={recommendationsSession} onUpdateRecommendations={setRecommendationsSession}
            savedFiles={savedFiles} onOpenFile={handleOpenFile} onDeleteFile={handleDeleteFile}
            onSaveCurrentWork={handleSaveCurrentWork}
          />
        </div>
      </MovableResizable>
    </div>
  );
};

export default Index;
