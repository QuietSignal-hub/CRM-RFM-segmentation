// Supabase replaced with API server — stub kept for type compatibility
export const supabase = {
  functions: {
    invoke: async (_name: string, _opts?: unknown) => {
      return { data: null, error: new Error("Use the API server instead") };
    },
  },
};
