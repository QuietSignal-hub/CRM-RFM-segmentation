// ── Track 3: Rule-database health / re-verification report ─────────────────────
//
// Blueprint §5.3 ("Rule Database Health" dashboard panel) and §10 (weekly
// re-verification job) call for surfacing stale, unverified, or broken rules.
// This produces that report from the rule data alone — no network — so it is
// fast and deterministic. Optional live source-link checking is documented in
// CURATION.md as a follow-up (a HEAD request per sourceUrl behind the existing
// SSRF guard); kept out of the default path to avoid slow/flaky network calls.

import type { ComplianceRule, Severity } from "./types";

const STALE_AFTER_DAYS = 90;

export interface RuleHealthReport {
  generatedAt: string;
  totalRules: number;
  verifiedCount: number;
  unverifiedCount: number;
  staleCount: number;
  missingSourceCount: number;
  bySeverity: Record<Severity, number>;
  /** Rules a human should action, with the reason(s) flagged. */
  flagged: Array<{
    id: string;
    title: string;
    reasons: string[];
    lastVerified: string | null;
  }>;
}

export function buildHealthReport(
  rules: ComplianceRule[],
  now: Date = new Date(),
): RuleHealthReport {
  const staleCutoff = now.getTime() - STALE_AFTER_DAYS * 24 * 60 * 60 * 1000;

  const bySeverity = { critical: 0, high: 0, medium: 0, low: 0 } as Record<
    Severity,
    number
  >;
  const flagged: RuleHealthReport["flagged"] = [];
  let verifiedCount = 0;
  let staleCount = 0;
  let missingSourceCount = 0;

  for (const rule of rules) {
    bySeverity[rule.severity]++;

    const reasons: string[] = [];
    if (!rule.verified) reasons.push("unverified");
    if (rule.verified && rule.lastVerified) {
      const verifiedAt = Date.parse(rule.lastVerified);
      if (!Number.isNaN(verifiedAt) && verifiedAt < staleCutoff) {
        reasons.push(`stale (>${STALE_AFTER_DAYS}d)`);
        staleCount++;
      }
    }
    if (!rule.sourceUrl || !/^https?:\/\//.test(rule.sourceUrl)) {
      reasons.push("missing/invalid source URL");
      missingSourceCount++;
    }

    if (rule.verified) verifiedCount++;
    if (reasons.length > 0) {
      flagged.push({
        id: rule.id,
        title: rule.title,
        reasons,
        lastVerified: rule.lastVerified,
      });
    }
  }

  return {
    generatedAt: now.toISOString(),
    totalRules: rules.length,
    verifiedCount,
    unverifiedCount: rules.length - verifiedCount,
    staleCount,
    missingSourceCount,
    bySeverity,
    flagged,
  };
}
