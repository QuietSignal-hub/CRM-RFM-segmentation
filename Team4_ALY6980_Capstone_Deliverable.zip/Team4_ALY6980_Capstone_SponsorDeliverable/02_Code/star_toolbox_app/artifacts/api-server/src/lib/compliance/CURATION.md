# Compliance Rule Curation Guide (Track 3)

This is the handoff document for maintaining the compliance rule database. It is
written so a **non-developer at YSSL** can add and verify rules without touching
the matching engine.

## Where the rules live

All rules are in [`rules.ts`](./rules.ts) — one TypeScript array,
`COMPLIANCE_RULES`. Each entry is a plain object. You edit the array, save, and
restart the API server (`pnpm --filter @workspace/api-server run dev`) to pick up
changes. The shape of a rule is defined and commented in [`types.ts`](./types.ts).

> **Why a `.ts` file and not a database?** This build uses local files to match
> the current S.T.A.R.Toolbox architecture (no Postgres/Supabase required). The
> rule shape is DB-ready, so it can move into a `compliance_rules` table later
> with no change to the matcher or API.

## Anatomy of a rule

```ts
{
  id: "qc-qst-collection",              // unique slug: <jurisdiction>-<topic>
  title: "Register for and collect QST",
  description: "Plain-language statement of the obligation.", // SOURCE OF TRUTH
  jurisdiction: "quebec",               // federal-ca | ontario | quebec | us-cross-border
  industries: ["all"],                  // ["photography"], ["film"], or ["all"]
  category: "tax",                      // permits|tax|labor|intellectual-property|insurance|cross-border|privacy|licensing
  severity: "high",                     // critical | high | medium | low
  requires: { commercialUse: true },    // OPTIONAL — all listed must be true to apply
  formReference: "Form ...",            // OPTIONAL
  noticePeriod: "14 days before",       // OPTIONAL
  actionSteps: ["..."],                 // OPTIONAL
  sourceName: "Revenu Québec",
  sourceUrl: "https://www.revenuquebec.ca/...",
  lastVerified: null,                   // ISO date once a human confirms it
  verified: false,                      // flip to true ONLY after verification
}
```

### The `requires` field — how matching works

A rule with **no `requires`** applies to every project in its jurisdiction +
industry. A rule **with `requires`** only appears when **all** listed
characteristics are true for the project. Available characteristics (defined in
`types.ts` → `ProjectCharacteristics`):

`involvesMinors`, `commercialUse`, `hiringCrew`, `publicProperty`,
`outdoorShoot`, `droneUse`, `paidModels`, `sellsPrints`, `livePerformance`,
`ticketedEvent`, `usesRecordedMusic`, `recordedRelease`, `sellsMerch`.

To add a new characteristic, add the key in `types.ts`, then add it to
`VALID_CHARACTERISTICS` in `routes/compliance-check.ts`, then to the frontend
input form (Track 4).

## The verification workflow (the important part)

**Every seed rule ships `verified: false`.** They are research leads, not
confirmed facts. This is deliberate — the entire premise of the project
(Blueprint §2) is that we do *not* publish confidently-wrong rule numbers the
way a generic chatbot does.

To verify a rule:

1. Open the rule's `sourceUrl` and find the authoritative government page.
2. Confirm the **title, description, form number, notice period, and fees** match
   the live source. Fix anything that drifted.
3. Replace `sourceUrl` with the **exact deep link** to the relevant page.
4. Set `lastVerified` to today's date, e.g. `"2026-02-15"`.
5. Set `verified: true`.
6. Delete the `verificationNote` once resolved (or update it).

Rules with a `verificationNote` have a **known issue to check first** — e.g. the
Quebec child-labour rule notes the 2023 Bill 19 overhaul that the original
blueprint detail predates.

## Checking database health

`GET /api/compliance/health` returns a live report:

```bash
curl http://localhost:5000/api/compliance/health
```

It lists totals plus every rule flagged as **unverified**, **stale**
(verified > 90 days ago), or **missing a source URL**. This powers the
"Rule Database Health" dashboard panel (Track 5) and is the basis of the weekly
re-verification job (Blueprint §10).

**Future extension:** add live source-link checking — a `HEAD` request per
`sourceUrl` behind the existing SSRF guard in `routes/parse-content.ts` — to
detect broken government links automatically. Left out of the default path to
keep the report fast and network-free.

## Scope & coverage

Disciplines (per sponsor): **photographers, singers (music), dancers (dance)**.
Jurisdictions: **Federal Canada, all 13 provinces/territories, US cross-border**.

Two kinds of rule live in the codebase:
- **Generated provincial rules** — sales tax, workers' comp, business
  registration, and employment standards for every province come from the
  verified table in [`provinces.ts`](./provinces.ts). To fix a tax rate, board
  name, or URL, edit that one table — do NOT hand-edit 13 rule objects.
- **Explicit rules** in [`rules.ts`](./rules.ts) — federal, cross-border,
  discipline-specific, and province-SPECIAL rules (child-performer regimes for
  ON/QC/BC/MB, Quebec Bill 96, etc.).

Sales-tax rates and workers'-comp boards are `verified: true`. Business
registration and employment standards carry the official provincial domain but
are `verified: false` — confirm the exact landing page per province. Other
unverified rules are practice-based (location releases) or vary by
municipality/state (local permits, US state sales tax).
