import { describe, it, expect } from "vitest";
import {
  resolveJurisdictions,
  matchRules,
  severityBreakdown,
  severityRank,
  isUnitedStates,
} from "./matcher";
import type { ComplianceRule, ComplianceCheckRequest } from "./types";
import { COMPLIANCE_RULES } from "./rules";

// ── Synthetic rules for precise, isolated assertions ───────────────────────────
const rule = (over: Partial<ComplianceRule>): ComplianceRule => ({
  id: "r",
  title: "t",
  description: "d",
  jurisdiction: "federal-ca",
  industries: ["all"],
  category: "tax",
  severity: "medium",
  sourceName: "src",
  sourceUrl: "https://example.gov",
  lastVerified: null,
  verified: false,
  ...over,
});

const baseReq = (over: Partial<ComplianceCheckRequest> = {}): ComplianceCheckRequest => ({
  industry: "photography",
  userLocation: "Ontario",
  workLocation: "Ontario",
  clientLocation: "Ontario",
  characteristics: {},
  ...over,
});

describe("isUnitedStates", () => {
  it("matches common US spellings", () => {
    for (const s of ["US", "us", "USA", "United States", "u.s.", "America"]) {
      expect(isUnitedStates(s)).toBe(true);
    }
  });
  it("rejects Canadian locations", () => {
    for (const s of ["Ontario", "QC", "Quebec", "Canada", ""]) {
      expect(isUnitedStates(s)).toBe(false);
    }
  });
});

describe("resolveJurisdictions", () => {
  it("always includes federal-ca", () => {
    expect(resolveJurisdictions(baseReq({ userLocation: "Nova Scotia", workLocation: "Nova Scotia", clientLocation: "Nova Scotia" }))).toContain("federal-ca");
  });
  it("adds province from user/work location", () => {
    const j = resolveJurisdictions(baseReq({ userLocation: "Ontario", workLocation: "Quebec", clientLocation: "Ontario" }));
    expect(j).toContain("on");
    expect(j).toContain("qc");
  });
  it("maps other provinces by name and abbreviation", () => {
    expect(resolveJurisdictions(baseReq({ userLocation: "BC", workLocation: "BC", clientLocation: "BC" }))).toContain("bc");
    expect(resolveJurisdictions(baseReq({ userLocation: "Alberta", workLocation: "Alberta", clientLocation: "Alberta" }))).toContain("ab");
    expect(resolveJurisdictions(baseReq({ userLocation: "Nova Scotia", workLocation: "Nova Scotia", clientLocation: "Nova Scotia" }))).toContain("ns");
  });
  it("adds us-cross-border when ANY location is the US", () => {
    expect(resolveJurisdictions(baseReq({ clientLocation: "US" }))).toContain("us-cross-border");
    expect(resolveJurisdictions(baseReq({ workLocation: "US" }))).toContain("us-cross-border");
  });
  it("does not add us-cross-border for a fully domestic project", () => {
    expect(resolveJurisdictions(baseReq())).not.toContain("us-cross-border");
  });
  it("dedupes (user + work both Ontario → one on)", () => {
    const j = resolveJurisdictions(baseReq());
    expect(j.filter((x) => x === "on")).toHaveLength(1);
  });
});

describe("matchRules — filtering", () => {
  const rules: ComplianceRule[] = [
    rule({ id: "fed-all" }),
    rule({ id: "music-only", industries: ["music"] }),
    rule({ id: "needs-minors", requires: { involvesMinors: true } }),
    rule({ id: "qc-only", jurisdiction: "qc" }),
  ];

  it("excludes rules from non-resolved jurisdictions", () => {
    const { matched } = matchRules(baseReq(), rules); // Ontario only
    expect(matched.map((r) => r.id)).not.toContain("qc-only");
  });
  it("excludes music-only rules for a photography project", () => {
    const { matched } = matchRules(baseReq({ industry: "photography" }), rules);
    expect(matched.map((r) => r.id)).not.toContain("music-only");
  });
  it("includes a rule only when its required characteristic is true", () => {
    expect(matchRules(baseReq(), rules).matched.map((r) => r.id)).not.toContain("needs-minors");
    expect(
      matchRules(baseReq({ characteristics: { involvesMinors: true } }), rules).matched.map((r) => r.id),
    ).toContain("needs-minors");
  });
});

describe("matchRules — work-location gate (precision fix)", () => {
  const visa = rule({ id: "us-visa", jurisdiction: "us-cross-border", requiresUsWorkLocation: true });
  const withholding = rule({ id: "us-withholding", jurisdiction: "us-cross-border" });
  const rules = [visa, withholding];

  it("domestic shoot, US client: client-driven rule fires, work-in-US rule does NOT", () => {
    const ids = matchRules(baseReq({ workLocation: "Quebec", clientLocation: "US" }), rules).matched.map((r) => r.id);
    expect(ids).toContain("us-withholding");
    expect(ids).not.toContain("us-visa");
  });
  it("work physically in the US: work-in-US rule fires", () => {
    const ids = matchRules(baseReq({ workLocation: "US", clientLocation: "US" }), rules).matched.map((r) => r.id);
    expect(ids).toContain("us-visa");
  });
});

describe("matchRules — ordering", () => {
  it("ranks by severity, critical first", () => {
    const rules = [
      rule({ id: "low", severity: "low" }),
      rule({ id: "crit", severity: "critical" }),
      rule({ id: "med", severity: "medium" }),
      rule({ id: "high", severity: "high" }),
    ];
    const order = matchRules(baseReq(), rules).matched.map((r) => r.id);
    expect(order).toEqual(["crit", "high", "med", "low"]);
  });
  it("severityRank orders critical < high < medium < low", () => {
    expect(severityRank("critical")).toBeLessThan(severityRank("high"));
    expect(severityRank("high")).toBeLessThan(severityRank("medium"));
    expect(severityRank("medium")).toBeLessThan(severityRank("low"));
  });
});

describe("severityBreakdown", () => {
  it("counts each severity and zero-fills the rest", () => {
    const b = severityBreakdown([rule({ severity: "high" }), rule({ severity: "high" }), rule({ severity: "low" })]);
    expect(b).toEqual({ critical: 0, high: 2, medium: 0, low: 1 });
  });
});

describe("flagship scenario against the real rule database", () => {
  it("Quebec photo shoot, US client, child models → critical child rules, W-8BEN, no US visa", () => {
    const { jurisdictions, matched } = matchRules(
      baseReq({
        industry: "photography",
        userLocation: "Ontario",
        workLocation: "Quebec",
        clientLocation: "US",
        characteristics: { involvesMinors: true, commercialUse: true, paidModels: true },
      }),
      COMPLIANCE_RULES,
    );
    const ids = matched.map((r) => r.id);

    expect(jurisdictions).toEqual(expect.arrayContaining(["federal-ca", "on", "qc", "us-cross-border"]));
    expect(ids).toContain("qc-child-artist-consent");
    expect(ids).toContain("us-w8ben-treaty-claim");
    // Shoot is in Quebec, not the US → US performance visa must NOT appear.
    expect(ids).not.toContain("us-p2-visa-performers");
    // Critical items must rank ahead of any low item.
    const firstLow = matched.findIndex((r) => r.severity === "low");
    const lastCritical = matched.map((r) => r.severity).lastIndexOf("critical");
    expect(lastCritical).toBeLessThan(firstLow);
  });

  it("dancer performing in the US to recorded music → P-2 visa, Article XVI, Re:Sound", () => {
    const { matched } = matchRules(
      baseReq({
        industry: "dance",
        userLocation: "Ontario",
        workLocation: "US",
        clientLocation: "US",
        characteristics: { livePerformance: true, usesRecordedMusic: true, ticketedEvent: true },
      }),
      COMPLIANCE_RULES,
    );
    const ids = matched.map((r) => r.id);
    expect(ids).toContain("us-p2-visa-performers");
    expect(ids).toContain("us-treaty-article-xvi-artistes");
    expect(ids).toContain("fed-resound-recorded-music");
  });
});
