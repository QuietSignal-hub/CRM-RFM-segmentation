// ── Track 3: Rule-matching engine (the "lead pipeline", Blueprint §5.2 B) ──────
//
// Pure functions, no I/O. Given a project description and the rule database,
// resolve the applicable jurisdictions, filter rules by jurisdiction + industry
// + project characteristics, and rank by severity. Kept side-effect-free so it
// can be unit-tested and reused by the OptimizePanel integration later.

import {
  type ComplianceRule,
  type ComplianceCheckRequest,
  type Jurisdiction,
  type Severity,
  type CharacteristicKey,
  SEVERITIES,
} from "./types";

/** Lower rank = higher urgency. Drives the output ordering. */
const SEVERITY_RANK: Record<Severity, number> = SEVERITIES.reduce(
  (acc, sev, i) => {
    acc[sev] = i;
    return acc;
  },
  {} as Record<Severity, number>,
);

export function severityRank(severity: Severity): number {
  return SEVERITY_RANK[severity];
}

/** Map a free-form location string to a Canadian province/territory code, if any. */
function provinceFor(location: string): Jurisdiction | null {
  const s = location.trim().toLowerCase();
  if (!s) return null;
  // Order matters: check longer/specific names before short ones.
  if (/^bc$|british columbia/.test(s)) return "bc";
  if (/^ab$|alberta/.test(s)) return "ab";
  if (/^sk$|saskatchewan/.test(s)) return "sk";
  if (/^mb$|manitoba/.test(s)) return "mb";
  if (/^on$|ontario/.test(s)) return "on";
  if (/^qc$|^pq$|^que\b|quebec|québec/.test(s)) return "qc";
  if (/^nb$|new brunswick/.test(s)) return "nb";
  if (/^ns$|nova scotia/.test(s)) return "ns";
  if (/^pe$|^pei$|prince edward/.test(s)) return "pe";
  if (/^nl$|^nf$|newfoundland|labrador/.test(s)) return "nl";
  if (/^yt$|^yk$|yukon/.test(s)) return "yt";
  if (/^nu$|nunavut/.test(s)) return "nu";
  // Match NWT before a bare "nt" and avoid colliding with other tokens.
  if (/^nt$|^nwt$|northwest territor/.test(s)) return "nt";
  return null;
}

/** True if the location string denotes the United States. */
export function isUnitedStates(location: string): boolean {
  const s = location.trim().toLowerCase();
  return /^us$|^usa$|united states|u\.s\.|america/.test(s);
}

/**
 * Resolve every jurisdiction relevant to a project. Federal Canada always
 * applies; provinces are added from the user/work locations; us-cross-border is
 * added whenever any of the three locations is in the US.
 */
export function resolveJurisdictions(
  req: Pick<ComplianceCheckRequest, "userLocation" | "workLocation" | "clientLocation">,
): Jurisdiction[] {
  const set = new Set<Jurisdiction>(["federal-ca"]);

  for (const loc of [req.userLocation, req.workLocation]) {
    const prov = provinceFor(loc);
    if (prov) set.add(prov);
  }

  if (
    isUnitedStates(req.userLocation) ||
    isUnitedStates(req.workLocation) ||
    isUnitedStates(req.clientLocation)
  ) {
    set.add("us-cross-border");
  }

  return [...set];
}

/** Every characteristic the rule requires must be explicitly true on the request. */
function characteristicsSatisfied(
  rule: ComplianceRule,
  req: ComplianceCheckRequest,
): boolean {
  if (!rule.requires) return true;
  return (Object.keys(rule.requires) as CharacteristicKey[]).every(
    (key) => req.characteristics[key] === true,
  );
}

/**
 * Match the request against the rule database and return the applicable rules
 * ranked by severity (critical first), breaking ties by jurisdiction then id
 * for deterministic output.
 */
export function matchRules(
  req: ComplianceCheckRequest,
  rules: ComplianceRule[],
): { jurisdictions: Jurisdiction[]; matched: ComplianceRule[] } {
  const jurisdictions = resolveJurisdictions(req);
  const jurisdictionSet = new Set(jurisdictions);

  const worksInUs = isUnitedStates(req.workLocation) || isUnitedStates(req.userLocation);

  const matched = rules
    .filter((rule) => jurisdictionSet.has(rule.jurisdiction))
    .filter(
      (rule) =>
        rule.industries.includes("all") || rule.industries.includes(req.industry),
    )
    .filter((rule) => characteristicsSatisfied(rule, req))
    // Work-in-US rules don't fire on a domestic shoot for a US client.
    .filter((rule) => !rule.requiresUsWorkLocation || worksInUs)
    .sort((a, b) => {
      const bySeverity = severityRank(a.severity) - severityRank(b.severity);
      if (bySeverity !== 0) return bySeverity;
      const byJurisdiction = a.jurisdiction.localeCompare(b.jurisdiction);
      if (byJurisdiction !== 0) return byJurisdiction;
      return a.id.localeCompare(b.id);
    });

  return { jurisdictions, matched };
}

/** Count matched rules by severity — feeds the response + analytics record. */
export function severityBreakdown(
  rules: ComplianceRule[],
): Record<Severity, number> {
  const breakdown = SEVERITIES.reduce((acc, sev) => {
    acc[sev] = 0;
    return acc;
  }, {} as Record<Severity, number>);
  for (const rule of rules) breakdown[rule.severity]++;
  return breakdown;
}
