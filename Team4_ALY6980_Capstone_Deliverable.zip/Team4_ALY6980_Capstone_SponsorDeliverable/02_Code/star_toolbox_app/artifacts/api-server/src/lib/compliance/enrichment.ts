// ── Track 3: AI enrichment (STUB / pluggable) ──────────────────────────────────
//
// Blueprint §5.2 sends each matched rule to an AI gateway for a 2–3 sentence
// personalized explanation. That is intentionally NOT wired up yet (the team
// chose "AI stubbed" for the first build). This module defines the seam:
//
//   • The default `templateExplanation` produces a deterministic, source-anchored
//     sentence with NO network call — so /api/compliance-check works offline.
//   • To add real AI later, implement `EnrichmentProvider` and pass it in. The
//     prompt MUST stay anchored to the stored rule text only (Risks §10: avoid
//     hallucinated rule numbers — the whole reason this project exists).

import type { ComplianceRule, ComplianceCheckRequest } from "./types";

export interface EnrichmentProvider {
  readonly name: string;
  explain(rule: ComplianceRule, req: ComplianceCheckRequest): Promise<string>;
}

/** Deterministic, no-network explanation. Strictly restates stored rule fields. */
export function templateExplanation(
  rule: ComplianceRule,
  req: ComplianceCheckRequest,
): string {
  const parts: string[] = [];
  parts.push(
    `Because your ${req.industry} project involves ${rule.jurisdiction.replace(/-/g, " ")}, this ${rule.severity}-priority item applies.`,
  );
  if (rule.formReference) parts.push(`Reference: ${rule.formReference}.`);
  if (rule.noticePeriod) parts.push(`Note the lead time: ${rule.noticePeriod}.`);
  parts.push(`Verify the details with ${rule.sourceName} before acting.`);
  return parts.join(" ");
}

/**
 * Enrich a matched rule. With no provider, returns the template (aiEnriched:
 * false). With a provider, calls it and falls back to the template on error so
 * a flaky AI gateway never breaks a compliance check.
 */
export async function enrichRule(
  rule: ComplianceRule,
  req: ComplianceCheckRequest,
  provider?: EnrichmentProvider,
): Promise<{ explanation: string; aiEnriched: boolean }> {
  if (!provider) {
    return { explanation: templateExplanation(rule, req), aiEnriched: false };
  }
  try {
    const explanation = await provider.explain(rule, req);
    return { explanation, aiEnriched: true };
  } catch {
    return { explanation: templateExplanation(rule, req), aiEnriched: false };
  }
}
