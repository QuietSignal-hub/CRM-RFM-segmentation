// ── Track 3: Compliance Intelligence — core data model ─────────────────────────
// Shared types for the compliance rule database, the matching engine, the
// check-history store, and the re-verification report. Kept dependency-free so
// the matcher stays pure and unit-testable.

/** Jurisdictions the rule database covers: federal + all 13 provinces/territories + US. */
export const JURISDICTIONS = [
  "federal-ca", // Government of Canada — applies to all Canadian work
  "bc", // British Columbia
  "ab", // Alberta
  "sk", // Saskatchewan
  "mb", // Manitoba
  "on", // Ontario
  "qc", // Quebec
  "nb", // New Brunswick
  "ns", // Nova Scotia
  "pe", // Prince Edward Island
  "nl", // Newfoundland and Labrador
  "yt", // Yukon
  "nt", // Northwest Territories
  "nu", // Nunavut
  "us-cross-border", // triggered when a US client / US work location is involved
] as const;
export type Jurisdiction = (typeof JURISDICTIONS)[number];

/** The 13 provincial/territorial jurisdiction codes (excludes federal + US). */
export const PROVINCE_CODES = [
  "bc", "ab", "sk", "mb", "on", "qc", "nb", "ns", "pe", "nl", "yt", "nt", "nu",
] as const;
export type ProvinceCode = (typeof PROVINCE_CODES)[number];

/**
 * Disciplines covered. Scope (per sponsor): photographers, singers, dancers.
 * "music" = singers/musicians, "dance" = dancers. "all" = discipline-agnostic.
 */
export const INDUSTRIES = ["photography", "music", "dance", "all"] as const;
export type Industry = (typeof INDUSTRIES)[number];

/** Severity, highest urgency first. The matcher sorts by this order. */
export const SEVERITIES = ["critical", "high", "medium", "low"] as const;
export type Severity = (typeof SEVERITIES)[number];

export const CATEGORIES = [
  "permits",
  "tax",
  "labor",
  "intellectual-property",
  "insurance",
  "cross-border",
  "privacy",
  "licensing",
] as const;
export type Category = (typeof CATEGORIES)[number];

/**
 * Boolean facts about a project that rules match against. A rule lists the
 * characteristics that must be TRUE for it to apply (see ComplianceRule.requires).
 * Add new keys here and reference them from rules + the input form.
 */
export interface ProjectCharacteristics {
  // General
  involvesMinors?: boolean;
  commercialUse?: boolean;
  hiringCrew?: boolean;
  publicProperty?: boolean;
  outdoorShoot?: boolean;
  // Photography
  droneUse?: boolean;
  paidModels?: boolean;
  sellsPrints?: boolean;
  // Music / dance (singers, dancers)
  livePerformance?: boolean;
  ticketedEvent?: boolean;
  usesRecordedMusic?: boolean;
  recordedRelease?: boolean;
  sellsMerch?: boolean;
}
export type CharacteristicKey = keyof ProjectCharacteristics;

/**
 * One verified compliance rule. The `description` is the source of truth — the
 * source URL is for reference only, so a broken link never invalidates the rule
 * text (see Risks §10). `verified`/`lastVerified` gate whether a human has
 * confirmed the rule against the live government source.
 */
export interface ComplianceRule {
  id: string;
  title: string;
  /** Plain-language statement of the obligation. Stored, authoritative. */
  description: string;
  jurisdiction: Jurisdiction;
  /** Industries this rule applies to. Use ["all"] for industry-agnostic rules. */
  industries: Industry[];
  category: Category;
  severity: Severity;
  /**
   * Characteristics that must ALL be true for the rule to apply. Empty/absent =
   * the rule applies to every project in its jurisdiction + industry.
   */
  requires?: Partial<Record<CharacteristicKey, true>>;
  /**
   * For us-cross-border rules only: when true, the rule applies only if work is
   * physically performed in the US (work/user location), not merely when the
   * CLIENT is American. Distinguishes "you worked in the US" obligations (visas,
   * child-performer protections) from "you were paid by a US client" ones
   * (withholding, W-8BEN).
   */
  requiresUsWorkLocation?: true;
  /** Official form/reference number, when one exists (e.g. "Form W-8BEN"). */
  formReference?: string;
  /** Statutory notice/lead-time, when one applies (e.g. "14 days before"). */
  noticePeriod?: string;
  /** Concrete next steps the creator can take. */
  actionSteps?: string[];
  /** Issuing authority (e.g. "CNESST", "Canada Revenue Agency"). */
  sourceName: string;
  /** Reference URL — official domain. Exact deep link must be human-verified. */
  sourceUrl: string;
  /** ISO date a human last confirmed this rule against the live source. */
  lastVerified: string | null;
  /** True only once a human has verified the rule. Seed data ships as false. */
  verified: boolean;
  /** Curator notes — what still needs confirming before flipping `verified`. */
  verificationNote?: string;
}

/** Request body for POST /api/compliance-check. */
export interface ComplianceCheckRequest {
  /** Free-text project description (e.g. used by AI enrichment). */
  description?: string;
  industry: Exclude<Industry, "all">;
  /** Where the creator is based (province code/name, or "US"). */
  userLocation: string;
  /** Where the work physically happens. */
  workLocation: string;
  /** Where the client is based. */
  clientLocation: string;
  characteristics: ProjectCharacteristics;
}

/** A single matched rule, enriched and ready for the frontend checklist. */
export interface MatchedRule extends ComplianceRule {
  /** 2–3 sentence personalized explanation (templated stub or AI). */
  explanation: string;
  /** False = deterministic template; true = produced by an AI provider. */
  aiEnriched: boolean;
}

export interface ComplianceCheckResponse {
  checkId: string;
  timestamp: string;
  jurisdictionsResolved: Jurisdiction[];
  matchCount: number;
  severityBreakdown: Record<Severity, number>;
  rules: MatchedRule[];
  disclaimer: string;
}

/** What we persist per check — shaped for the Track 5 analytics dashboard. */
export interface ComplianceCheckRecord {
  id: string;
  timestamp: string;
  industry: string;
  userLocation: string;
  workLocation: string;
  clientLocation: string;
  characteristics: ProjectCharacteristics;
  jurisdictionsResolved: Jurisdiction[];
  matchedRuleIds: string[];
  matchCount: number;
  severityBreakdown: Record<Severity, number>;
}
