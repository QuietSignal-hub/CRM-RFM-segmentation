// ── Track 3: Province/territory data + generated provincial rules ──────────────
//
// The rules that vary by province (sales tax, workers' comp, business
// registration, employment standards) are generated from this one verified
// table instead of being hand-copied 13 times. A curator edits a single row
// (rate, board, URL) rather than four near-identical rule objects.
//
// Verification (as of VERIFIED_ON): sales-tax rates and workers'-comp board
// identities were confirmed via web research against official sources. Business
// registry and employment-standards rules carry the correct official provincial
// domain but are flagged verified:false — the exact landing page should be
// confirmed by a human per province.

import type { ComplianceRule, ProvinceCode } from "./types";

const VERIFIED_ON = "2026-06-11";

const CRA_RATE_URL =
  "https://www.canada.ca/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/charge-collect-which-rate.html";

type SalesTax =
  | { kind: "HST"; total: number; sourceUrl: string; note?: string }
  | { kind: "PST" | "RST"; provincial: number; total: number; sourceUrl: string }
  | { kind: "QST"; provincial: number; total: number; sourceUrl: string }
  | { kind: "GST_ONLY"; total: 5; sourceUrl: string };

interface ProvinceInfo {
  code: ProvinceCode;
  name: string;
  sales: SalesTax;
  wcbName: string;
  wcbUrl: string;
  registryName: string;
  registryUrl: string;
  esName: string;
  esUrl: string;
}

export const PROVINCES: ProvinceInfo[] = [
  {
    code: "bc",
    name: "British Columbia",
    sales: { kind: "PST", provincial: 7, total: 12, sourceUrl: "https://www2.gov.bc.ca/gov/content/taxes/sales-taxes/pst" },
    wcbName: "WorkSafeBC",
    wcbUrl: "https://www.worksafebc.com/",
    registryName: "BC Registries and Online Services",
    registryUrl: "https://www2.gov.bc.ca/gov/content/employment-business/business/managing-a-business/permits-licences/businesses-incorporated-companies/register-a-business",
    esName: "BC Employment Standards Branch",
    esUrl: "https://www2.gov.bc.ca/gov/content/employment-business/employment-standards-advice/employment-standards",
  },
  {
    code: "ab",
    name: "Alberta",
    sales: { kind: "GST_ONLY", total: 5, sourceUrl: CRA_RATE_URL },
    wcbName: "Workers' Compensation Board – Alberta",
    wcbUrl: "https://www.wcb.ab.ca/",
    registryName: "Alberta corporate/trade-name registry (via an authorized registry agent)",
    registryUrl: "https://www.alberta.ca/register-business-name",
    esName: "Alberta Employment Standards",
    esUrl: "https://www.alberta.ca/employment-standards",
  },
  {
    code: "sk",
    name: "Saskatchewan",
    sales: { kind: "PST", provincial: 6, total: 11, sourceUrl: "https://www.saskatchewan.ca/business/taxes-licensing/provincial-taxes-policies-and-bulletins/provincial-sales-tax" },
    wcbName: "WCB Saskatchewan",
    wcbUrl: "https://www.wcbsask.com/",
    registryName: "Information Services Corporation (ISC)",
    registryUrl: "https://www.saskatchewan.ca/business/first-steps-for-businesses/register-incorporate-and-license-your-business",
    esName: "Saskatchewan Employment Standards",
    esUrl: "https://www.saskatchewan.ca/business/employment-standards",
  },
  {
    code: "mb",
    name: "Manitoba",
    sales: { kind: "RST", provincial: 7, total: 12, sourceUrl: "https://www.gov.mb.ca/finance/taxation/taxes/retail.html" },
    wcbName: "Workers Compensation Board of Manitoba",
    wcbUrl: "https://www.wcb.mb.ca/",
    registryName: "Manitoba Companies Office",
    registryUrl: "https://www.companiesoffice.gov.mb.ca/",
    esName: "Manitoba Employment Standards",
    esUrl: "https://www.gov.mb.ca/labour/standards/",
  },
  {
    code: "on",
    name: "Ontario",
    sales: { kind: "HST", total: 13, sourceUrl: CRA_RATE_URL },
    wcbName: "Workplace Safety and Insurance Board (WSIB)",
    wcbUrl: "https://www.wsib.ca/en",
    registryName: "Ontario Business Registry",
    registryUrl: "https://www.ontario.ca/page/registering-your-business-name",
    esName: "Ontario Employment Standards Act",
    esUrl: "https://www.ontario.ca/document/your-guide-employment-standards-act-0",
  },
  {
    code: "qc",
    name: "Quebec",
    sales: { kind: "QST", provincial: 9.975, total: 14.975, sourceUrl: "https://www.revenuquebec.ca/en/businesses/consumption-taxes/gsthst-and-qst/registering-for-the-gst-and-qst/" },
    wcbName: "CNESST",
    wcbUrl: "https://www.cnesst.gouv.qc.ca/en",
    registryName: "Registraire des entreprises du Québec (REQ)",
    registryUrl: "https://www.registreentreprises.gouv.qc.ca/en/",
    esName: "CNESST (normes du travail)",
    esUrl: "https://www.cnesst.gouv.qc.ca/en/working-conditions",
  },
  {
    code: "nb",
    name: "New Brunswick",
    sales: { kind: "HST", total: 15, sourceUrl: CRA_RATE_URL },
    wcbName: "WorkSafeNB",
    wcbUrl: "https://www.worksafenb.ca/",
    registryName: "Service New Brunswick — Corporate Registry",
    registryUrl: "https://www2.snb.ca/content/snb/en/sites/corporate-registry.html",
    esName: "New Brunswick Employment Standards",
    esUrl: "https://www2.gnb.ca/content/gnb/en/departments/post-secondary_education_training_and_labour/People/content/EmploymentStandards.html",
  },
  {
    code: "ns",
    name: "Nova Scotia",
    sales: { kind: "HST", total: 14, sourceUrl: CRA_RATE_URL, note: "Nova Scotia's HST dropped from 15% to 14% on April 1, 2025 (provincial part 9%)." },
    wcbName: "Workers' Compensation Board of Nova Scotia",
    wcbUrl: "https://www.wcb.ns.ca/",
    registryName: "Registry of Joint Stock Companies",
    registryUrl: "https://beta.novascotia.ca/programs-and-services/registry-joint-stock-companies",
    esName: "Nova Scotia Labour Standards",
    esUrl: "https://novascotia.ca/lae/employmentrights/",
  },
  {
    code: "pe",
    name: "Prince Edward Island",
    sales: { kind: "HST", total: 15, sourceUrl: CRA_RATE_URL },
    wcbName: "Workers Compensation Board of PEI",
    wcbUrl: "https://www.wcb.pe.ca/",
    registryName: "PEI business registration",
    registryUrl: "https://www.princeedwardisland.ca/en/topic/business-registration",
    esName: "PEI Employment Standards",
    esUrl: "https://www.princeedwardisland.ca/en/information/workforce-advanced-learning-and-population/employment-standards",
  },
  {
    code: "nl",
    name: "Newfoundland and Labrador",
    sales: { kind: "HST", total: 15, sourceUrl: CRA_RATE_URL },
    wcbName: "WorkplaceNL",
    wcbUrl: "https://workplacenl.ca/",
    registryName: "NL Registry of Companies",
    registryUrl: "https://www.gov.nl.ca/dgsnl/registries/companies/",
    esName: "NL Labour Standards",
    esUrl: "https://www.gov.nl.ca/jps/working/",
  },
  {
    code: "yt",
    name: "Yukon",
    sales: { kind: "GST_ONLY", total: 5, sourceUrl: CRA_RATE_URL },
    wcbName: "Yukon Workers' Compensation Health and Safety Board",
    wcbUrl: "https://wcb.yk.ca/",
    registryName: "Yukon Corporate Affairs",
    registryUrl: "https://yukon.ca/en/doing-business/business-permits-and-licensing/register-business",
    esName: "Yukon Employment Standards",
    esUrl: "https://yukon.ca/en/employment-standards",
  },
  {
    code: "nt",
    name: "Northwest Territories",
    sales: { kind: "GST_ONLY", total: 5, sourceUrl: CRA_RATE_URL },
    wcbName: "Workers' Safety and Compensation Commission (WSCC)",
    wcbUrl: "https://www.wscc.nt.ca/",
    registryName: "NWT Corporate Registries",
    registryUrl: "https://www.justice.gov.nt.ca/en/registries/corporate-registries/",
    esName: "NWT Employment Standards",
    esUrl: "https://www.ece.gov.nt.ca/en/services/employment-standards",
  },
  {
    code: "nu",
    name: "Nunavut",
    sales: { kind: "GST_ONLY", total: 5, sourceUrl: CRA_RATE_URL },
    wcbName: "Workers' Safety and Compensation Commission (WSCC)",
    wcbUrl: "https://www.wscc.nu.ca/",
    registryName: "Nunavut Legal Registries",
    registryUrl: "https://nunavutlegalregistries.ca/",
    esName: "Nunavut Labour Standards",
    esUrl: "https://nu-lsco.ca/",
  },
];

function salesTaxRule(p: ProvinceInfo): ComplianceRule {
  const s = p.sales;
  let description: string;
  let severity: ComplianceRule["severity"];
  if (s.kind === "HST") {
    description = `As a registered business you charge ${s.total}% HST on taxable sales in ${p.name}. HST is administered by the CRA; you register once worldwide taxable revenue passes the federal $30,000 small-supplier threshold.${s.note ? " " + s.note : ""}`;
    severity = "high";
  } else if (s.kind === "QST") {
    description = `Quebec charges 9.975% QST in addition to the 5% federal GST (≈14.975% combined). Register for GST + QST with Revenu Québec once over the $30,000 threshold — you have 30 days from the sale that crosses it.`;
    severity = "high";
  } else if (s.kind === "PST" || s.kind === "RST") {
    description = `${p.name} levies a ${s.provincial}% ${s.kind} on top of the 5% federal GST (≈${s.total}% combined). Register with the province to collect ${s.kind}; the GST side follows the federal $30,000 threshold. ${s.kind} can apply on different rules than GST — check what is taxable.`;
    severity = "high";
  } else {
    description = `${p.name} has no provincial sales tax — only the 5% federal GST applies. Register for GST once worldwide taxable revenue passes the federal $30,000 small-supplier threshold.`;
    severity = "low";
  }
  return {
    id: `${p.code}-sales-tax`,
    title:
      s.kind === "GST_ONLY"
        ? `No provincial sales tax in ${p.name} (5% GST only)`
        : `Collect ${s.kind === "HST" ? `${s.total}% HST` : s.kind === "QST" ? "GST + 9.975% QST" : `${s.kind} (${(s as any).provincial}%) + GST`} in ${p.name}`,
    description,
    jurisdiction: p.code,
    industries: ["all"],
    category: "tax",
    severity,
    requires: { commercialUse: true },
    sourceName: s.kind === "HST" || s.kind === "GST_ONLY" ? "Canada Revenue Agency" : `${p.name} (provincial tax authority)`,
    sourceUrl: s.sourceUrl,
    lastVerified: VERIFIED_ON,
    verified: true,
  };
}

function workersCompRule(p: ProvinceInfo): ComplianceRule {
  return {
    id: `${p.code}-workers-comp`,
    title: `Register workers with ${p.wcbName}`,
    description: `Employers with workers in ${p.name} generally must register with ${p.wcbName} for workers' compensation / occupational-health coverage. Self-employed sole proprietors are often not automatically covered but may opt in.`,
    jurisdiction: p.code,
    industries: ["all"],
    category: "insurance",
    severity: "medium",
    requires: { hiringCrew: true },
    sourceName: p.wcbName,
    sourceUrl: p.wcbUrl,
    lastVerified: VERIFIED_ON,
    verified: true,
  };
}

function businessRegistrationRule(p: ProvinceInfo): ComplianceRule {
  return {
    id: `${p.code}-business-registration`,
    title: `Register your business name in ${p.name}`,
    description: `Operating under a business name other than your own legal name generally requires registration with ${p.registryName}. Sole proprietorships, partnerships, and corporations follow different paths.`,
    jurisdiction: p.code,
    industries: ["all"],
    category: "permits",
    severity: "medium",
    sourceName: p.registryName,
    sourceUrl: p.registryUrl,
    lastVerified: null,
    verified: false,
    verificationNote: "Requirement is standard across provinces; confirm the exact registry landing page/fee for this province.",
  };
}

function employmentStandardsRule(p: ProvinceInfo): ComplianceRule {
  return {
    id: `${p.code}-employment-standards`,
    title: `Meet ${p.name} employment standards when hiring`,
    description: `If you hire employees in ${p.name} (vs. independent contractors), provincial employment standards — minimum wage, hours, overtime, vacation, record-keeping — apply, administered via ${p.esName}.`,
    jurisdiction: p.code,
    industries: ["all"],
    category: "labor",
    severity: "medium",
    requires: { hiringCrew: true },
    sourceName: p.esName,
    sourceUrl: p.esUrl,
    lastVerified: null,
    verified: false,
    verificationNote: "Confirm the exact employment-standards page and any artist/performer-specific provisions for this province.",
  };
}

/** All generated province-varying rules (sales tax, WCB, registration, ES). */
export function provincialRules(): ComplianceRule[] {
  return PROVINCES.flatMap((p) => [
    salesTaxRule(p),
    workersCompRule(p),
    businessRegistrationRule(p),
    employmentStandardsRule(p),
  ]);
}
