// ── Track 3: Check-history store (local JSON) ──────────────────────────────────
//
// Persists one record per compliance check to local-data/compliance_checks.json.
// This is the table the Track 5 analytics dashboard reads (usage volume, top
// rules triggered, jurisdiction breakdown, segment usage). Local-file storage
// matches the repo's current architecture; swap this module for a DB later
// without touching the route or matcher.

import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import type { ComplianceCheckRecord } from "./types";

const DATA_DIR = path.resolve(process.cwd(), "local-data");
const CHECKS_FILE = path.join(DATA_DIR, "compliance_checks.json");

// Serialize read-modify-write so concurrent requests don't clobber the file.
let writeQueue: Promise<unknown> = Promise.resolve();

async function readAllRaw(): Promise<ComplianceCheckRecord[]> {
  try {
    const raw = await readFile(CHECKS_FILE, "utf8");
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as ComplianceCheckRecord[]) : [];
  } catch (err: any) {
    if (err?.code === "ENOENT") return []; // not created yet
    throw err;
  }
}

/** Append a check record. Creates local-data/ and the file on first write. */
export async function appendCheckRecord(
  record: ComplianceCheckRecord,
): Promise<void> {
  const task = writeQueue.then(async () => {
    await mkdir(DATA_DIR, { recursive: true });
    const all = await readAllRaw();
    all.push(record);
    await writeFile(CHECKS_FILE, JSON.stringify(all, null, 2), "utf8");
  });
  // Keep the chain alive even if this write fails.
  writeQueue = task.catch(() => undefined);
  return task;
}

/** Read check history, newest first, optionally limited. */
export async function readCheckHistory(
  limit?: number,
): Promise<ComplianceCheckRecord[]> {
  const all = await readAllRaw();
  const newestFirst = [...all].reverse();
  return typeof limit === "number" ? newestFirst.slice(0, limit) : newestFirst;
}
