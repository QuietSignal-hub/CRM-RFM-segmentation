// ── Track 3: Compliance rule database ──────────────────────────────────────────
//
// Scope: PHOTOGRAPHERS, SINGERS (music), DANCERS (dance) — Federal Canada, ALL
// 13 provinces/territories, and US cross-border.
//
// Province-varying rules (sales tax, workers' comp, business registration,
// employment standards) are GENERATED from the verified table in ./provinces.ts
// and spread in at the end of this array. The rules below are federal,
// cross-border, discipline-specific, and province-SPECIAL (e.g. child-performer
// regimes, Quebec Bill 96) that don't fit the generic template.
//
// VERIFICATION STATUS. Rules marked `verified: true` had their source URL and
// core facts confirmed against the live official government/collective-society
// page on `lastVerified`. This is SOURCE verification, not legal certification:
// it confirms the rule reflects the cited source, not that the source is the
// complete legal picture for a given project. Rules marked `verified: false`
// are practice-based or vary by municipality/state and still need a human owner
// to confirm — see ./CURATION.md.
//
// "Why generic AI fails" (Blueprint §2): every rule below links to the real
// source so a user — and the curator — can check it.

import type { ComplianceRule } from "./types";
import { provincialRules } from "./provinces";

const VERIFIED_ON = "2026-06-11";

export const COMPLIANCE_RULES: ComplianceRule[] = [
  // ── Federal (Canada) — applies to all disciplines ─────────────────────────
  {
    id: "fed-gst-hst-registration",
    title: "Register for GST/HST once over the $30,000 threshold",
    description:
      "A self-employed creator must register for and collect GST/HST once worldwide taxable revenue exceeds CAD $30,000 in a single calendar quarter or over four consecutive quarters. You must register within 29 days of the sale that pushes you over. Registration is online via Business Registration Online (CRA stopped phone registration on Nov 3, 2025).",
    jurisdiction: "federal-ca",
    industries: ["all"],
    category: "tax",
    severity: "high",
    requires: { commercialUse: true },
    sourceName: "Canada Revenue Agency",
    sourceUrl: "https://www.canada.ca/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/when-register-charge.html",
    lastVerified: VERIFIED_ON,
    verified: true,
  },
  {
    id: "fed-business-number",
    title: "Obtain a Business Number (BN)",
    description:
      "A CRA Business Number is required before opening GST/HST or payroll program accounts. Sole proprietors operating under their own legal name may not need one until they register for a program account.",
    jurisdiction: "federal-ca",
    industries: ["all"],
    category: "permits",
    severity: "medium",
    sourceName: "Canada Revenue Agency",
    sourceUrl: "https://www.canada.ca/en/services/taxes/business-number.html",
    lastVerified: VERIFIED_ON,
    verified: true,
  },
  {
    id: "fed-income-tax-t2125",
    title: "Report self-employment income on Form T2125",
    description:
      "Self-employed creative income and expenses are reported on Form T2125 (Statement of Business or Professional Activities) with your personal T1 return. Quarterly tax instalments may be required if you owe more than $3,000 in net tax in the year and either of the two prior years.",
    jurisdiction: "federal-ca",
    industries: ["all"],
    category: "tax",
    severity: "high",
    formReference: "Form T2125",
    sourceName: "Canada Revenue Agency",
    sourceUrl: "https://www.canada.ca/en/revenue-agency/services/forms-publications/forms/t2125.html",
    lastVerified: VERIFIED_ON,
    verified: true,
  },
  {
    id: "fed-copyright-ownership",
    title: "Know your copyright (automatic; registration optional)",
    description:
      "Under the Copyright Act, copyright in an original work (a photograph, song, or choreographic work) exists automatically on creation — no registration needed. Registration with CIPO is optional but gives a certificate that is evidence of ownership in a dispute. Clarify ownership/licensing with clients in writing.",
    jurisdiction: "federal-ca",
    industries: ["all"],
    category: "intellectual-property",
    severity: "medium",
    sourceName: "Canadian Intellectual Property Office (CIPO)",
    sourceUrl: "https://ised-isde.canada.ca/site/canadian-intellectual-property-office/en/copyright",
    lastVerified: VERIFIED_ON,
    verified: true,
  },
  {
    id: "fed-pipeda-personal-info",
    title: "Handle personal information per PIPEDA",
    description:
      "When collecting, using, or disclosing identifiable personal information (clients, mailing lists, recognizable subjects) in commercial activity, PIPEDA obligations — meaningful consent, stated purpose, safeguarding — may apply. Quebec's Law 25 imposes stricter consent rules when subjects are in Quebec.",
    jurisdiction: "federal-ca",
    industries: ["all"],
    category: "privacy",
    severity: "medium",
    requires: { commercialUse: true },
    sourceName: "Office of the Privacy Commissioner of Canada",
    sourceUrl: "https://www.priv.gc.ca/en/privacy-topics/privacy-laws-in-canada/the-personal-information-protection-and-electronic-documents-act-pipeda/",
    lastVerified: VERIFIED_ON,
    verified: true,
  },
  {
    id: "fed-status-of-artist",
    title: "Status of the Artist Act (federal collective representation)",
    description:
      "The federal Status of the Artist Act lets certified artists' associations represent self-employed artists in scale agreements with federal producers/broadcasters. Relevant if you engage with federally-regulated producers; administered via the Canada Industrial Relations Board.",
    jurisdiction: "federal-ca",
    industries: ["music", "dance"],
    category: "labor",
    severity: "low",
    sourceName: "Canada Industrial Relations Board",
    sourceUrl: "https://www.cirb-ccri.gc.ca/en/decisions/certification-register-under-status",
    lastVerified: VERIFIED_ON,
    verified: true,
  },
  {
    id: "fed-payroll-deductions",
    title: "Remit payroll source deductions when hiring employees",
    description:
      "If you hire employees (vs. independent contractors), open a payroll account and remit CPP, EI, and income-tax source deductions to the CRA. Misclassifying employees as contractors carries penalties.",
    jurisdiction: "federal-ca",
    industries: ["all"],
    category: "labor",
    severity: "medium",
    requires: { hiringCrew: true },
    sourceName: "Canada Revenue Agency",
    sourceUrl: "https://www.canada.ca/en/services/taxes/payroll.html",
    lastVerified: VERIFIED_ON,
    verified: true,
  },
  {
    id: "fed-ei-self-employed",
    title: "Consider opting into EI special benefits",
    description:
      "Self-employed creators can opt into federal Employment Insurance for special benefits (maternity, parental, sickness, caregiving). Enrolment with the Canada Employment Insurance Commission and a waiting period apply before benefits can be claimed.",
    jurisdiction: "federal-ca",
    industries: ["all"],
    category: "labor",
    severity: "low",
    sourceName: "Service Canada / Employment Insurance",
    sourceUrl: "https://www.canada.ca/en/services/benefits/ei/ei-self-employed-workers.html",
    lastVerified: VERIFIED_ON,
    verified: true,
  },

  // ── Federal — music / performance rights ──────────────────────────────────
  {
    id: "fed-socan-performance-licence",
    title: "Clear songwriter/publisher rights (SOCAN, via Entandem)",
    description:
      "Public performance or communication of musical works requires a SOCAN licence (paying composers, lyricists, and publishers). Since 2019, SOCAN and Re:Sound licences for businesses are obtained together through Entandem. The venue/event organizer is usually the licensee, but the obligation should be confirmed in your engagement.",
    jurisdiction: "federal-ca",
    industries: ["music", "dance"],
    category: "licensing",
    severity: "high",
    requires: { livePerformance: true },
    sourceName: "SOCAN / Entandem",
    sourceUrl: "https://www.socan.com/music-licenses/",
    lastVerified: VERIFIED_ON,
    verified: true,
  },
  {
    id: "fed-resound-recorded-music",
    title: "Clear sound-recording rights (Re:Sound, via Entandem)",
    description:
      "Using recorded music in public (e.g. a dancer performing to recorded tracks, or recorded music at an event) requires a Re:Sound licence, which pays performers and makers of the recording. This is separate from SOCAN and is obtained together via Entandem.",
    jurisdiction: "federal-ca",
    industries: ["dance", "music"],
    category: "licensing",
    severity: "high",
    requires: { usesRecordedMusic: true },
    sourceName: "Re:Sound / Entandem",
    sourceUrl: "https://www.resound.ca/tariffs-2-2/",
    lastVerified: VERIFIED_ON,
    verified: true,
  },
  {
    id: "fed-sync-master-license",
    title: "Obtain sync + master licences to set music to video",
    description:
      "Putting copyrighted music to moving images (a music video, a dance reel) requires a synchronization licence from the music publisher AND a master-use licence from the owner of the specific recording. This is separate from SOCAN/Re:Sound performance tariffs.",
    jurisdiction: "federal-ca",
    industries: ["music", "dance"],
    category: "licensing",
    severity: "medium",
    requires: { recordedRelease: true },
    sourceName: "Music publishers / rights holders",
    sourceUrl: "https://www.socan.com/music-licenses/",
    lastVerified: null,
    verified: false,
    verificationNote: "Sync/master licences are negotiated privately, not via a single government source — confirm the licensing path per use.",
  },

  // ── Federal — photography ─────────────────────────────────────────────────
  {
    id: "fed-model-release-consent",
    title: "Get model/subject consent for commercial use",
    description:
      "Commercial use of a recognizable person's image generally requires their consent (a signed model release). This is grounded in privacy/personality rights — PIPEDA federally, and Article 36 of the Civil Code of Québec (image and voice) in Quebec — plus client/stock-agency requirements. Newsworthy or incidental subjects can be exceptions.",
    jurisdiction: "federal-ca",
    industries: ["photography"],
    category: "privacy",
    severity: "high",
    requires: { paidModels: true },
    sourceName: "Office of the Privacy Commissioner of Canada",
    sourceUrl: "https://www.priv.gc.ca/en/privacy-topics/privacy-laws-in-canada/the-personal-information-protection-and-electronic-documents-act-pipeda/",
    lastVerified: VERIFIED_ON,
    verified: true,
    verificationNote: "In Quebec, anchor to Civil Code art. 36 (image/voice). Outside QC, consent is driven by privacy/personality rights + client needs.",
  },
  {
    id: "fed-location-property-release",
    title: "Obtain location / property releases",
    description:
      "For commercial shoots on recognizable private property or featuring branded/trademarked property, get a property release from the owner authorizing commercial use of the imagery.",
    jurisdiction: "federal-ca",
    industries: ["photography"],
    category: "intellectual-property",
    severity: "medium",
    requires: { commercialUse: true },
    sourceName: "Industry practice (no single statute)",
    sourceUrl: "https://www.canada.ca/en.html",
    lastVerified: null,
    verified: false,
    verificationNote: "Practice-based, not statutory — keep as guidance, not a cited legal requirement.",
  },
  {
    id: "fed-drone-rpas-certificate",
    title: "Hold a Drone Pilot Certificate and register the drone (RPAS)",
    description:
      "Operating a drone weighing 250 g or more requires registering it and holding a Transport Canada Pilot Certificate (Basic or Advanced operations, depending on where/how you fly). Drones under 250 g need no certificate but must follow microdrone rules. The certificate does not expire but skills must be kept current.",
    jurisdiction: "federal-ca",
    industries: ["photography"],
    category: "permits",
    severity: "high",
    requires: { droneUse: true },
    sourceName: "Transport Canada",
    sourceUrl: "https://tc.canada.ca/en/aviation/drone-safety/drone-pilot-licensing/getting-drone-pilot-certificate",
    lastVerified: VERIFIED_ON,
    verified: true,
  },

  // ── Province-specific special rules (child performers, language, etc.) ─────
  // NB: standard provincial rules (sales tax, workers' comp, business
  // registration, employment standards) for ALL provinces are generated from
  // ./provinces.ts and spread in at the end — they are NOT listed here.
  {
    id: "on-child-performers-act",
    title: "Comply with the Protecting Child Performers Act, 2015 (Ontario)",
    description:
      "Ontario's Protecting Child Performers Act protects paid child performers in the LIVE and RECORDED entertainment industries — directly relevant to young singers and dancers. It requires a parent/guardian or authorized chaperone present for performers under 16 (recorded), a designated child performers' co-ordinator (recorded) or child attendant (live), and sets minimum ages (15 days recorded; 2.5 years live).",
    jurisdiction: "on",
    industries: ["music", "dance", "photography"],
    category: "labor",
    severity: "critical",
    requires: { involvesMinors: true },
    sourceName: "Government of Ontario",
    sourceUrl: "https://www.ontario.ca/page/child-performers",
    lastVerified: VERIFIED_ON,
    verified: true,
  },
  {
    id: "on-municipal-performance-permit",
    title: "Permit for performing or shooting on public property (Ontario)",
    description:
      "Performing, busking, or commercial photography on municipal property/streets in Ontario commonly requires a permit or licence from the local municipality, often with proof of insurance. Requirements vary by city.",
    jurisdiction: "on",
    industries: ["photography", "music", "dance"],
    category: "permits",
    severity: "medium",
    requires: { publicProperty: true },
    sourceName: "Municipal (varies)",
    sourceUrl: "https://www.ontario.ca/",
    lastVerified: null,
    verified: false,
    verificationNote: "Municipal and venue-specific — confirm per city (e.g. City of Toronto) for the actual engagement.",
  },
  {
    id: "bc-child-performer",
    title: "Follow BC child-in-entertainment rules (Employment Standards Reg. Part 7.1)",
    description:
      "British Columbia regulates children in the recorded and live entertainment industries under Employment Standards Regulation Part 7.1: minimum age 15 days, daily hour caps by age (under 2: max 4 hrs/day; over 2: max 8 hrs/day), 12 consecutive hours free per day, chaperone requirements, and earnings protection — 25% of earnings over $2,000 on a production is remitted to the Public Guardian and Trustee.",
    jurisdiction: "bc",
    industries: ["music", "dance", "photography"],
    category: "labor",
    severity: "critical",
    requires: { involvesMinors: true },
    sourceName: "Province of British Columbia — Employment Standards",
    sourceUrl: "https://www2.gov.bc.ca/gov/content/employment-business/employment-standards-advice/employment-standards/hiring/young-people",
    lastVerified: VERIFIED_ON,
    verified: true,
  },
  {
    id: "mb-child-performer-permit",
    title: "Obtain a child performer permit (Manitoba)",
    description:
      "Manitoba's Employment Standards requires a child performer permit to employ a child in artistic/entertainment work, with conditions on hours, supervision, and schooling. Apply before the engagement.",
    jurisdiction: "mb",
    industries: ["music", "dance", "photography"],
    category: "labor",
    severity: "critical",
    requires: { involvesMinors: true },
    sourceName: "Manitoba Employment Standards",
    sourceUrl: "https://www.gov.mb.ca/labour/standards/doc,child_performers-permit,factsheet.html",
    lastVerified: VERIFIED_ON,
    verified: true,
  },
  {
    id: "qc-income-tax",
    title: "File a Quebec provincial income tax return (TP-1)",
    description:
      "Quebec administers its own income tax separately from the CRA. Self-employed creators resident or earning in Quebec file a TP-1 provincial return in addition to the federal T1.",
    jurisdiction: "qc",
    industries: ["all"],
    category: "tax",
    severity: "high",
    sourceName: "Revenu Québec",
    sourceUrl: "https://www.revenuquebec.ca/en/citizens/income-tax-return/",
    lastVerified: VERIFIED_ON,
    verified: true,
  },
  {
    id: "qc-child-artist-consent",
    title: "Get CNESST parental-consent form for a child performer (Quebec)",
    description:
      "Since June 1, 2023, Quebec's minimum working age is 14, BUT children working as creators/performers in artistic fields (performing arts, theatre, music, dance) are EXEMPT from the minimum age. The employer must obtain written parental consent on the CNESST-prescribed form, recording the main tasks, maximum weekly hours, and availability. School-age children are limited to 17 hours/week during school weeks (max 10 on weekdays).",
    jurisdiction: "qc",
    industries: ["music", "dance", "photography"],
    category: "labor",
    severity: "critical",
    requires: { involvesMinors: true },
    sourceName: "CNESST",
    sourceUrl: "https://www.cnesst.gouv.qc.ca/en/working-conditions/special-status/young-workers/young-people-under-14-years-age",
    lastVerified: VERIFIED_ON,
    verified: true,
    verificationNote: "Corrects the original blueprint's 'Form 1042 / 14-day notice' — that detail predated the 2023 reform and was inaccurate.",
  },
  {
    id: "qc-status-of-artists-act",
    title: "Quebec professional-status-of-artists protections (S-32.1)",
    description:
      "Quebec's Act respecting the professional status of performing, recording, and film artists (CQLR c. S-32.1) governs relations between self-employed performing artists (incl. singers and dancers) and producers — recognized associations, model contracts, and minimum engagement conditions.",
    jurisdiction: "qc",
    industries: ["music", "dance"],
    category: "labor",
    severity: "low",
    sourceName: "LégisQuébec",
    sourceUrl: "https://www.legisquebec.gouv.qc.ca/en/document/cs/s-32.1",
    lastVerified: VERIFIED_ON,
    verified: true,
  },
  {
    id: "qc-french-language-bill96",
    title: "Meet French-language requirements (Charter / Bill 96)",
    description:
      "Commercial advertising, public signage, and customer-facing materials in Quebec must comply with the Charter of the French Language. Bill 96 amendments in force June 1, 2025 require French to be markedly predominant and tightened rules for non-French trademarks on signage/packaging. Fines run $700–$7,000 (individuals) and $3,000–$30,000 (others), doubling on repeat offences.",
    jurisdiction: "qc",
    industries: ["all"],
    category: "licensing",
    severity: "medium",
    requires: { commercialUse: true },
    sourceName: "Office québécois de la langue française (OQLF)",
    sourceUrl: "https://www.oqlf.gouv.qc.ca/",
    lastVerified: VERIFIED_ON,
    verified: true,
  },

  // ── US cross-border ───────────────────────────────────────────────────────
  {
    id: "us-treaty-article-xvi-artistes",
    title: "Apply Canada–US treaty Article XVI (artistes & athletes)",
    description:
      "Income a Canadian entertainer (musician, performer) earns from personal activities performed in the US may be taxed by the US, EXCEPT where gross receipts from those activities do not exceed USD $15,000 for the calendar year. Withholding can apply, but not on the first USD $5,000 of remuneration in the year. This artiste-specific rule governs your US performance income.",
    jurisdiction: "us-cross-border",
    industries: ["music", "dance"],
    category: "cross-border",
    severity: "high",
    requiresUsWorkLocation: true,
    sourceName: "CRA — Article XVI, Canada–US Tax Convention",
    sourceUrl: "https://www.canada.ca/en/revenue-agency/services/tax/international-non-residents/film-media-tax-credits/non-resident-actors/article-artists-athletes-canada-united-states-income-tax-convention.html",
    lastVerified: VERIFIED_ON,
    verified: true,
  },
  {
    id: "us-w8ben-treaty-claim",
    title: "File Form W-8BEN (or 8233) to claim treaty benefits",
    description:
      "A Canadian paid by a US payer files Form W-8BEN (or Form 8233 for exemption on independent personal-services income) with the withholding agent to certify foreign status and claim Canada–US treaty benefits, reducing default US withholding.",
    jurisdiction: "us-cross-border",
    industries: ["all"],
    category: "cross-border",
    severity: "high",
    formReference: "Form W-8BEN / Form 8233",
    sourceName: "US Internal Revenue Service (IRS)",
    sourceUrl: "https://www.irs.gov/forms-pubs/about-form-w-8-ben",
    lastVerified: VERIFIED_ON,
    verified: true,
  },
  {
    id: "us-p2-visa-performers",
    title: "Get a P-2 (or O-1) visa to perform in the US",
    description:
      "Performing paid work physically in the US needs work authorization. Canadian musicians and performers commonly use the P-2 visa via a reciprocal exchange program (e.g. the American Federation of Musicians Canada↔US, or Canadian Actors' Equity↔US Actors' Equity for stage performers). The O-1 visa is for individually, internationally recognized artists. Entering as a business visitor does NOT permit paid US work.",
    jurisdiction: "us-cross-border",
    industries: ["music", "dance"],
    category: "cross-border",
    severity: "critical",
    requiresUsWorkLocation: true,
    sourceName: "USCIS",
    sourceUrl: "https://www.uscis.gov/working-in-the-united-states/temporary-workers/p-2-individual-performer-or-part-of-a-group-entering-to-perform-under-a-reciprocal-exchange-program",
    lastVerified: VERIFIED_ON,
    verified: true,
    verificationNote: "Musicians: route P-2 via the Canadian Federation of Musicians (AFM). Confirm the correct reciprocal program for the performer's discipline.",
  },
  {
    id: "us-1042s-reporting",
    title: "Expect a Form 1042-S from the US payer",
    description:
      "US payers report amounts paid to, and tax withheld from, foreign persons on Form 1042-S. Keep it to claim a foreign tax credit on your Canadian return.",
    jurisdiction: "us-cross-border",
    industries: ["all"],
    category: "cross-border",
    severity: "low",
    formReference: "Form 1042-S",
    sourceName: "US Internal Revenue Service (IRS)",
    sourceUrl: "https://www.irs.gov/forms-pubs/about-form-1042-s",
    lastVerified: VERIFIED_ON,
    verified: true,
  },
  {
    id: "us-state-sales-tax-prints",
    title: "Check US state sales-tax nexus for print/merch sales",
    description:
      "Selling prints or merchandise to US customers can create state sales-tax collection obligations where economic-nexus thresholds are met. Rules and thresholds vary by state.",
    jurisdiction: "us-cross-border",
    industries: ["photography", "music", "dance"],
    category: "cross-border",
    severity: "low",
    requires: { sellsPrints: true },
    sourceName: "US state revenue departments (varies)",
    sourceUrl: "https://www.irs.gov/businesses/small-businesses-self-employed",
    lastVerified: null,
    verified: false,
    verificationNote: "State-specific — confirm nexus rules for the states you sell into. (Also gate on sellsMerch for musicians/dancers.)",
  },

  // ── Generated: standard provincial rules for all 13 provinces/territories ──
  ...provincialRules(),
];
