// ── Track 3: interactive test console (dev/demo aid) ───────────────────────────
//
// Serves a self-contained HTML page at GET /api/compliance/console so the
// compliance-check endpoint can be exercised in a browser before the real
// CompliancePanel (Track 4) exists. Same-origin → no CORS/proxy needed.
// This is a developer/demo convenience, not a production UI.

import { Router, type IRouter } from "express";

const router: IRouter = Router();

const PAGE = /* html */ `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>S.T.A.R. Compliance Console</title>
<style>
  :root { --bg:#0f1720; --card:#172230; --line:#26384a; --ink:#e7eef6; --mut:#90a4b8;
          --crit:#e5484d; --high:#f76808; --med:#f5d90a; --low:#46a758; --accent:#3b82f6; }
  * { box-sizing: border-box; }
  body { margin:0; font:14px/1.5 ui-sans-serif,system-ui,Segoe UI,Roboto,sans-serif;
         background:var(--bg); color:var(--ink); }
  header { padding:20px 24px; border-bottom:1px solid var(--line); }
  h1 { margin:0; font-size:18px; }
  .sub { color:var(--mut); font-size:13px; margin-top:2px; }
  .wrap { display:grid; grid-template-columns:340px 1fr; gap:0; min-height:calc(100vh - 70px); }
  form { padding:20px 24px; border-right:1px solid var(--line); }
  label { display:block; font-size:12px; color:var(--mut); margin:14px 0 4px; text-transform:uppercase; letter-spacing:.04em; }
  input, select { width:100%; padding:8px 10px; background:var(--card); border:1px solid var(--line);
                  color:var(--ink); border-radius:8px; font-size:14px; }
  .checks { display:grid; grid-template-columns:1fr 1fr; gap:6px 12px; margin-top:6px; }
  .checks label { display:flex; align-items:center; gap:6px; margin:0; text-transform:none;
                  letter-spacing:0; color:var(--ink); font-size:13px; cursor:pointer; }
  .checks input { width:auto; }
  button { margin-top:18px; width:100%; padding:10px; background:var(--accent); color:#fff;
           border:0; border-radius:8px; font-size:14px; font-weight:600; cursor:pointer; }
  button:hover { filter:brightness(1.08); }
  .results { padding:20px 24px; overflow:auto; }
  .meta { color:var(--mut); font-size:13px; margin-bottom:14px; }
  .rule { background:var(--card); border:1px solid var(--line); border-left-width:4px;
          border-radius:8px; padding:12px 14px; margin-bottom:10px; }
  .rule.critical { border-left-color:var(--crit); }
  .rule.high { border-left-color:var(--high); }
  .rule.medium { border-left-color:var(--med); }
  .rule.low { border-left-color:var(--low); }
  .rule h3 { margin:0 0 4px; font-size:14px; }
  .tags { display:flex; flex-wrap:wrap; gap:6px; margin:6px 0; }
  .tag { font-size:11px; padding:2px 7px; border-radius:999px; background:#0e1722; border:1px solid var(--line); color:var(--mut); }
  .tag.sev { color:#fff; border:0; }
  .tag.sev.critical{background:var(--crit)} .tag.sev.high{background:var(--high)}
  .tag.sev.medium{background:#a88600} .tag.sev.low{background:var(--low)}
  .desc { color:var(--ink); font-size:13px; }
  .expl { color:var(--mut); font-size:12px; margin-top:6px; font-style:italic; }
  a { color:#7fb2ff; }
  .badge-unverified { font-size:10px; color:var(--high); border:1px solid var(--high); padding:1px 5px; border-radius:4px; margin-left:6px; }
  .disclaimer { margin-top:16px; padding:10px 12px; background:#1b1205; border:1px solid #6b3d0a;
                border-radius:8px; color:#f3c08a; font-size:12px; }
  .empty { color:var(--mut); }
</style>
</head>
<body>
<header>
  <h1>S.T.A.R. Compliance Console <span class="sub">— Track 3 API tester</span></h1>
  <div class="sub">Exercises POST /api/compliance-check. All rules are unverified seed data.</div>
</header>
<div class="wrap">
  <form id="f">
    <label>Discipline</label>
    <select name="industry">
      <option value="photography">Photographer</option>
      <option value="music">Singer / musician</option>
      <option value="dance">Dancer</option>
    </select>
    <label>Your location</label>
    <input name="userLocation" value="Ontario" />
    <label>Work / performance location</label>
    <input name="workLocation" value="Quebec" />
    <label>Client / payer location</label>
    <input name="clientLocation" value="Canada" />
    <label>Project characteristics</label>
    <div class="checks">
      <label><input type="checkbox" name="involvesMinors" checked /> Involves minors</label>
      <label><input type="checkbox" name="commercialUse" checked /> Commercial use</label>
      <label><input type="checkbox" name="hiringCrew" /> Hiring crew/employees</label>
      <label><input type="checkbox" name="publicProperty" /> On public property</label>
      <label><input type="checkbox" name="outdoorShoot" /> Outdoor</label>
      <label><input type="checkbox" name="droneUse" /> Drone use</label>
      <label><input type="checkbox" name="paidModels" /> Paid models/subjects</label>
      <label><input type="checkbox" name="sellsPrints" /> Sells prints/merch</label>
      <label><input type="checkbox" name="livePerformance" /> Live performance</label>
      <label><input type="checkbox" name="ticketedEvent" /> Ticketed event</label>
      <label><input type="checkbox" name="usesRecordedMusic" /> Uses recorded music</label>
      <label><input type="checkbox" name="recordedRelease" /> Releases a recording/video</label>
      <label><input type="checkbox" name="sellsMerch" /> Sells merch</label>
    </div>
    <button type="submit">Run compliance check</button>
  </form>
  <div class="results" id="out"><div class="empty">Submit the form to see the ranked checklist.</div></div>
</div>
<script>
const CHAR_KEYS = ["involvesMinors","commercialUse","hiringCrew","publicProperty","outdoorShoot","droneUse","paidModels","sellsPrints","livePerformance","ticketedEvent","usesRecordedMusic","recordedRelease","sellsMerch"];
const f = document.getElementById("f");
const out = document.getElementById("out");
f.addEventListener("submit", async (e) => {
  e.preventDefault();
  const fd = new FormData(f);
  const characteristics = {};
  for (const k of CHAR_KEYS) if (fd.get(k)) characteristics[k] = true;
  const body = {
    industry: fd.get("industry"),
    userLocation: fd.get("userLocation"),
    workLocation: fd.get("workLocation"),
    clientLocation: fd.get("clientLocation"),
    characteristics,
  };
  out.innerHTML = '<div class="empty">Running…</div>';
  try {
    const res = await fetch("/api/compliance-check", {
      method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body),
    });
    const data = await res.json();
    if (!res.ok) { out.innerHTML = '<div class="disclaimer">Error: ' + (data.error || res.status) + '</div>'; return; }
    render(data);
  } catch (err) {
    out.innerHTML = '<div class="disclaimer">Request failed: ' + err.message + '</div>';
  }
});
function esc(s){ return String(s).replace(/[&<>]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;"}[c])); }
function render(d) {
  const sb = d.severityBreakdown;
  let html = '<div class="meta"><b>' + d.matchCount + ' rules</b> across ' +
    d.jurisdictionsResolved.join(", ") + ' &nbsp;·&nbsp; ' +
    'critical ' + sb.critical + ' / high ' + sb.high + ' / medium ' + sb.medium + ' / low ' + sb.low + '</div>';
  for (const r of d.rules) {
    html += '<div class="rule ' + r.severity + '">' +
      '<h3>' + esc(r.title) + (r.verified ? '' : '<span class="badge-unverified">UNVERIFIED</span>') + '</h3>' +
      '<div class="tags">' +
        '<span class="tag sev ' + r.severity + '">' + r.severity + '</span>' +
        '<span class="tag">' + r.jurisdiction + '</span>' +
        '<span class="tag">' + r.category + '</span>' +
        (r.formReference ? '<span class="tag">' + esc(r.formReference) + '</span>' : '') +
      '</div>' +
      '<div class="desc">' + esc(r.description) + '</div>' +
      '<div class="expl">' + esc(r.explanation) + ' · <a href="' + esc(r.sourceUrl) + '" target="_blank" rel="noopener">' + esc(r.sourceName) + ' ↗</a></div>' +
    '</div>';
  }
  html += '<div class="disclaimer">' + esc(d.disclaimer) + '</div>';
  out.innerHTML = html;
}
</script>
</body>
</html>`;

router.get("/compliance/console", (_req, res) => {
  res.type("html").send(PAGE);
});

export default router;
