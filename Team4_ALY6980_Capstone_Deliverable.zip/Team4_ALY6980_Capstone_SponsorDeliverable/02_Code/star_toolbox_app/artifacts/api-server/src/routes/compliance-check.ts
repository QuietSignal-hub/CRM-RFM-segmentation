// ── Track 3: Compliance Intelligence API ───────────────────────────────────────
//
//   POST /api/compliance-check        Run a check → ranked, enriched checklist
//   GET  /api/compliance/rules        Browse the rule database (filterable)
//   GET  /api/compliance/rules/:id    Fetch a single rule
//   GET  /api/compliance/checks       Recent check history (for analytics)
//   GET  /api/compliance/health       Rule-database health / re-verification report
//
// Storage is local JSON; the matcher and enrichment are pure modules in
// ../lib/compliance. AI enrichment is stubbed (deterministic template) — see
// enrichment.ts to plug in a provider.

import { Router, type IRouter } from "express";
import { randomUUID } from "node:crypto";
import {
  INDUSTRIES,
  type ComplianceCheckRequest,
  type ComplianceCheckResponse,
  type ComplianceCheckRecord,
  type MatchedRule,
  type ProjectCharacteristics,
  type CharacteristicKey,
} from "../lib/compliance/types";
import { COMPLIANCE_RULES } from "../lib/compliance/rules";
import { matchRules, severityBreakdown } from "../lib/compliance/matcher";
import { enrichRule } from "../lib/compliance/enrichment";
import { appendCheckRecord, readCheckHistory } from "../lib/compliance/storage";
import { buildHealthReport } from "../lib/compliance/reverify";

const router: IRouter = Router();

const DISCLAIMER =
  "This is informational compliance research, not legal advice. Rules may be " +
  "unverified or out of date — confirm each item with the linked official " +
  "source and consult a professional before acting.";

const VALID_CHARACTERISTICS: CharacteristicKey[] = [
  "involvesMinors",
  "commercialUse",
  "hiringCrew",
  "publicProperty",
  "outdoorShoot",
  "droneUse",
  "paidModels",
  "sellsPrints",
  "livePerformance",
  "ticketedEvent",
  "usesRecordedMusic",
  "recordedRelease",
  "sellsMerch",
];

// ── Input validation (manual, mirrors parse-content.ts style) ──────────────────

function validateRequest(
  body: any,
): { ok: true; value: ComplianceCheckRequest } | { ok: false; error: string } {
  if (typeof body !== "object" || body === null) {
    return { ok: false, error: "Request body must be a JSON object" };
  }

  const industry = body.industry;
  if (industry !== "photography" && industry !== "music" && industry !== "dance") {
    return { ok: false, error: 'industry must be "photography", "music", or "dance"' };
  }

  for (const field of ["userLocation", "workLocation", "clientLocation"]) {
    if (typeof body[field] !== "string" || body[field].trim() === "") {
      return { ok: false, error: `${field} is required and must be a non-empty string` };
    }
  }

  const characteristics: ProjectCharacteristics = {};
  if (body.characteristics != null) {
    if (typeof body.characteristics !== "object") {
      return { ok: false, error: "characteristics must be an object" };
    }
    for (const [key, val] of Object.entries(body.characteristics)) {
      if (!VALID_CHARACTERISTICS.includes(key as CharacteristicKey)) {
        return { ok: false, error: `Unknown characteristic: ${key}` };
      }
      if (typeof val !== "boolean") {
        return { ok: false, error: `characteristic "${key}" must be a boolean` };
      }
      characteristics[key as CharacteristicKey] = val;
    }
  }

  return {
    ok: true,
    value: {
      description: typeof body.description === "string" ? body.description : undefined,
      industry,
      userLocation: body.userLocation,
      workLocation: body.workLocation,
      clientLocation: body.clientLocation,
      characteristics,
    },
  };
}

// ── POST /compliance-check ─────────────────────────────────────────────────────

router.post("/compliance-check", async (req: any, res: any) => {
  const validation = validateRequest(req.body);
  if (!validation.ok) {
    return res.status(400).json({ error: validation.error });
  }
  const request = validation.value;

  const { jurisdictions, matched } = matchRules(request, COMPLIANCE_RULES);

  // Enrich each matched rule (stubbed → deterministic template, no network).
  const rules: MatchedRule[] = await Promise.all(
    matched.map(async (rule) => {
      const { explanation, aiEnriched } = await enrichRule(rule, request);
      return { ...rule, explanation, aiEnriched };
    }),
  );

  const checkId = randomUUID();
  const timestamp = new Date().toISOString();
  const breakdown = severityBreakdown(matched);

  // Persist for analytics (Track 5). Never let a logging failure break the check.
  const record: ComplianceCheckRecord = {
    id: checkId,
    timestamp,
    industry: request.industry,
    userLocation: request.userLocation,
    workLocation: request.workLocation,
    clientLocation: request.clientLocation,
    characteristics: request.characteristics,
    jurisdictionsResolved: jurisdictions,
    matchedRuleIds: matched.map((r) => r.id),
    matchCount: matched.length,
    severityBreakdown: breakdown,
  };
  try {
    await appendCheckRecord(record);
  } catch (err) {
    req.log.error({ err }, "failed to persist compliance check record");
  }

  const response: ComplianceCheckResponse = {
    checkId,
    timestamp,
    jurisdictionsResolved: jurisdictions,
    matchCount: matched.length,
    severityBreakdown: breakdown,
    rules,
    disclaimer: DISCLAIMER,
  };
  return res.json(response);
});

// ── GET /compliance/rules ──────────────────────────────────────────────────────

router.get("/compliance/rules", (req: any, res: any) => {
  const { jurisdiction, industry, category, severity, verified } = req.query;

  let rules = COMPLIANCE_RULES;
  if (jurisdiction) rules = rules.filter((r) => r.jurisdiction === jurisdiction);
  if (category) rules = rules.filter((r) => r.category === category);
  if (severity) rules = rules.filter((r) => r.severity === severity);
  if (industry) {
    rules = rules.filter(
      (r) => r.industries.includes("all") || r.industries.includes(industry),
    );
  }
  if (verified === "true") rules = rules.filter((r) => r.verified);
  if (verified === "false") rules = rules.filter((r) => !r.verified);

  return res.json({ count: rules.length, rules });
});

// ── GET /compliance/rules/:id ──────────────────────────────────────────────────

router.get("/compliance/rules/:id", (req: any, res: any) => {
  const rule = COMPLIANCE_RULES.find((r) => r.id === req.params.id);
  if (!rule) return res.status(404).json({ error: "Rule not found" });
  return res.json(rule);
});

// ── GET /compliance/checks ─────────────────────────────────────────────────────

router.get("/compliance/checks", async (req: any, res: any) => {
  const rawLimit = req.query.limit;
  let limit: number | undefined;
  if (rawLimit != null) {
    const n = Number(rawLimit);
    if (Number.isNaN(n) || n < 0) {
      return res.status(400).json({ error: "limit must be a non-negative number" });
    }
    limit = n;
  }
  try {
    const checks = await readCheckHistory(limit);
    return res.json({ count: checks.length, checks });
  } catch (err) {
    req.log.error({ err }, "failed to read compliance check history");
    return res.status(500).json({ error: "Failed to read check history" });
  }
});

// ── GET /compliance/health ─────────────────────────────────────────────────────

router.get("/compliance/health", (_req: any, res: any) => {
  return res.json(buildHealthReport(COMPLIANCE_RULES));
});

export default router;
