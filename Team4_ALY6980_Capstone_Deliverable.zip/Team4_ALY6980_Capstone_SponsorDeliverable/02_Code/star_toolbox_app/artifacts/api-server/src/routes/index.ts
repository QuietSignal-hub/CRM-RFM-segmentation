import { Router, type IRouter } from "express";
import healthRouter from "./health";
import parseContentRouter from "./parse-content";
import complianceRouter from "./compliance-check";
import complianceConsoleRouter from "./compliance-console";

const router: IRouter = Router();

router.use(healthRouter);
router.use(parseContentRouter);
router.use(complianceRouter);
router.use(complianceConsoleRouter);

export default router;
