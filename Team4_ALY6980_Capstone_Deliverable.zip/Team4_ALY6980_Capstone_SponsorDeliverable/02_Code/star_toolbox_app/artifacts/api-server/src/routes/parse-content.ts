import { Router, type IRouter } from "express";
import dns from "node:dns/promises";
import net from "node:net";

const router: IRouter = Router();

// ── SSRF guard ───────────────────────────────────────────────────────────────
// Returns true if the IPv4/IPv6 address is private, loopback, link-local,
// or otherwise not safe to fetch from a public server context.
function isPrivateIp(ip: string): boolean {
  // Normalise IPv6-mapped IPv4 addresses: ::ffff:1.2.3.4 → 1.2.3.4
  const normalised = ip.replace(/^::ffff:/i, "");

  if (net.isIPv4(normalised)) {
    const parts = normalised.split(".").map(Number);
    const [a, b] = parts;
    return (
      a === 0 ||                              // 0.0.0.0/8
      a === 10 ||                             // 10.0.0.0/8
      a === 127 ||                            // 127.0.0.0/8 loopback
      a === 169 && b === 254 ||               // 169.254.0.0/16 link-local
      a === 172 && b >= 16 && b <= 31 ||      // 172.16.0.0/12
      a === 192 && b === 168 ||               // 192.168.0.0/16
      a === 192 && b === 0 && parts[2] === 2 || // 192.0.2.0/24 TEST-NET-1
      a === 198 && b === 51 && parts[2] === 100 || // 198.51.100.0/24 TEST-NET-2
      a === 203 && b === 0 && parts[2] === 113 ||  // 203.0.113.0/24 TEST-NET-3
      a >= 224                                // 224+ multicast / reserved
    );
  }

  if (net.isIPv6(normalised)) {
    const lower = normalised.toLowerCase();
    return (
      lower === "::1" ||                      // loopback
      lower.startsWith("fc") ||              // fc00::/7 Unique Local
      lower.startsWith("fd") ||
      lower.startsWith("fe80") ||            // fe80::/10 link-local
      lower.startsWith("ff") ||              // ff00::/8 multicast
      lower === "::"                          // unspecified
    );
  }

  // Unknown format — block it
  return true;
}

async function assertPublicUrl(targetUrl: URL): Promise<void> {
  const hostname = targetUrl.hostname;

  // Block bare IP inputs that are already private
  if (net.isIP(hostname)) {
    if (isPrivateIp(hostname)) {
      throw Object.assign(new Error("Private/reserved IP addresses are not allowed"), { code: "SSRF" });
    }
    return;
  }

  // Block obviously internal hostnames
  const lower = hostname.toLowerCase();
  if (
    lower === "localhost" ||
    lower.endsWith(".local") ||
    lower.endsWith(".internal") ||
    lower.endsWith(".localhost") ||
    lower === "metadata.google.internal" ||
    lower === "169.254.169.254" // AWS/GCP metadata IP as hostname
  ) {
    throw Object.assign(new Error("Internal hostnames are not allowed"), { code: "SSRF" });
  }

  // Resolve DNS and check every returned address
  let addresses: string[];
  try {
    const results = await dns.lookup(hostname, { all: true });
    addresses = results.map((r) => r.address);
  } catch (e: any) {
    throw Object.assign(new Error(`DNS resolution failed: ${e.message}`), { code: "SSRF" });
  }

  if (addresses.length === 0) {
    throw Object.assign(new Error("DNS returned no addresses"), { code: "SSRF" });
  }

  for (const addr of addresses) {
    if (isPrivateIp(addr)) {
      throw Object.assign(
        new Error(`Resolved to a private/reserved address (${addr}) — not allowed`),
        { code: "SSRF" }
      );
    }
  }
}

// ── HTML/RSS helpers ──────────────────────────────────────────────────────────

function stripHtml(html: string): string {
  return html
    .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, " ")
    .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&nbsp;/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function parseRssText(xml: string): string {
  const items: string[] = [];
  const itemMatches = xml.matchAll(/<item[^>]*>([\s\S]*?)<\/item>/gi);
  for (const match of itemMatches) {
    const item = match[1];
    const title =
      item.match(/<title[^>]*><!\[CDATA\[(.*?)\]\]><\/title>/i)?.[1] ??
      item.match(/<title[^>]*>(.*?)<\/title>/i)?.[1] ?? "";
    const desc =
      item.match(/<description[^>]*><!\[CDATA\[([\s\S]*?)\]\]><\/description>/i)?.[1] ??
      item.match(/<description[^>]*>([\s\S]*?)<\/description>/i)?.[1] ?? "";
    const text = [title.trim(), stripHtml(desc).slice(0, 400)].filter(Boolean).join(": ");
    if (text) items.push(text);
  }
  if (items.length > 0) return items.join("\n\n");

  // Atom feed fallback
  const entries: string[] = [];
  const entryMatches = xml.matchAll(/<entry[^>]*>([\s\S]*?)<\/entry>/gi);
  for (const match of entryMatches) {
    const entry = match[1];
    const title = entry.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1] ?? "";
    const summary =
      entry.match(/<summary[^>]*>([\s\S]*?)<\/summary>/i)?.[1] ??
      entry.match(/<content[^>]*>([\s\S]*?)<\/content>/i)?.[1] ?? "";
    const text = [stripHtml(title).trim(), stripHtml(summary).slice(0, 400)].filter(Boolean).join(": ");
    if (text) entries.push(text);
  }
  return entries.join("\n\n");
}

// ── Route ─────────────────────────────────────────────────────────────────────

router.post("/parse-content", async (req: any, res: any) => {
  const { url, type } = req.body as { url?: string; type?: "url" | "rss" };

  if (!url) return res.status(400).json({ error: "url is required" });

  let targetUrl: URL;
  try {
    targetUrl = new URL(url);
  } catch {
    return res.status(400).json({ error: "Invalid URL" });
  }

  if (!["http:", "https:"].includes(targetUrl.protocol)) {
    return res.status(400).json({ error: "Only http/https URLs are supported" });
  }

  // SSRF guard — DNS-resolve then validate every address before fetching
  try {
    await assertPublicUrl(targetUrl);
  } catch (e: any) {
    return res.status(400).json({ error: e.message });
  }

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10_000);

    const response = await fetch(targetUrl.toString(), {
      signal: controller.signal,
      redirect: "follow",
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; STARToolbox/1.0)",
        Accept:
          type === "rss"
            ? "application/rss+xml, application/atom+xml, application/xml, text/xml, */*"
            : "text/html, */*",
      },
    });

    clearTimeout(timeout);

    // After redirects, re-validate the final URL against SSRF rules
    if (response.url && response.url !== targetUrl.toString()) {
      try {
        await assertPublicUrl(new URL(response.url));
      } catch (e: any) {
        return res.status(400).json({ error: `Redirect target blocked: ${e.message}` });
      }
    }

    if (!response.ok) {
      return res.status(502).json({ error: `Remote server returned ${response.status}` });
    }

    // Content-length guard (10 MB raw before stripping)
    const contentLength = Number(response.headers.get("content-length") ?? 0);
    if (contentLength > 10_000_000) {
      return res.status(413).json({ error: "Remote resource is too large (> 10 MB)" });
    }

    const contentType = response.headers.get("content-type") ?? "";
    const rawText = await response.text();

    // Guard on actual body size too (in case Content-Length was absent/wrong)
    if (rawText.length > 10_000_000) {
      return res.status(413).json({ error: "Remote resource body is too large" });
    }

    let content: string;
    if (type === "rss" || contentType.includes("xml") || contentType.includes("rss") || contentType.includes("atom")) {
      content = parseRssText(rawText);
      if (!content) content = stripHtml(rawText);
    } else {
      content = stripHtml(rawText);
    }

    // Truncate extracted text to ~50 KB
    if (content.length > 50_000) content = content.slice(0, 50_000) + "…";

    return res.json({ content });
  } catch (err: any) {
    if (err.name === "AbortError") {
      return res.status(504).json({ error: "Request timed out — the URL took too long to respond" });
    }
    req.log.error({ err }, "parse-content fetch failed");
    return res.status(502).json({ error: "Failed to fetch URL: " + (err.message ?? "unknown error") });
  }
});

export default router;
